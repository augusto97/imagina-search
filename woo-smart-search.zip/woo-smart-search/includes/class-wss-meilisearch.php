<?php
/**
 * Meilisearch connection class (singleton).
 *
 * Direct connection to Meilisearch without abstraction layers.
 * Uses wp_remote_* for HTTP communication.
 *
 * @package WooSmartSearch
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WSS_Meilisearch
 */
class WSS_Meilisearch implements WSS_Search_Engine {

	/**
	 * Singleton instance.
	 *
	 * @var WSS_Meilisearch|null
	 */
	private static $instance = null;

	/**
	 * Base URL of the Meilisearch server.
	 *
	 * @var string
	 */
	private $base_url = '';

	/**
	 * API key.
	 *
	 * @var string
	 */
	private $api_key = '';

	/**
	 * Whether the engine is connected.
	 *
	 * @var bool
	 */
	private $connected = false;

	/**
	 * Get the singleton instance, auto-configured from plugin settings.
	 *
	 * @return WSS_Meilisearch|null Returns null if API key is not configured.
	 */
	public static function get_instance() {
		if ( null !== self::$instance ) {
			return self::$instance;
		}

		// Read directly from DB to avoid stale static cache in wss_get_option().
		$settings = get_option( 'wss_settings', array() );
		$api_key  = isset( $settings['api_key'] ) ? $settings['api_key'] : '';

		if ( empty( $api_key ) ) {
			return null;
		}

		$decrypted = self::decrypt_key( $api_key );

		// Auto-migrate legacy encryption formats to v2 (random IV).
		if ( strpos( $api_key, 'enc2_' ) !== 0 && ! empty( $decrypted ) && function_exists( 'openssl_encrypt' ) ) {
			$settings['api_key'] = self::encrypt_key( $decrypted );
			update_option( 'wss_settings', $settings );
		}

		self::$instance = new self();
		self::$instance->connect( array(
			'host'     => isset( $settings['host'] ) ? $settings['host'] : 'localhost',
			'port'     => isset( $settings['port'] ) ? $settings['port'] : '',
			'protocol' => isset( $settings['protocol'] ) ? $settings['protocol'] : 'http',
			'api_key'  => $decrypted,
		) );

		return self::$instance;
	}

	/**
	 * Create a new instance with custom config (for testing connection).
	 *
	 * @param array $config Connection config.
	 * @return WSS_Meilisearch
	 */
	public static function create( array $config ) {
		$instance = new self();
		$instance->connect( $config );
		return $instance;
	}

	/**
	 * Reset the singleton (for config changes).
	 */
	public static function reset() {
		self::$instance = null;
	}

	/**
	 * Connect to Meilisearch.
	 *
	 * @param array $config Configuration array.
	 * @return bool
	 */
	public function connect( array $config ): bool {
		$protocol = isset( $config['protocol'] ) ? $config['protocol'] : 'http';
		$host     = isset( $config['host'] ) ? rtrim( $config['host'], '/' ) : 'localhost';
		$port     = isset( $config['port'] ) && '' !== $config['port'] ? $config['port'] : '';

		$host = preg_replace( '#^https?://#', '', $host );

		$this->base_url = $protocol . '://' . $host;
		if ( $port ) {
			$this->base_url .= ':' . $port;
		}
		$this->api_key   = isset( $config['api_key'] ) ? $config['api_key'] : '';
		$this->connected = true;

		return true;
	}

	/**
	 * Test the connection.
	 *
	 * Uses /health (no auth required) to verify connectivity, then
	 * tries /version (requires admin key) for version info.
	 *
	 * @return array { success: bool, message: string, version: string }
	 */
	public function test_connection(): array {
		// Step 1: Check /health — no auth required, works with any key.
		$health = $this->request( 'GET', '/health' );

		if ( is_wp_error( $health ) ) {
			return array(
				'success' => false,
				'message' => $health->get_error_message(),
				'version' => '',
			);
		}

		$health_code = wp_remote_retrieve_response_code( $health );
		if ( 200 !== $health_code ) {
			return array(
				'success' => false,
				'message' => sprintf(
					/* translators: %d: HTTP status code */
					__( 'Meilisearch returned HTTP %d', 'woo-smart-search' ),
					$health_code
				),
				'version' => '',
			);
		}

		// Step 2: Try /version for version info (may fail with restricted keys).
		$version_str = '';
		$response    = $this->request( 'GET', '/version' );
		if ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) ) {
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			// Meilisearch returns pkgVersion; handle possible key variations.
			if ( isset( $body['pkgVersion'] ) ) {
				$version_str = $body['pkgVersion'];
			} elseif ( isset( $body['version'] ) ) {
				$version_str = $body['version'];
			}
		}

		// Fallback: try /health response which may include version in some setups.
		if ( empty( $version_str ) && ! is_wp_error( $health ) ) {
			$health_body = json_decode( wp_remote_retrieve_body( $health ), true );
			if ( isset( $health_body['version'] ) ) {
				$version_str = $health_body['version'];
			}
		}

		// Detect restricted key: /health works but /version doesn't.
		$restricted_key = empty( $version_str ) && ! is_wp_error( $response )
			&& 200 !== wp_remote_retrieve_response_code( $response );

		return array(
			'success'        => true,
			'message'        => __( 'Connected successfully to Meilisearch', 'woo-smart-search' ),
			'version'        => $version_str,
			'restricted_key' => $restricted_key,
		);
	}

	/**
	 * Create an index.
	 *
	 * @param string $index_name Index name.
	 * @return bool
	 */
	public function create_index( string $index_name ): bool {
		$body     = array(
			'uid'        => $index_name,
			'primaryKey' => 'id',
		);
		$response = $this->request( 'POST', '/indexes', $body );
		if ( is_wp_error( $response ) ) {
			wss_log( 'Failed to create index: ' . $response->get_error_message(), 'error' );
			return false;
		}
		$status = wp_remote_retrieve_response_code( $response );
		// 200/201/202 = success or accepted, 409 = index already exists (not an error).
		return in_array( $status, array( 200, 201, 202, 409 ), true );
	}

	/**
	 * Delete an index.
	 *
	 * @param string $index_name Index name.
	 * @return bool
	 */
	public function delete_index( string $index_name ): bool {
		$response = $this->request( 'DELETE', '/indexes/' . $index_name );
		if ( is_wp_error( $response ) ) {
			return false;
		}
		return in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202, 204 ), true );
	}

	/**
	 * Get index statistics.
	 *
	 * @param string $index_name Index name.
	 * @return array
	 */
	public function get_index_stats( string $index_name ): array {
		$response = $this->request( 'GET', '/indexes/' . $index_name . '/stats' );
		if ( is_wp_error( $response ) ) {
			return array( 'numberOfDocuments' => 0, 'isIndexing' => false );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		return array(
			'numberOfDocuments' => isset( $body['numberOfDocuments'] ) ? (int) $body['numberOfDocuments'] : 0,
			'isIndexing'        => isset( $body['isIndexing'] ) ? (bool) $body['isIndexing'] : false,
		);
	}

	/**
	 * Configure index settings (searchable, filterable, sortable attributes).
	 *
	 * @param string $index_name Index name.
	 * @param array  $settings   Settings.
	 * @return bool
	 */
	public function configure_index( string $index_name, array $settings ): bool {
		$response = $this->request( 'PATCH', '/indexes/' . $index_name . '/settings', $settings );
		if ( is_wp_error( $response ) ) {
			wss_log( 'Failed to configure index: ' . $response->get_error_message(), 'error' );
			return false;
		}
		$status = wp_remote_retrieve_response_code( $response );
		if ( ! in_array( $status, array( 200, 202 ), true ) ) {
			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			wss_log( sprintf( 'configure_index failed (HTTP %d): %s', $status, isset( $body['message'] ) ? $body['message'] : 'Unknown' ), 'error' );
			return false;
		}
		return true;
	}

	/**
	 * Add or replace documents in the index.
	 *
	 * @param string $index_name Index name.
	 * @param array  $documents  Documents array.
	 * @return array
	 */
	public function index_documents( string $index_name, array $documents ): array {
		$response = $this->request( 'POST', '/indexes/' . $index_name . '/documents', $documents );
		if ( is_wp_error( $response ) ) {
			return array( 'success' => false, 'message' => $response->get_error_message() );
		}

		$status = wp_remote_retrieve_response_code( $response );
		$body   = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! in_array( $status, array( 200, 202 ), true ) ) {
			$error_msg = isset( $body['message'] ) ? $body['message'] : 'Unknown error';
			wss_log(
				sprintf( 'index_documents failed (HTTP %d): %s', $status, $error_msg ),
				'error'
			);
			return array( 'success' => false, 'message' => sprintf( 'HTTP %d: %s', $status, $error_msg ) );
		}

		return array( 'success' => true, 'taskUid' => isset( $body['taskUid'] ) ? $body['taskUid'] : null );
	}

	/**
	 * Delete a single document.
	 *
	 * @param string $index_name  Index name.
	 * @param string $document_id Document ID.
	 * @return bool
	 */
	public function delete_document( string $index_name, string $document_id ): bool {
		$response = $this->request( 'DELETE', '/indexes/' . $index_name . '/documents/' . $document_id );
		if ( is_wp_error( $response ) ) {
			return false;
		}
		return in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Delete all documents from an index.
	 *
	 * @param string $index_name Index name.
	 * @return bool
	 */
	public function delete_all_documents( string $index_name ): bool {
		$response = $this->request( 'DELETE', '/indexes/' . $index_name . '/documents' );
		if ( is_wp_error( $response ) ) {
			return false;
		}
		return in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Search documents.
	 *
	 * @param string $index_name Index name.
	 * @param string $query      Search query.
	 * @param array  $options    Search options.
	 * @return array
	 */
	public function search( string $index_name, string $query, array $options = array() ): array {
		$body = array( 'q' => $query );

		if ( isset( $options['limit'] ) ) {
			$body['limit'] = (int) $options['limit'];
		}
		if ( isset( $options['offset'] ) ) {
			$body['offset'] = (int) $options['offset'];
		}
		if ( ! empty( $options['filters'] ) ) {
			$body['filter'] = $options['filters'];
		}
		if ( ! empty( $options['facets'] ) ) {
			$body['facets'] = $options['facets'];
		}
		if ( ! empty( $options['sort'] ) ) {
			$body['sort'] = (array) $options['sort'];
		}
		if ( ! empty( $options['highlight_fields'] ) ) {
			$body['attributesToHighlight'] = $options['highlight_fields'];
			$body['highlightPreTag']       = '<mark>';
			$body['highlightPostTag']      = '</mark>';
		}

		$response = $this->request( 'POST', '/indexes/' . $index_name . '/search', $body );

		if ( is_wp_error( $response ) ) {
			return array(
				'hits'               => array(),
				'query'              => $query,
				'estimatedTotalHits' => 0,
				'error'              => $response->get_error_message(),
			);
		}

		$result = json_decode( wp_remote_retrieve_body( $response ), true );

		return array(
			'hits'               => isset( $result['hits'] ) ? $result['hits'] : array(),
			'query'              => $query,
			'estimatedTotalHits' => isset( $result['estimatedTotalHits'] ) ? (int) $result['estimatedTotalHits'] : 0,
			'facetDistribution'  => isset( $result['facetDistribution'] ) ? $result['facetDistribution'] : array(),
			'processingTimeMs'   => isset( $result['processingTimeMs'] ) ? (int) $result['processingTimeMs'] : 0,
		);
	}

	/**
	 * Set searchable attributes.
	 *
	 * @param string $index_name Index name.
	 * @param array  $attributes Attributes.
	 * @return bool
	 */
	public function set_searchable_attributes( string $index_name, array $attributes ): bool {
		$response = $this->request( 'PUT', '/indexes/' . $index_name . '/settings/searchable-attributes', $attributes );
		return ! is_wp_error( $response ) && in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Set filterable attributes.
	 *
	 * @param string $index_name Index name.
	 * @param array  $attributes Attributes.
	 * @return bool
	 */
	public function set_filterable_attributes( string $index_name, array $attributes ): bool {
		$response = $this->request( 'PUT', '/indexes/' . $index_name . '/settings/filterable-attributes', $attributes );
		return ! is_wp_error( $response ) && in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Set sortable attributes.
	 *
	 * @param string $index_name Index name.
	 * @param array  $attributes Attributes.
	 * @return bool
	 */
	public function set_sortable_attributes( string $index_name, array $attributes ): bool {
		$response = $this->request( 'PUT', '/indexes/' . $index_name . '/settings/sortable-attributes', $attributes );
		return ! is_wp_error( $response ) && in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Set displayed attributes (controls which fields are returned in search results).
	 *
	 * @param string $index_name Index name.
	 * @param array  $attributes Attributes to display.
	 * @return bool
	 */
	public function set_displayed_attributes( string $index_name, array $attributes ): bool {
		$response = $this->request( 'PUT', '/indexes/' . $index_name . '/settings/displayed-attributes', $attributes );
		return ! is_wp_error( $response ) && in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Get the base URL for this Meilisearch instance.
	 *
	 * @return string
	 */
	public function get_base_url(): string {
		return $this->base_url;
	}

	/**
	 * Set synonyms.
	 *
	 * @param string $index_name Index name.
	 * @param array  $synonyms   Synonyms.
	 * @return bool
	 */
	public function set_synonyms( string $index_name, array $synonyms ): bool {
		$response = $this->request( 'PUT', '/indexes/' . $index_name . '/settings/synonyms', $synonyms );
		return ! is_wp_error( $response ) && in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Set stop words.
	 *
	 * @param string $index_name Index name.
	 * @param array  $stop_words Stop words.
	 * @return bool
	 */
	public function set_stop_words( string $index_name, array $stop_words ): bool {
		$response = $this->request( 'PUT', '/indexes/' . $index_name . '/settings/stop-words', $stop_words );
		return ! is_wp_error( $response ) && in_array( wp_remote_retrieve_response_code( $response ), array( 200, 202 ), true );
	}

	/**
	 * Encrypt an API key for storage.
	 *
	 * @param string $key The plain API key.
	 * @return string
	 */
	public static function encrypt_key( string $key ): string {
		if ( empty( $key ) ) {
			return '';
		}
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			wss_log( __( 'OpenSSL extension is required for secure API key storage. Install php-openssl.', 'woo-smart-search' ), 'error' );
			// Store with base64 + marker so we know it's not encrypted.
			return 'plain_' . base64_encode( $key ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		}

		$encryption_key = self::get_encryption_key();
		// Random IV for each encryption — critical for AES-CBC security.
		$iv = openssl_random_pseudo_bytes( 16 );
		$encrypted = openssl_encrypt( $key, 'AES-256-CBC', $encryption_key, OPENSSL_RAW_DATA, $iv );

		if ( false === $encrypted ) {
			wss_log( __( 'Failed to encrypt API key.', 'woo-smart-search' ), 'error' );
			return '';
		}

		// Prepend IV to ciphertext so we can retrieve it on decryption.
		// Format: enc2_<base64(iv + ciphertext)>
		return 'enc2_' . base64_encode( $iv . $encrypted ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Decrypt an API key from storage.
	 *
	 * @param string $encrypted The encrypted API key.
	 * @return string
	 */
	public static function decrypt_key( string $encrypted ): string {
		if ( empty( $encrypted ) ) {
			return '';
		}

		// Format v2: enc2_<base64(iv + ciphertext)> — random IV per encryption.
		if ( strpos( $encrypted, 'enc2_' ) === 0 ) {
			if ( ! function_exists( 'openssl_decrypt' ) ) {
				wss_log( __( 'Cannot decrypt API key: OpenSSL extension is not available.', 'woo-smart-search' ), 'error' );
				return '';
			}
			$raw = base64_decode( substr( $encrypted, 5 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( strlen( $raw ) <= 16 ) {
				return '';
			}
			$iv         = substr( $raw, 0, 16 );
			$ciphertext = substr( $raw, 16 );
			$decrypted  = openssl_decrypt( $ciphertext, 'AES-256-CBC', self::get_encryption_key(), OPENSSL_RAW_DATA, $iv );
			return false !== $decrypted ? $decrypted : '';
		}

		// Legacy format: plain_ prefix (no OpenSSL fallback).
		if ( strpos( $encrypted, 'plain_' ) === 0 ) {
			return base64_decode( substr( $encrypted, 6 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		}

		// Legacy format: obf_ prefix (old XOR obfuscation).
		if ( strpos( $encrypted, 'obf_' ) === 0 ) {
			$salt = defined( 'AUTH_SALT' ) ? AUTH_SALT : 'wss-default-salt';
			$data = base64_decode( substr( $encrypted, 4 ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			return $data ^ str_repeat( substr( hash( 'sha256', $salt ), 0, 32 ), ( strlen( $data ) / 32 ) + 1 );
		}

		// Legacy format v1: base64(openssl with deterministic IV).
		if ( function_exists( 'openssl_decrypt' ) ) {
			$salt    = defined( 'AUTH_SALT' ) ? AUTH_SALT : 'wss-default-salt';
			$iv      = substr( hash( 'sha256', $salt ), 0, 16 );
			$decoded = base64_decode( $encrypted ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			$decrypted = openssl_decrypt( $decoded, 'AES-256-CBC', $salt, 0, $iv );
			return false !== $decrypted ? $decrypted : $encrypted;
		}

		wss_log( __( 'Cannot decrypt API key: OpenSSL extension is not available.', 'woo-smart-search' ), 'error' );
		return '';
	}

	/**
	 * Get the encryption key derived from WordPress salts.
	 *
	 * Uses HKDF-like derivation from AUTH_KEY + AUTH_SALT for a strong 32-byte key.
	 *
	 * @return string 32-byte binary encryption key.
	 */
	private static function get_encryption_key(): string {
		$material = '';
		if ( defined( 'AUTH_KEY' ) ) {
			$material .= AUTH_KEY;
		}
		if ( defined( 'AUTH_SALT' ) ) {
			$material .= AUTH_SALT;
		}
		if ( empty( $material ) ) {
			$material = 'wss-fallback-' . DB_NAME . DB_USER;
		}
		return hash( 'sha256', 'wss-api-key-encryption:' . $material, true );
	}

	/**
	 * Get the engine type identifier.
	 *
	 * @return string
	 */
	public function get_engine_type(): string {
		return 'meilisearch';
	}

	/**
	 * Make an HTTP request to Meilisearch.
	 *
	 * @param string     $method HTTP method.
	 * @param string     $path   API path.
	 * @param array|null $body   Request body.
	 * @return array|WP_Error
	 */
	private function request( string $method, string $path, $body = null ) {
		$args = array(
			'method'  => $method,
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $this->api_key,
			),
			'timeout' => 30,
		);
		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}
		return wp_remote_request( $this->base_url . $path, $args );
	}
}
