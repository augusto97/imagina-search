<?php
/**
 * Admin AJAX handlers.
 *
 * @package WooSmartSearch
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WSS_Admin_Ajax
 */
class WSS_Admin_Ajax {

	/**
	 * Initialize AJAX hooks.
	 */
	public function init() {
		add_action( 'wp_ajax_wss_save_settings', array( $this, 'save_settings' ) );
		add_action( 'wp_ajax_wss_test_connection', array( $this, 'test_connection' ) );
		add_action( 'wp_ajax_wss_full_sync', array( $this, 'full_sync' ) );
		add_action( 'wp_ajax_wss_sync_progress', array( $this, 'sync_progress' ) );
		add_action( 'wp_ajax_wss_run_sync_batch', array( $this, 'run_sync_batch' ) );
		add_action( 'wp_ajax_wss_clear_index', array( $this, 'clear_index' ) );
		add_action( 'wp_ajax_wss_get_logs', array( $this, 'get_logs' ) );
		add_action( 'wp_ajax_wss_clear_logs', array( $this, 'clear_logs' ) );
		add_action( 'wp_ajax_wss_export_logs', array( $this, 'export_logs' ) );
		add_action( 'wp_ajax_wss_get_index_stats', array( $this, 'get_index_stats' ) );
		add_action( 'wp_ajax_wss_get_analytics', array( $this, 'get_analytics' ) );
		add_action( 'wp_ajax_wss_get_connection_status', array( $this, 'get_connection_status' ) );
		add_action( 'wp_ajax_wss_purge_search_cache', array( $this, 'purge_search_cache' ) );
		add_action( 'wp_ajax_wss_get_cache_stats', array( $this, 'get_cache_stats' ) );
	}

	/**
	 * Verify the AJAX nonce and permissions.
	 *
	 * @return bool
	 */
	private function verify_request(): bool {
		if ( ! check_ajax_referer( 'wss_admin_nonce', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid security token.', 'woo-smart-search' ) ) );
			return false;
		}

		$required_cap = wss_is_woocommerce_active() ? 'manage_woocommerce' : 'manage_options';
		if ( ! current_user_can( $required_cap ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'woo-smart-search' ) ) );
			return false;
		}

		return true;
	}

	/**
	 * Save plugin settings.
	 */
	public function save_settings() {
		$this->verify_request();

		$settings = get_option( 'wss_settings', array() );

		// Connection details (where the stored master key is sent) can only be
		// changed by administrators, not shop managers.
		if ( ! current_user_can( 'manage_options' ) ) {
			foreach ( array( 'host', 'port', 'protocol', 'api_key', 'search_api_key', 'search_engine' ) as $locked ) {
				unset( $_POST[ $locked ] );
			}
		}

		// Custom CSS is printed on every page: require unfiltered_html.
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			unset( $_POST['custom_css'], $_POST['rp_custom_css'] );
		}

		// Connection tab fields.
		$text_fields = array(
			'host', 'port', 'protocol', 'index_name',
			'search_api_key', 'theme', 'primary_color', 'bg_color',
			'text_color', 'border_color', 'font_size', 'border_radius',
			'placeholder_text', 'custom_css', 'integration_mode',
			'synonyms', 'stop_words', 'widget_layout', 'widget_layout_mobile', 'content_source',
			'search_engine',
			// Results page appearance.
			'results_layout', 'results_layout_mobile', 'results_columns',
			'rp_card_bg', 'rp_card_border', 'rp_card_radius', 'rp_card_shadow',
			'rp_price_color', 'rp_sale_color', 'rp_badge_bg', 'rp_badge_text',
			'rp_stars_color', 'rp_button_bg', 'rp_button_text', 'rp_button_radius',
			'rp_button_hover_bg', 'rp_button_hover_text',
			'rp_sidebar_bg', 'rp_toolbar_bg', 'rp_page_bg',
			'rp_image_ratio', 'rp_image_fit', 'rp_card_gap',
			'rp_name_size', 'rp_price_size', 'rp_name_lines',
			'rp_custom_css',
		);

		foreach ( $text_fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				if ( 'custom_css' === $field || 'rp_custom_css' === $field ) {
					// Preserve newlines but strip HTML tags and potential injections.
					$settings[ $field ] = wp_strip_all_tags( wp_unslash( $_POST[ $field ] ) );
				} elseif ( 'protocol' === $field ) {
					// Only allow http or https.
					$val = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
					$settings[ $field ] = in_array( $val, array( 'http', 'https' ), true ) ? $val : 'https';
				} elseif ( 'index_name' === $field ) {
					// Alphanumeric, dashes, and underscores only.
					$settings[ $field ] = preg_replace( '/[^a-zA-Z0-9_\-]/', '', sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) );
				} else {
					$settings[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
				}
			}
		}

		// Validate search_engine field.
		if ( isset( $settings['search_engine'] ) && ! in_array( $settings['search_engine'], array( 'meilisearch', 'local' ), true ) ) {
			$settings['search_engine'] = 'meilisearch';
		}

		// Validate results_layout field.
		if ( isset( $settings['results_layout'] ) && ! in_array( $settings['results_layout'], array( 'default', 'amazon', 'temu', 'mercadolibre', 'aliexpress', 'shopify' ), true ) ) {
			$settings['results_layout'] = 'default';
		}

		// Validate results_layout_mobile field ('same' = follow desktop layout).
		if ( isset( $settings['results_layout_mobile'] ) && ! in_array( $settings['results_layout_mobile'], array( 'same', 'default', 'amazon', 'temu', 'mercadolibre', 'aliexpress', 'shopify' ), true ) ) {
			$settings['results_layout_mobile'] = 'same';
		}

		// Validate widget_layout_mobile field ('same' = follow desktop widget layout).
		if ( isset( $settings['widget_layout_mobile'] ) && ! in_array( $settings['widget_layout_mobile'], array( 'same', 'standard', 'expanded', 'compact', 'amazon', 'falabella', 'fullscreen' ), true ) ) {
			$settings['widget_layout_mobile'] = 'same';
		}

		// Handle local engine index name from its own field.
		if ( isset( $_POST['index_name_local'] ) && 'local' === ( $settings['search_engine'] ?? 'meilisearch' ) ) {
			$settings['index_name'] = preg_replace( '/[^a-zA-Z0-9_\-]/', '', sanitize_text_field( wp_unslash( $_POST['index_name_local'] ) ) );
		}

		// Handle API key encryption (with basic format validation so a
		// malformed paste fails here with a clear message instead of with a
		// cryptic error on the next sync).
		if ( isset( $_POST['api_key'] ) ) {
			$raw_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ) );
			// Never re-encrypt an already-stored (encrypted) value echoed back.
			if ( WSS_Meilisearch::is_encrypted_value( $raw_key ) ) {
				$raw_key = '';
			}
			if ( ! empty( $raw_key ) ) {
				if ( strlen( $raw_key ) < 8 || strlen( $raw_key ) > 512 || preg_match( '/\s/', $raw_key ) ) {
					wp_send_json_error( array(
						'message' => __( 'The API key looks invalid: it must be 8–512 characters with no spaces. Check that you copied it completely.', 'woo-smart-search' ),
					) );
					return;
				}
				$settings['api_key'] = WSS_Meilisearch::encrypt_key( $raw_key );
			}
		}

		// The public search key is printed in every page: make sure it can only
		// search. (A pasted admin/master key would let any visitor modify or
		// delete the index.)
		$search_key_warning = '';
		if ( isset( $_POST['search_api_key'] ) && ! empty( $settings['search_api_key'] ) && 'meilisearch' === ( $settings['search_engine'] ?? 'meilisearch' ) && ! empty( $settings['api_key'] ) ) {
			$checker = WSS_Meilisearch::create(
				array(
					'host'     => $settings['host'] ?? 'localhost',
					'port'     => $settings['port'] ?? '',
					'protocol' => $settings['protocol'] ?? 'http',
					'api_key'  => WSS_Meilisearch::decrypt_key( $settings['api_key'] ),
				)
			);
			if ( $checker ) {
				$check = $checker->check_public_key( (string) $settings['search_api_key'], (string) ( $settings['index_name'] ?? 'woo_products' ) );
				if ( 'invalid' === $check['status'] ) {
					wp_send_json_error( array( 'message' => $check['message'] ) );
					return;
				}
				$settings['search_key_status'] = $check['status'];
				if ( 'unverified' === $check['status'] ) {
					$search_key_warning = __( 'Could not verify that the Search API Key is search-only — make sure it is not an admin key.', 'woo-smart-search' );
				}
			}
		}

		// Integer fields.
		$int_fields = array( 'batch_size', 'max_autocomplete_results', 'results_per_page', 'cache_ttl', 'rate_limit', 'results_page_id', 'reindex_interval' );
		foreach ( $int_fields as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				$settings[ $field ] = absint( $_POST[ $field ] );
			}
		}

		// Bounds: reindex interval is 0 (disabled) or between 5 minutes and 7 days.
		if ( isset( $settings['reindex_interval'] ) && $settings['reindex_interval'] > 0 ) {
			$settings['reindex_interval'] = max( 5, min( 10080, $settings['reindex_interval'] ) );
		}

		// Yes/no fields — only process checkboxes when their form tab is submitted.
		// Each form has a hidden _wss_tab field to identify it.
		$submitted_tab = isset( $_POST['_wss_tab'] ) ? sanitize_text_field( wp_unslash( $_POST['_wss_tab'] ) ) : '';

		$appearance_bools = array(
			'show_image', 'show_price', 'show_category',
			'show_sku', 'show_stock', 'show_rating',
			'show_sale_badge', 'show_excerpt', 'show_author',
			'show_date', 'show_post_type', 'enable_analytics',
		);

		$search_bools = array(
			'index_out_of_stock', 'index_hidden', 'enable_facets',
			'search_by_sku', 'show_out_of_stock_results',
			// Results page visible elements.
			'rp_show_image', 'rp_show_category', 'rp_show_price',
			'rp_show_sale_badge', 'rp_show_stock', 'rp_show_rating',
			'rp_show_sku', 'rp_show_description', 'rp_show_add_to_cart',
			'rp_show_shipping', 'rp_show_sold',
		);

		$indexing_bools = array(
			'index_out_of_stock', 'index_hidden',
		);

		$synonyms_bools = array(
			'local_fuzzy',
		);

		$bool_fields = array();
		if ( 'appearance' === $submitted_tab ) {
			$bool_fields = $appearance_bools;
		} elseif ( 'search' === $submitted_tab ) {
			// Remove indexing bools from search tab (they belong to indexing tab now).
			$bool_fields = array_diff( $search_bools, $indexing_bools );
		} elseif ( 'indexing' === $submitted_tab ) {
			$bool_fields = $indexing_bools;
		} elseif ( 'synonyms' === $submitted_tab ) {
			$bool_fields = $synonyms_bools;
		}

		// Process every bool explicitly present in POST regardless of tab —
		// the Vue admin sends ALL settings with explicit yes/no values on
		// every save, so changes made in other tabs persist too. Absent
		// fields only reset to 'no' for the submitted tab (legacy checkbox
		// forms send nothing for unchecked boxes).
		$all_bools = array_unique( array_merge( $appearance_bools, $search_bools, $indexing_bools, $synonyms_bools ) );

		foreach ( $all_bools as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				$val = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
				$settings[ $field ] = ( 'yes' === $val || '1' === $val || 'true' === $val || 'on' === $val ) ? 'yes' : 'no';
			} elseif ( in_array( $field, $bool_fields, true ) ) {
				$settings[ $field ] = 'no';
			}
		}

		// Array fields — only reset when their owning tab is submitted.
		if ( isset( $_POST['exclude_categories'] ) && is_array( $_POST['exclude_categories'] ) ) {
			$settings['exclude_categories'] = array_map( 'absint', $_POST['exclude_categories'] );
		} elseif ( 'indexing' === $submitted_tab ) {
			$settings['exclude_categories'] = array();
		}

		// Dynamic taxonomy exclusions (exclude_taxonomies[taxonomy_slug][] = term_ids).
		if ( 'indexing' === $submitted_tab ) {
			if ( isset( $_POST['exclude_taxonomies'] ) && is_array( $_POST['exclude_taxonomies'] ) ) {
				$clean_tax = array();
				foreach ( $_POST['exclude_taxonomies'] as $tax_slug => $term_ids ) {
					$safe_slug = sanitize_key( $tax_slug );
					if ( is_array( $term_ids ) ) {
						$clean_tax[ $safe_slug ] = array_map( 'absint', $term_ids );
					}
				}
				$settings['exclude_taxonomies'] = $clean_tax;
			} else {
				$settings['exclude_taxonomies'] = array();
			}
			// Clean up legacy key.
			unset( $settings['exclude_wp_categories'] );
		}

		if ( isset( $_POST['custom_fields'] ) && is_array( $_POST['custom_fields'] ) ) {
			$settings['custom_fields'] = array_map( 'sanitize_text_field', wp_unslash( $_POST['custom_fields'] ) );
		} elseif ( 'indexing' === $submitted_tab ) {
			$settings['custom_fields'] = array();
		}

		if ( isset( $_POST['visible_facets'] ) && is_array( $_POST['visible_facets'] ) ) {
			$settings['visible_facets'] = array_map( 'sanitize_text_field', wp_unslash( $_POST['visible_facets'] ) );
		} elseif ( 'search' === $submitted_tab ) {
			// Only reset visible_facets when the Results Page tab is submitted with none checked.
			$settings['visible_facets'] = array();
		}

		// Content source settings.
		$content_source_changed = false;
		if ( isset( $_POST['content_source'] ) ) {
			$source = sanitize_text_field( wp_unslash( $_POST['content_source'] ) );
			if ( in_array( $source, array( 'auto', 'woocommerce', 'wordpress', 'mixed' ), true ) ) {
				$old_source = $settings['content_source'] ?? 'auto';
				if ( $old_source !== $source ) {
					$content_source_changed = true;
				}
				$settings['content_source'] = $source;
			}
		}

		if ( isset( $_POST['wp_post_types'] ) && is_array( $_POST['wp_post_types'] ) ) {
			// Public post types only (never shop_coupon, revisions, etc.).
			$public_types              = get_post_types( array( 'public' => true ) );
			$submitted_types           = array_map( 'sanitize_key', wp_unslash( $_POST['wp_post_types'] ) );
			$settings['wp_post_types'] = array_values( array_diff( array_intersect( $submitted_types, $public_types ), array( 'attachment' ) ) );
			if ( empty( $settings['wp_post_types'] ) ) {
				$settings['wp_post_types'] = array( 'post' );
			}
		} elseif ( 'content_sources' === $submitted_tab ) {
			$settings['wp_post_types'] = array( 'post' );
		}

		if ( isset( $_POST['wp_custom_fields'] ) && is_array( $_POST['wp_custom_fields'] ) ) {
			$settings['wp_custom_fields'] = array_map( 'sanitize_text_field', wp_unslash( $_POST['wp_custom_fields'] ) );
		} elseif ( 'content_sources' === $submitted_tab ) {
			$settings['wp_custom_fields'] = array();
		}

		// Translations — sanitize each string value, remove empties.
		if ( 'translations' === $submitted_tab && isset( $_POST['translations'] ) && is_array( $_POST['translations'] ) ) {
			$raw = wp_unslash( $_POST['translations'] );
			// Allowed translation keys (camelCase).
			$allowed_keys = array(
				'placeholder', 'noResults', 'viewAll', 'viewAllResults', 'error',
				'startTyping', 'products', 'results', 'content', 'categories',
				'popularSearches', 'suggestions', 'inStock', 'outOfStock', 'onBackorder',
				'clearSearch', 'close', 'searchOurStore', 'collections', 'brands',
				'relatedBrands', 'relatedCategories', 'relatedTags', 'filters', 'resultsFor',
				'noResultsPage', 'sortRelevance', 'sortPriceLow', 'sortPriceHigh',
				'sortNewest', 'sortPopular', 'sortRating', 'sortNameAZ', 'sortNameZA',
				'addToCart', 'freeShipping', 'sold',
				// Facet / filter labels.
				'tags', 'stock', 'brand', 'rating', 'price', 'priceMin', 'priceMax',
				'contentType', 'author', 'onSale', 'clearAll',
				// Results count patterns.
				'xResults', 'xProducts', 'errorLoading',
			);
			$clean = array();
			foreach ( $raw as $key => $value ) {
				if ( in_array( $key, $allowed_keys, true ) ) {
					$v = sanitize_text_field( $value );
					if ( '' !== $v ) {
						$clean[ $key ] = $v;
					}
				}
			}
			$settings['translations'] = $clean;
		}

		update_option( 'wss_settings', $settings );
		// Refresh wss_get_option()'s static cache so the code below (synonym
		// push, filterable attributes) sees the settings just saved.
		wss_get_option( 'search_engine', '', true );

		// Reschedule periodic reindex if interval changed.
		if ( isset( $_POST['reindex_interval'] ) && function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'wss_periodic_reindex', array(), 'woo-smart-search' );
		}
		// Re-check the recurring jobs on the next request.
		delete_option( 'wss_jobs_checked_at' );

		// Invalidate cached CSS variables.
		delete_transient( 'wss_css_vars_' . WSS_VERSION );

		// Reset engine singletons so they pick up new config.
		WSS_Meilisearch::reset();
		WSS_Local_Engine::reset();

		// Push synonyms / stop words to the active engine immediately when the
		// Synonyms tab is saved, so changes take effect right away without
		// waiting for a full re-sync.
		if ( 'synonyms' === $submitted_tab ) {
			$engine = wss_get_engine();
			if ( $engine ) {
				$index_name = $settings['index_name'] ?? 'woo_products';

				$syn_json = isset( $settings['synonyms'] ) ? $settings['synonyms'] : '';
				$syn_map  = ! empty( $syn_json ) ? json_decode( $syn_json, true ) : array();
				$engine->set_synonyms( $index_name, is_array( $syn_map ) ? $syn_map : array() );

				$stop_raw   = isset( $settings['stop_words'] ) ? $settings['stop_words'] : '';
				$stop_words = ! empty( $stop_raw ) ? array_filter( array_map( 'trim', explode( ',', $stop_raw ) ) ) : array();
				$engine->set_stop_words( $index_name, $stop_words );
			}
		}

		// Update Meilisearch filterable attributes (only in ecommerce mode).
		if ( wss_is_ecommerce_mode() ) {
			WSS_Product_Sync::update_filterable_attributes();
		}

		// Auto-clear index when content source changes (old documents would pollute results).
		if ( $content_source_changed ) {
			$engine = WSS_Meilisearch::get_instance();
			if ( $engine ) {
				$index_name = $settings['index_name'] ?? 'woo_products';
				$engine->delete_all_documents( $index_name );
				wss_log( __( 'Index cleared automatically due to content source change. Please run a Full Sync.', 'woo-smart-search' ), 'info' );
			}
		}

		wss_log( __( 'Settings updated', 'woo-smart-search' ), 'info' );

		$message = __( 'Settings saved successfully.', 'woo-smart-search' );
		if ( $search_key_warning ) {
			$message .= ' ' . $search_key_warning;
		}
		if ( $content_source_changed ) {
			$message .= ' ' . __( 'Content source changed — index has been cleared. Please run a Full Sync from the Indexing tab.', 'woo-smart-search' );
		}

		wp_send_json_success( array( 'message' => $message ) );
	}

	/**
	 * Test the Meilisearch connection.
	 */
	public function test_connection() {
		$this->verify_request();

		// Use form values, but fall back to saved API key when field is empty
		// (the password field is always rendered empty for security).
		$config = array(
			'host'     => isset( $_POST['host'] ) ? sanitize_text_field( wp_unslash( $_POST['host'] ) ) : '',
			'port'     => isset( $_POST['port'] ) ? sanitize_text_field( wp_unslash( $_POST['port'] ) ) : '',
			'protocol' => isset( $_POST['protocol'] ) ? sanitize_text_field( wp_unslash( $_POST['protocol'] ) ) : 'http',
		);

		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) : '';
		if ( empty( $api_key ) || WSS_Meilisearch::is_encrypted_value( $api_key ) ) {
			// The saved key is only sent to the saved server: testing another
			// host requires typing the key, so it can't be exfiltrated.
			$same_server = $config['host'] === (string) wss_get_option( 'host', '' )
				&& (string) $config['port'] === (string) wss_get_option( 'port', '' )
				&& $config['protocol'] === (string) wss_get_option( 'protocol', 'http' );
			$saved_key   = wss_get_option( 'api_key', '' );
			$api_key     = ( $same_server && ! empty( $saved_key ) ) ? WSS_Meilisearch::decrypt_key( $saved_key ) : '';
		}
		$config['api_key'] = $api_key;

		$engine = WSS_Meilisearch::create( $config );
		if ( ! $engine ) {
			wp_send_json_error( array( 'message' => __( 'Could not create Meilisearch instance.', 'woo-smart-search' ) ) );
			return;
		}

		$result = $engine->test_connection();

		if ( $result['success'] ) {
			do_action( 'wss_connection_established', 'meilisearch' );
			wss_log(
				sprintf(
					/* translators: %s: Meilisearch version */
					__( 'Connection test successful: Meilisearch v%s', 'woo-smart-search' ),
					$result['version']
				),
				'info'
			);
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( $result );
		}
	}

	/**
	 * Start full synchronization.
	 */
	public function full_sync() {
		$this->verify_request();

		// Always clean up stale flag from previous sync attempts.
		delete_option( 'wss_skip_index_configure' );

		$content_source = wss_get_content_source();

		if ( 'mixed' === $content_source ) {
			// Mixed mode: configure index with combined attributes, then sync both.
			$engine     = wss_get_engine();
			$index_name = wss_get_option( 'index_name', 'woo_products' );


			if ( $engine ) {
				$engine->create_index( $index_name );
				$this->configure_mixed_index( $engine, $index_name );
			}

			// Flag to prevent start_full_sync from overwriting the combined config.
			update_option( 'wss_skip_index_configure', true, false );

			$results = array();

			if ( wss_is_woocommerce_active() ) {
				$product_sync = new WSS_Product_Sync();
				$results[] = $product_sync->start_full_sync();
			}

			$post_sync = new WSS_Post_Sync();
			$results[] = $post_sync->start_full_sync();

			delete_option( 'wss_skip_index_configure' );

			// Run products first, then content (see complete_sync handover):
			// two concurrent chains would fight over the shared progress.
			if ( function_exists( 'as_unschedule_all_actions' ) && wss_is_woocommerce_active() ) {
				as_unschedule_all_actions( 'wss_bulk_post_sync_batch', array(), 'woo-smart-search' );
			}

			$total = 0;
			$messages = array();
			foreach ( $results as $r ) {
				$total += $r['total'] ?? 0;
				$messages[] = $r['message'] ?? '';
			}

			// Override progress with combined total so the progress bar
			// reflects ALL content, not just the last sync that overwrote it.
			update_option(
				'wss_sync_progress',
				array(
					'total'     => $total,
					'processed' => 0,
					'batches'   => 0,
					'current'   => 0,
					'status'    => 'running',
					'started'   => time(),
					'errors'    => 0,
					'mixed'     => wss_is_woocommerce_active(),
					'phase'     => 'products',
				),
				false
			);

			wp_send_json_success( array(
				'success' => true,
				'message' => implode( ' | ', array_filter( $messages ) ),
				'total'   => $total,
			) );
		} elseif ( wss_is_ecommerce_mode() ) {
			$sync = new WSS_Product_Sync();
		} else {
			$sync = new WSS_Post_Sync();
		}

		if ( isset( $sync ) ) {
			$result = $sync->start_full_sync();

			if ( $result['success'] ) {
				wp_send_json_success( $result );
			} else {
				wp_send_json_error( $result );
			}
		}
	}

	/**
	 * Configure a mixed-mode index with merged attributes from both product and post sync.
	 *
	 * @param WSS_Meilisearch $engine     The Meilisearch engine instance.
	 * @param string          $index_name The index name.
	 */
	private function configure_mixed_index( $engine, $index_name ) {
		// Product searchable attributes.
		$product_searchable = apply_filters(
			'wss_searchable_attributes',
			array( 'name', 'sku', 'all_skus', 'search_codes', 'categories', 'tags', 'brand', 'description', 'attributes_text', 'variations_text' )
		);

		// Post searchable attributes.
		$post_searchable = apply_filters(
			'wss_wp_searchable_attributes',
			array( 'name', 'description', 'full_description', 'categories', 'tags', 'taxonomies_text', 'author' )
		);

		$searchable = array_values( array_unique( array_merge( $product_searchable, $post_searchable ) ) );

		// Product filterable attributes.
		$product_filterable = apply_filters(
			'wss_filterable_attributes',
			array(
				'categories', 'category_ids', 'category_slugs', 'tags',
				'price', 'price_min', 'price_max', 'stock_status', 'on_sale',
				'featured', 'rating', 'brand', 'type', 'content_source',
			)
		);

		// Dynamically add WC product attributes as filterable.
		if ( wss_is_woocommerce_active() && function_exists( 'wc_get_attribute_taxonomies' ) ) {
			$attribute_taxonomies = wc_get_attribute_taxonomies();
			$attribute_names      = array();
			if ( ! empty( $attribute_taxonomies ) ) {
				foreach ( $attribute_taxonomies as $tax ) {
					$label               = $tax->attribute_label ? $tax->attribute_label : $tax->attribute_name;
					$product_filterable[] = 'attributes.' . $label;
					$attribute_names[]    = $label;
				}
			}
			update_option( 'wss_product_attribute_names', $attribute_names, true );
		}

		// Post filterable attributes.
		$post_filterable = apply_filters(
			'wss_wp_filterable_attributes',
			array( 'categories', 'category_ids', 'category_slugs', 'tags', 'post_type', 'author', 'content_source' )
		);

		// Dynamically add custom taxonomy keys as filterable (tax_genre, etc.).
		$wp_post_types       = wss_get_option( 'wp_post_types', array( 'post' ) );
		$excluded_taxonomies = array( 'category', 'post_tag', 'product_cat', 'product_tag', 'post_format' );
		$custom_tax_keys     = array();
		if ( ! empty( $wp_post_types ) && is_array( $wp_post_types ) ) {
			foreach ( $wp_post_types as $pt ) {
				$pt_taxonomies = get_object_taxonomies( $pt, 'objects' );
				foreach ( $pt_taxonomies as $tax_name => $tax_obj ) {
					if ( in_array( $tax_name, $excluded_taxonomies, true ) || ! $tax_obj->public ) {
						continue;
					}
					$key = 'tax_' . $tax_name;
					if ( ! in_array( $key, $custom_tax_keys, true ) ) {
						$custom_tax_keys[]  = $key;
						$post_filterable[]  = $key;
					}
				}
			}
		}

		// Dynamically add custom field keys as filterable (cf_color, etc.).
		$configured_fields = wss_get_option( 'wp_custom_fields', array() );
		$custom_cf_keys    = array();
		if ( ! empty( $configured_fields ) && is_array( $configured_fields ) ) {
			foreach ( $configured_fields as $cf_key ) {
				$prefixed         = 'cf_' . $cf_key;
				$custom_cf_keys[] = $prefixed;
				$post_filterable[] = $prefixed;
			}
		}

		$filterable = array_values( array_unique( array_merge( $product_filterable, $post_filterable ) ) );

		// Sortable: merge both sets.
		$product_sortable = array( 'price', 'price_min', 'price_max', 'date_created', 'date_modified', 'name', 'rating', 'total_sales', 'menu_order' );
		$post_sortable    = array( 'date_created', 'date_modified', 'name', 'menu_order', 'comment_count' );
		$sortable         = array_values( array_unique( array_merge( $product_sortable, $post_sortable ) ) );

		// Displayed: merge both sets.
		$product_displayed = apply_filters(
			'wss_displayed_attributes',
			array(
				'id', 'name', 'slug', 'description', 'sku', 'permalink',
				'image', 'gallery',
				'price', 'regular_price', 'sale_price', 'price_min', 'price_max',
				'on_sale', 'currency',
				'stock_status',
				'categories', 'category_slugs',
				'tags', 'brand',
				'attributes',
				'rating', 'review_count',
				'type',
				'content_source',
			)
		);

		$post_displayed = apply_filters(
			'wss_wp_displayed_attributes',
			array(
				'id', 'name', 'slug', 'description', 'permalink',
				'image', 'post_type',
				'categories', 'category_slugs',
				'tags', 'taxonomies',
				'author', 'date_created',
				'comment_count', 'content_source',
			)
		);

		$displayed = array_values( array_unique( array_merge( $product_displayed, $post_displayed, $custom_tax_keys, $custom_cf_keys ) ) );

		// Apply combined settings.
		$settings = apply_filters(
			'wss_index_settings',
			array(
				'searchableAttributes' => $searchable,
				'filterableAttributes' => $filterable,
				'sortableAttributes'   => $sortable,
				'displayedAttributes'  => $displayed,
			)
		);

		$engine->configure_index( $index_name, $settings );

		// Configure synonyms if set.
		$synonyms = wss_get_option( 'synonyms', '' );
		if ( ! empty( $synonyms ) ) {
			$synonyms_array = json_decode( $synonyms, true );
			if ( is_array( $synonyms_array ) ) {
				$engine->set_synonyms( $index_name, $synonyms_array );
			}
		}

		// Configure stop words if set.
		$stop_words = wss_get_option( 'stop_words', '' );
		if ( ! empty( $stop_words ) ) {
			$stop_words_array = array_map( 'trim', explode( ',', $stop_words ) );
			$engine->set_stop_words( $index_name, $stop_words_array );
		}
	}

	/**
	 * Get sync progress.
	 */
	public function sync_progress() {
		$this->verify_request();

		$progress = get_option( 'wss_sync_progress' );

		if ( ! $progress ) {
			wp_send_json_success(
				array(
					'status'    => 'idle',
					'total'     => 0,
					'processed' => 0,
				)
			);
			return;
		}

		wp_send_json_success( $progress );
	}

	/**
	 * Process one Full Sync batch synchronously, driven by the admin browser.
	 *
	 * The normal Full Sync chains its batches through Action Scheduler, which
	 * never runs on sites where WP-Cron / Action Scheduler is broken — the
	 * progress bar then sits at 0%. This lets the open admin page pump the
	 * batches itself, independent of cron. It takes ownership of the Action
	 * Scheduler chain (unschedules the pending batch actions) so the same page
	 * is not processed twice; batches serialize on a cross-process lock.
	 */
	public function run_sync_batch() {
		$this->verify_request();

		$progress = wss_get_sync_progress();

		if ( empty( $progress ) || 'running' !== ( $progress['status'] ?? '' ) ) {
			if ( ! empty( $progress ) ) {
				$ts                          = (int) wss_get_last_sync();
				$progress['last_sync_label'] = $ts ? date_i18n( 'Y-m-d H:i', $ts ) : '';
			}
			wp_send_json_success( ! empty( $progress ) ? $progress : array( 'status' => 'idle' ) );
			return;
		}

		// Take ownership from Action Scheduler so batches are not run twice.
		// (process_bulk_sync_batch also holds a cross-process lock and skips
		// pages another worker already handled.)
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'wss_bulk_sync_batch', array(), 'woo-smart-search' );
			as_unschedule_all_actions( 'wss_bulk_post_sync_batch', array(), 'woo-smart-search' );
		}

		$next_page      = (int) ( $progress['current'] ?? 0 ) + 1;
		$content_source = wss_get_content_source();
		$posts_phase    = ! empty( $progress['mixed'] ) && 'posts' === ( $progress['phase'] ?? '' );

		if ( ! $posts_phase && ( wss_is_ecommerce_mode() || 'mixed' === $content_source ) && class_exists( 'WSS_Product_Sync' ) ) {
			$sync = new WSS_Product_Sync();
			$sync->process_bulk_sync_batch( array( 'page' => $next_page ), false );
		} elseif ( class_exists( 'WSS_Post_Sync' ) ) {
			$sync = new WSS_Post_Sync();
			$sync->process_bulk_sync_batch( array( 'page' => $next_page ), false );
		}

		$updated = wss_get_sync_progress();
		if ( ! empty( $updated ) && 'completed' === ( $updated['status'] ?? '' ) ) {
			$ts                         = (int) wss_get_last_sync();
			$updated['last_sync_label'] = $ts ? date_i18n( 'Y-m-d H:i', $ts ) : '';
		}
		wp_send_json_success( ! empty( $updated ) ? $updated : array( 'status' => 'idle' ) );
	}

	/**
	 * Clear the search index.
	 */
	public function clear_index() {
		$this->verify_request();

		$engine = wss_get_engine();

		// Fallback for Meilisearch: try creating from saved settings if singleton failed.
		if ( ! $engine && 'meilisearch' === wss_get_option( 'search_engine', 'meilisearch' ) ) {
			$settings  = get_option( 'wss_settings', array() );
			$saved_key = isset( $settings['api_key'] ) ? $settings['api_key'] : '';
			if ( ! empty( $saved_key ) ) {
				$engine = WSS_Meilisearch::create( array(
					'host'     => isset( $settings['host'] ) ? $settings['host'] : 'localhost',
					'port'     => isset( $settings['port'] ) ? $settings['port'] : '',
					'protocol' => isset( $settings['protocol'] ) ? $settings['protocol'] : 'http',
					'api_key'  => WSS_Meilisearch::decrypt_key( $saved_key ),
				) );
			}
		}

		if ( ! $engine ) {
			wp_send_json_error( array( 'message' => __( 'Search engine is not configured.', 'woo-smart-search' ) ) );
			return;
		}

		$settings   = get_option( 'wss_settings', array() );
		$index_name = isset( $settings['index_name'] ) ? $settings['index_name'] : 'woo_products';
		$result     = $engine->delete_all_documents( $index_name );

		if ( $result ) {
			wss_log( __( 'Index cleared', 'woo-smart-search' ), 'info' );
			wp_send_json_success( array( 'message' => __( 'Index cleared successfully.', 'woo-smart-search' ) ) );
		} else {
			wp_send_json_error( array( 'message' => __( 'Failed to clear index.', 'woo-smart-search' ) ) );
		}
	}

	/**
	 * Get log entries.
	 */
	public function get_logs() {
		$this->verify_request();

		global $wpdb;

		$table  = $wpdb->prefix . 'wss_logs';
		$type   = isset( $_POST['log_type'] ) ? sanitize_text_field( wp_unslash( $_POST['log_type'] ) ) : '';
		$page   = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
		$limit  = 50;
		$offset = ( $page - 1 ) * $limit;

		$where  = '1=1';
		$params = array();

		if ( ! empty( $type ) ) {
			$where   .= ' AND type = %s';
			$params[] = $type;
		}

		if ( ! empty( $params ) ) {
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where}", $params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$logs  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d", array_merge( $params, array( $limit, $offset ) ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		} else {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$logs  = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		}

		wp_send_json_success(
			array(
				'logs'  => $logs,
				'total' => $total,
				'pages' => ceil( $total / $limit ),
				'page'  => $page,
			)
		);
	}

	/**
	 * Clear all logs.
	 */
	public function clear_logs() {
		$this->verify_request();

		global $wpdb;
		$wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}wss_logs" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		wp_send_json_success( array( 'message' => __( 'Logs cleared.', 'woo-smart-search' ) ) );
	}

	/**
	 * Export logs as CSV.
	 */
	public function export_logs() {
		$this->verify_request();

		global $wpdb;

		$table = $wpdb->prefix . 'wss_logs';
		$logs  = $wpdb->get_results( "SELECT type, message, context, created_at FROM {$table} ORDER BY created_at DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$csv_rows   = array();
		$csv_rows[] = array( 'Type', 'Message', 'Context', 'Date' );
		foreach ( $logs as $log ) {
			// Neutralise spreadsheet formulas (=, +, -, @) in exported cells.
			$csv_rows[] = array_map(
				function ( $cell ) {
					$cell = (string) $cell;
					return ( '' !== $cell && in_array( $cell[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) ? "'" . $cell : $cell;
				},
				array( $log['type'], $log['message'], $log['context'], $log['created_at'] )
			);
		}

		$csv = '';
		foreach ( $csv_rows as $row ) {
			$csv .= '"' . implode( '","', array_map( function ( $v ) { return str_replace( '"', '""', $v ); }, $row ) ) . "\"\n";
		}

		wp_send_json_success( array( 'csv' => $csv ) );
	}

	/**
	 * Get index statistics.
	 */
	public function get_index_stats() {
		$this->verify_request();

		$engine = wss_get_engine();
		if ( ! $engine ) {
			wp_send_json_error( array( 'message' => __( 'Search engine is not configured.', 'woo-smart-search' ) ) );
			return;
		}

		$index_name = wss_get_option( 'index_name', 'woo_products' );
		$stats      = $engine->get_index_stats( $index_name );

		$stats['last_sync'] = wss_get_last_sync();

		wp_send_json_success( $stats );
	}

	/**
	 * Get search analytics data.
	 *
	 * Returns top queries, zero-result queries, search volume, and CTR.
	 */
	public function get_analytics() {
		$this->verify_request();

		$analytics = new WSS_Search_Analytics();
		$period    = isset( $_POST['period'] ) ? sanitize_text_field( wp_unslash( $_POST['period'] ) ) : 'week';

		$top_queries         = $analytics->get_top_queries( 20 );
		$zero_result_queries = $analytics->get_zero_result_queries( 20 );
		$search_volume       = $analytics->get_search_volume( $period );
		$ctr                 = $analytics->get_click_through_rate();

		// Calculate totals for today, week, and month.
		$volume_today = $analytics->get_search_volume( 'today' );
		$volume_week  = $analytics->get_search_volume( 'week' );
		$volume_month = $analytics->get_search_volume( 'month' );

		$total_today = 0;
		foreach ( $volume_today as $day ) {
			$total_today += (int) $day->count;
		}

		$total_week = 0;
		foreach ( $volume_week as $day ) {
			$total_week += (int) $day->count;
		}

		$total_month = 0;
		foreach ( $volume_month as $day ) {
			$total_month += (int) $day->count;
		}

		wp_send_json_success(
			array(
				'top_queries'         => $top_queries,
				'zero_result_queries' => $zero_result_queries,
				'search_volume'       => $search_volume,
				'click_through_rate'  => $ctr,
				'totals'              => array(
					'today' => $total_today,
					'week'  => $total_week,
					'month' => $total_month,
				),
			)
		);
	}

	/**
	 * Get the current search engine connection status.
	 *
	 * Returns status (connected, error, not_configured), version, and document count.
	 */
	public function get_connection_status() {
		$this->verify_request();

		$engine_type = wss_get_option( 'search_engine', 'meilisearch' );

		// Local engine: always available.
		if ( 'local' === $engine_type ) {
			$engine     = WSS_Local_Engine::get_instance();
			$result     = $engine->test_connection();
			$index_name = wss_get_option( 'index_name', 'woo_products' );
			$stats      = $engine->get_index_stats( $index_name );
			$doc_count  = isset( $stats['numberOfDocuments'] ) ? (int) $stats['numberOfDocuments'] : 0;

			if ( ! $result['success'] ) {
				wp_send_json_success( array(
					'status'  => 'error',
					'message' => $result['message'],
				) );
				return;
			}

			wp_send_json_success( array(
				'status'         => 'connected',
				'version'        => $result['version'],
				'documents'      => $doc_count,
				'restricted_key' => false,
				'engine_type'    => 'local',
			) );
			return;
		}

		// Meilisearch engine.
		$error = get_transient( 'wss_connection_error' );
		if ( $error ) {
			wp_send_json_success( array(
				'status'  => 'error',
				'message' => $error,
			) );
			return;
		}

		$engine = WSS_Meilisearch::get_instance();

		// Fallback: if get_instance() returned null, try creating from saved settings directly.
		if ( ! $engine ) {
			$settings  = get_option( 'wss_settings', array() );
			$saved_key = isset( $settings['api_key'] ) ? $settings['api_key'] : '';

			if ( ! empty( $saved_key ) ) {
				$engine = WSS_Meilisearch::create( array(
					'host'     => isset( $settings['host'] ) ? $settings['host'] : 'localhost',
					'port'     => isset( $settings['port'] ) ? $settings['port'] : '',
					'protocol' => isset( $settings['protocol'] ) ? $settings['protocol'] : 'http',
					'api_key'  => WSS_Meilisearch::decrypt_key( $saved_key ),
				) );
			}
		}

		if ( ! $engine ) {
			wp_send_json_success( array(
				'status'  => 'not_configured',
				'message' => __( 'Meilisearch is not configured.', 'woo-smart-search' ),
			) );
			return;
		}

		$result = $engine->test_connection();
		if ( ! $result['success'] ) {
			wp_send_json_success( array(
				'status'  => 'error',
				'message' => $result['message'],
			) );
			return;
		}

		// Get document count.
		$settings   = get_option( 'wss_settings', array() );
		$index_name = isset( $settings['index_name'] ) ? $settings['index_name'] : 'woo_products';
		$stats      = $engine->get_index_stats( $index_name );
		$doc_count  = isset( $stats['numberOfDocuments'] ) ? (int) $stats['numberOfDocuments'] : 0;

		wp_send_json_success( array(
			'status'         => 'connected',
			'version'        => isset( $result['version'] ) ? $result['version'] : '',
			'documents'      => $doc_count,
			'restricted_key' => ! empty( $result['restricted_key'] ),
			'engine_type'    => 'meilisearch',
		) );
	}

	/**
	 * Purge the local search cache.
	 */
	public function purge_search_cache() {
		$this->verify_request();

		$engine = WSS_Local_Engine::get_instance();
		$engine->invalidate_cache( '', true );

		wss_log( __( 'Search cache purged manually.', 'woo-smart-search' ), 'info' );

		wp_send_json_success( array( 'message' => __( 'Search cache purged.', 'woo-smart-search' ) ) );
	}

	/**
	 * Get local search cache statistics.
	 */
	public function get_cache_stats() {
		$this->verify_request();

		$engine = WSS_Local_Engine::get_instance();
		$stats  = $engine->get_cache_stats();

		wp_send_json_success( $stats );
	}
}
