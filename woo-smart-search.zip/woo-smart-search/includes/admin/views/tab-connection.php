<?php
/**
 * Connection tab template.
 *
 * @package WooSmartSearch
 * @var array $settings Plugin settings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="wss-connection-status-indicator" class="wss-connection-indicator" style="margin-bottom: 15px; padding: 10px 15px; background: #fff; border-left: 4px solid #ccc; display: flex; align-items: center; gap: 10px;">
	<span class="wss-status-dot" style="display: inline-block; width: 12px; height: 12px; border-radius: 50%; background: #ccc;"></span>
	<span class="wss-status-text"><?php esc_html_e( 'Checking connection...', 'woo-smart-search' ); ?></span>
	<span class="wss-status-version" style="color: #666; font-style: italic;"></span>
</div>

<form id="wss-connection-form" class="wss-form">
	<input type="hidden" name="_wss_tab" value="connection" />
	<table class="form-table">
		<tr>
			<th scope="row">
				<label for="wss-search-engine"><?php esc_html_e( 'Search Engine', 'woo-smart-search' ); ?></label>
			</th>
			<td>
				<select id="wss-search-engine" name="search_engine">
					<option value="meilisearch" <?php selected( $settings['search_engine'] ?? 'meilisearch', 'meilisearch' ); ?>>
						Meilisearch (<?php esc_html_e( 'Cloud / Self-hosted', 'woo-smart-search' ); ?>)
					</option>
					<option value="local" <?php selected( $settings['search_engine'] ?? 'meilisearch', 'local' ); ?>>
						<?php esc_html_e( 'Local (MySQL)', 'woo-smart-search' ); ?>
					</option>
				</select>
				<p class="description">
					<strong>Meilisearch:</strong> <?php esc_html_e( 'Fastest option. Requires an external Meilisearch server (cloud or self-hosted). Best typo tolerance and relevance.', 'woo-smart-search' ); ?><br/>
					<strong><?php esc_html_e( 'Local:', 'woo-smart-search' ); ?></strong> <?php esc_html_e( 'Zero cost, zero dependencies. Uses an inverted index in your MySQL database. Works on any hosting. Great for stores with up to ~50,000 products.', 'woo-smart-search' ); ?>
				</p>
			</td>
		</tr>
	</table>

	<!-- Meilisearch settings (shown when engine = meilisearch) -->
	<div id="wss-meilisearch-settings" style="<?php echo ( $settings['search_engine'] ?? 'meilisearch' ) === 'local' ? 'display:none;' : ''; ?>">
	<table class="form-table">
		<tr>
			<th scope="row">
				<label for="wss-host"><?php esc_html_e( 'Host', 'woo-smart-search' ); ?></label>
			</th>
			<td>
				<input type="text" id="wss-host" name="host" value="<?php echo esc_attr( $settings['host'] ?? 'localhost' ); ?>" class="regular-text" placeholder="localhost" />
				<p class="description"><?php esc_html_e( 'Meilisearch server hostname or IP address (without protocol).', 'woo-smart-search' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="wss-port"><?php esc_html_e( 'Port', 'woo-smart-search' ); ?></label>
			</th>
			<td>
				<input type="text" id="wss-port" name="port" value="<?php echo esc_attr( $settings['port'] ?? '' ); ?>" class="small-text" placeholder="7700" />
				<p class="description"><?php esc_html_e( 'Local: 7700. Meilisearch Cloud: leave empty (uses HTTPS/443).', 'woo-smart-search' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="wss-protocol"><?php esc_html_e( 'Protocol', 'woo-smart-search' ); ?></label>
			</th>
			<td>
				<select id="wss-protocol" name="protocol">
					<option value="http" <?php selected( $settings['protocol'] ?? 'http', 'http' ); ?>>HTTP</option>
					<option value="https" <?php selected( $settings['protocol'] ?? '', 'https' ); ?>>HTTPS</option>
				</select>
				<p class="description"><?php esc_html_e( 'Use HTTPS if your Meilisearch server has SSL enabled.', 'woo-smart-search' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="wss-api-key"><?php esc_html_e( 'Admin API Key', 'woo-smart-search' ); ?></label>
			</th>
			<td>
				<input type="password" id="wss-api-key" name="api_key" value="" class="regular-text" placeholder="<?php echo ! empty( $settings['api_key'] ) ? '********' : ''; ?>" />
				<p class="description">
					<?php esc_html_e( 'Required for indexing, configuration, and statistics. Leave empty to keep current key.', 'woo-smart-search' ); ?>
				</p>
				<p class="description" style="margin-top: 4px;">
					<strong><?php esc_html_e( 'Which key to use:', 'woo-smart-search' ); ?></strong>
					<?php esc_html_e( 'Use your Master Key or the "Default Admin API Key" from Meilisearch Cloud. Do NOT use the "Default Search API Key" here — it only has search permissions and cannot index or configure.', 'woo-smart-search' ); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="wss-search-api-key"><?php esc_html_e( 'Search API Key', 'woo-smart-search' ); ?></label>
			</th>
			<td>
				<input type="text" id="wss-search-api-key" name="search_api_key" value="<?php echo esc_attr( $settings['search_api_key'] ?? '' ); ?>" class="regular-text" />
				<p class="description">
					<?php esc_html_e( 'Optional. Enables ultra-fast direct search from the browser (bypasses WordPress). Leave empty to use WordPress proxy mode.', 'woo-smart-search' ); ?>
				</p>
				<p class="description" style="margin-top: 4px;">
					<strong><?php esc_html_e( 'Which key to use:', 'woo-smart-search' ); ?></strong>
					<?php esc_html_e( 'Use the "Default Search API Key" from Meilisearch Cloud. This is a read-only key safe to expose in the browser.', 'woo-smart-search' ); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="wss-index-name"><?php esc_html_e( 'Index Name', 'woo-smart-search' ); ?></label>
			</th>
			<td>
				<input type="text" id="wss-index-name" name="index_name" value="<?php echo esc_attr( $settings['index_name'] ?? 'woo_products' ); ?>" class="regular-text" />
				<p class="description"><?php esc_html_e( 'The Meilisearch index to store product data in.', 'woo-smart-search' ); ?></p>
			</td>
		</tr>
	</table>
	</div><!-- /#wss-meilisearch-settings -->

	<!-- Local engine info (shown when engine = local) -->
	<div id="wss-local-settings" style="<?php echo ( $settings['search_engine'] ?? 'meilisearch' ) !== 'local' ? 'display:none;' : ''; ?>">
	<table class="form-table">
		<tr>
			<th scope="row"><?php esc_html_e( 'Index Name', 'woo-smart-search' ); ?></th>
			<td>
				<input type="text" name="index_name_local" value="<?php echo esc_attr( $settings['index_name'] ?? 'woo_products' ); ?>" class="regular-text" />
				<p class="description"><?php esc_html_e( 'Identifier for the local search index.', 'woo-smart-search' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Status', 'woo-smart-search' ); ?></th>
			<td>
				<p class="description" style="font-size: 13px;">
					<?php esc_html_e( 'The local engine stores an inverted index in your MySQL database. No external server is needed.', 'woo-smart-search' ); ?>
					<?php esc_html_e( 'After saving, go to the Sync tab and run a full synchronization to build the local index.', 'woo-smart-search' ); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Search Cache', 'woo-smart-search' ); ?></th>
			<td>
				<p class="description" style="margin-bottom: 8px;">
					<?php esc_html_e( 'Frequent search queries are cached for up to 5 minutes to provide near-instant responses. Cache is automatically cleared when products are updated.', 'woo-smart-search' ); ?>
				</p>
				<span id="wss-cache-stats" style="color: #666; font-style: italic;"></span>
				<button type="button" id="wss-purge-cache" class="button button-secondary" style="margin-left: 10px;">
					<?php esc_html_e( 'Purge Cache', 'woo-smart-search' ); ?>
				</button>
				<span id="wss-cache-status" style="margin-left: 8px;"></span>
			</td>
		</tr>
	</table>
	</div><!-- /#wss-local-settings -->

	<p class="submit">
		<button type="button" id="wss-test-connection" class="button button-secondary">
			<?php esc_html_e( 'Test Connection', 'woo-smart-search' ); ?>
		</button>
		<button type="submit" class="button button-primary wss-save-settings">
			<?php esc_html_e( 'Save Settings', 'woo-smart-search' ); ?>
		</button>
		<span class="wss-status-message"></span>
	</p>

	<div id="wss-connection-result" class="wss-notice" style="display:none;"></div>
</form>

<script type="text/javascript">
	jQuery( document ).ready( function( $ ) {
		function wssCheckConnectionStatus() {
			$.post( wssAdmin.ajaxUrl, {
				action: 'wss_get_connection_status',
				nonce: wssAdmin.nonce
			}, function( response ) {
				var $indicator = $( '#wss-connection-status-indicator' );
				var $dot       = $indicator.find( '.wss-status-dot' );
				var $text      = $indicator.find( '.wss-status-text' );
				var $version   = $indicator.find( '.wss-status-version' );

				if ( response.success && response.data ) {
					var data = response.data;

					if ( data.status === 'connected' ) {
						if ( data.restricted_key ) {
							$dot.css( 'background', '#ffb900' );
							$indicator.css( 'border-left-color', '#ffb900' );
							$text.html( '<?php echo esc_js( __( 'Connected', 'woo-smart-search' ) ); ?> <small style="color:#b45309;"><?php echo esc_js( __( '(restricted key — use the Master Key for full functionality)', 'woo-smart-search' ) ); ?></small>' );
						} else {
							$dot.css( 'background', '#46b450' );
							$indicator.css( 'border-left-color', '#46b450' );
							$text.text( '<?php echo esc_js( __( 'Connected', 'woo-smart-search' ) ); ?>' );
						}
						var info = '';
						if ( data.version ) {
							info += ( data.engine_type === 'local' ? '' : 'v' ) + data.version;
						}
						if ( typeof data.documents !== 'undefined' ) {
							info += ( info ? ', ' : '' ) + data.documents + ' <?php echo esc_js( __( 'documents', 'woo-smart-search' ) ); ?>';
						}
						$version.text( info );
					} else if ( data.status === 'not_configured' ) {
						$dot.css( 'background', '#ffb900' );
						$indicator.css( 'border-left-color', '#ffb900' );
						$text.text( '<?php echo esc_js( __( 'Not Configured', 'woo-smart-search' ) ); ?>' );
						$version.text( '' );
					} else {
						$dot.css( 'background', '#dc3232' );
						$indicator.css( 'border-left-color', '#dc3232' );
						$text.text( '<?php echo esc_js( __( 'Error', 'woo-smart-search' ) ); ?>' );
						$version.text( data.message || '' );
					}
				}
			} );
		}

		wssCheckConnectionStatus();

		// Toggle Meilisearch / Local settings visibility.
		$( '#wss-search-engine' ).on( 'change', function () {
			var engine = $( this ).val();
			if ( engine === 'local' ) {
				$( '#wss-meilisearch-settings' ).hide();
				$( '#wss-local-settings' ).show();
				wssLoadCacheStats();
			} else {
				$( '#wss-meilisearch-settings' ).show();
				$( '#wss-local-settings' ).hide();
			}
		} );

		// Load cache stats on page load if local engine is active.
		function wssLoadCacheStats() {
			$.post( wssAdmin.ajaxUrl, {
				action: 'wss_get_cache_stats',
				nonce: wssAdmin.nonce
			}, function( response ) {
				if ( response.success && response.data ) {
					$( '#wss-cache-stats' ).text(
						response.data.entries + ' <?php echo esc_js( __( 'cached queries', 'woo-smart-search' ) ); ?>' +
						' (' + response.data.size + ')'
					);
				}
			} );
		}

		if ( $( '#wss-search-engine' ).val() === 'local' ) {
			wssLoadCacheStats();
		}

		// Purge cache button.
		$( '#wss-purge-cache' ).on( 'click', function() {
			var $btn    = $( this );
			var $status = $( '#wss-cache-status' );
			$btn.prop( 'disabled', true );
			$status.text( '<?php echo esc_js( __( 'Purging...', 'woo-smart-search' ) ); ?>' );

			$.post( wssAdmin.ajaxUrl, {
				action: 'wss_purge_search_cache',
				nonce: wssAdmin.nonce
			}, function( response ) {
				$btn.prop( 'disabled', false );
				if ( response.success ) {
					$status.text( '<?php echo esc_js( __( 'Cache purged!', 'woo-smart-search' ) ); ?>' ).css( 'color', '#46b450' );
					wssLoadCacheStats();
				} else {
					$status.text( '<?php echo esc_js( __( 'Error purging cache.', 'woo-smart-search' ) ); ?>' ).css( 'color', '#dc3232' );
				}
				setTimeout( function() { $status.text( '' ); }, 3000 );
			} );
		} );
	} );
</script>
