<?php
/**
 * Product Synchronization.
 *
 * Handles full (bulk) and incremental product sync with Meilisearch.
 * Uses paginated WP_Query and Action Scheduler chain pattern for bulk sync.
 * Never loads all products into memory at once.
 *
 * @package WooSmartSearch
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WSS_Product_Sync
 */
class WSS_Product_Sync {

	/**
	 * Initialize sync hooks.
	 */
	public function init() {
		// Incremental sync hooks.
		add_action( 'woocommerce_update_product', array( $this, 'schedule_product_update' ), 10, 1 );
		add_action( 'woocommerce_new_product', array( $this, 'schedule_product_update' ), 10, 1 );
		add_action( 'before_delete_post', array( $this, 'schedule_product_delete' ) );
		add_action( 'wp_trash_post', array( $this, 'schedule_product_delete' ) );
		add_action( 'untrash_post', array( $this, 'schedule_product_update' ) );
		add_action( 'woocommerce_product_set_stock', array( $this, 'on_stock_change' ) );
		add_action( 'woocommerce_product_set_stock_status', array( $this, 'on_stock_status_change' ), 10, 3 );
		add_action( 'woocommerce_variation_set_stock', array( $this, 'on_variation_stock_change' ) );
		add_action( 'set_object_terms', array( $this, 'on_terms_change' ), 10, 4 );
		add_action( 'transition_post_status', array( $this, 'on_status_change' ), 10, 3 );

		// ACF / custom meta hooks.
		add_action( 'updated_post_meta', array( $this, 'on_meta_change' ), 10, 4 );
		add_action( 'added_post_meta', array( $this, 'on_meta_change' ), 10, 4 );

		// WooCommerce REST API hooks (products updated via API, mobile apps, etc.).
		add_action( 'woocommerce_rest_insert_product_object', array( $this, 'on_rest_product_update' ), 10, 1 );
		add_action( 'woocommerce_rest_insert_product_variation', array( $this, 'on_rest_variation_update' ), 10, 1 );

		// WooCommerce scheduled sales (sale prices activated/deactivated by cron).
		add_action( 'woocommerce_scheduled_sales', array( $this, 'on_scheduled_sales' ) );

		// WooCommerce bulk edit (admin bulk actions).
		add_action( 'woocommerce_product_bulk_edit_save', array( $this, 'on_bulk_edit_save' ), 10, 1 );
		add_action( 'woocommerce_product_quick_edit_save', array( $this, 'on_bulk_edit_save' ), 10, 1 );

		// WooCommerce CSV import completion.
		add_action( 'woocommerce_product_import_inserted_product_object', array( $this, 'on_import_product' ), 10, 1 );

		// WP All Import — fires after each record is saved.
		add_action( 'pmxi_saved_post', array( $this, 'on_wp_all_import_saved' ), 10, 1 );
		// WP All Import — fires after the entire import is complete.
		add_action( 'pmxi_after_xml_import', array( $this, 'on_wp_all_import_complete' ), 10, 0 );

		// WooCommerce Advanced Bulk Edit (WCABE). Its bulk save writes with direct
		// SQL and does NOT fire the standard product hooks, but it fires
		// wcabe_product_save_completed with the product ID for every row saved
		// (verified in v6.2). Queue that product — the queue drains at request
		// end, so the change appears in search right away.
		add_action( 'wcabe_product_save_completed', array( $this, 'on_advanced_bulk_edit_saved' ), 10, 1 );

		// ATUM Inventory / any plugin that fires this generic WC hook.
		add_action( 'woocommerce_product_object_updated_props', array( $this, 'on_product_props_updated' ), 10, 1 );

		// Catch-all: any save_post on product type, low priority so other
		// plugins finish their meta writes first.
		add_action( 'save_post_product', array( $this, 'on_save_post_product' ), 99, 3 );

		// Bulk sync action (chain pattern).
		add_action( 'wss_bulk_sync_batch', array( $this, 'process_bulk_sync_batch' ), 10, 1 );

		// Periodic re-indexation — the ultimate safety net for changes that
		// bypass ALL WordPress hooks (direct SQL, ERPs, WP-CLI, etc.).
		add_action( 'wss_periodic_reindex', array( $this, 'run_periodic_reindex' ) );
	}

	/**
	 * Schedule a product update in the sync queue.
	 *
	 * @param int $product_id Product ID.
	 */
	public function schedule_product_update( $product_id ) {
		$product_id = absint( $product_id );

		if ( ! $product_id || 'product' !== get_post_type( $product_id ) ) {
			return;
		}

		WSS_Sync_Queue::add( $product_id, 'update' );
	}

	/**
	 * Handle save_post_product hook.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update.
	 */
	public function on_save_post_product( $post_id, $post, $update ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		$this->schedule_product_update( $post_id );
	}

	/**
	 * Schedule a product deletion from the index.
	 *
	 * @param int $post_id Post ID.
	 */
	public function schedule_product_delete( $post_id ) {
		if ( 'product' !== get_post_type( $post_id ) ) {
			return;
		}

		WSS_Sync_Queue::add( absint( $post_id ), 'delete' );
	}

	/**
	 * Handle stock changes.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function on_stock_change( $product ) {
		$this->schedule_product_update( $product->get_id() );
	}

	/**
	 * Handle stock status changes.
	 *
	 * @param int        $product_id   Product ID.
	 * @param string     $stock_status New stock status.
	 * @param WC_Product $product      Product object.
	 */
	public function on_stock_status_change( $product_id, $stock_status, $product ) {
		$this->schedule_product_update( absint( $product_id ) );
	}

	/**
	 * Handle variation stock changes.
	 *
	 * @param WC_Product $variation Variation object.
	 */
	public function on_variation_stock_change( $variation ) {
		$parent_id = $variation->get_parent_id();

		if ( $parent_id ) {
			$this->schedule_product_update( $parent_id );
		}
	}

	/**
	 * Handle taxonomy term changes.
	 *
	 * @param int    $object_id Object ID.
	 * @param array  $terms     Terms.
	 * @param array  $tt_ids    Term taxonomy IDs.
	 * @param string $taxonomy  Taxonomy.
	 */
	public function on_terms_change( $object_id, $terms, $tt_ids, $taxonomy ) {
		$tracked_taxonomies = array( 'product_cat', 'product_tag', 'product_brand', 'pwb-brand' );

		if ( in_array( $taxonomy, $tracked_taxonomies, true ) ) {
			if ( 'product' === get_post_type( $object_id ) ) {
				$this->schedule_product_update( $object_id );
			}
		}
	}

	/**
	 * Handle post status transitions.
	 *
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Post object.
	 */
	public function on_status_change( $new_status, $old_status, $post ) {
		if ( 'product' !== $post->post_type ) {
			return;
		}

		if ( 'publish' === $new_status ) {
			$this->schedule_product_update( $post->ID );
		} elseif ( 'publish' === $old_status && 'publish' !== $new_status ) {
			$this->schedule_product_delete( $post->ID );
		}
	}

	/**
	 * Handle post meta changes for ACF and custom fields.
	 *
	 * Only triggers a sync if the changed meta key is in the configured
	 * custom_fields list and the post is a product.
	 *
	 * @param int    $meta_id    Meta ID.
	 * @param int    $object_id  Object ID.
	 * @param string $meta_key   Meta key.
	 * @param mixed  $meta_value Meta value.
	 */
	public function on_meta_change( $meta_id, $object_id, $meta_key, $meta_value ) {
		if ( 'product' !== get_post_type( $object_id ) ) {
			return;
		}

		// Only react to configured custom fields.
		$configured_fields = wss_get_option( 'custom_fields', array() );

		if ( empty( $configured_fields ) || ! is_array( $configured_fields ) ) {
			return;
		}

		// Check direct match or ACF internal key (prefixed with underscore).
		$is_tracked = in_array( $meta_key, $configured_fields, true );

		if ( ! $is_tracked ) {
			// ACF stores a reference key as _fieldname.
			$unprefixed = ltrim( $meta_key, '_' );
			$is_tracked = in_array( $unprefixed, $configured_fields, true );
		}

		if ( $is_tracked ) {
			$this->schedule_product_update( $object_id );
		}
	}

	/**
	 * Handle WooCommerce REST API product updates.
	 *
	 * Catches products updated via REST API, mobile apps, external integrations.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function on_rest_product_update( $product ) {
		if ( $product && method_exists( $product, 'get_id' ) ) {
			$this->schedule_product_update( $product->get_id() );
		}
	}

	/**
	 * Handle WooCommerce REST API variation updates.
	 *
	 * Re-indexes the parent product when a variation changes.
	 *
	 * @param WC_Product_Variation $variation Variation object.
	 */
	public function on_rest_variation_update( $variation ) {
		if ( $variation && method_exists( $variation, 'get_parent_id' ) ) {
			$parent_id = $variation->get_parent_id();
			if ( $parent_id ) {
				$this->schedule_product_update( $parent_id );
			}
		}
	}

	/**
	 * Handle WooCommerce scheduled sales.
	 *
	 * When WooCommerce cron activates/deactivates scheduled sale prices,
	 * re-index all affected products.
	 */
	public function on_scheduled_sales() {
		global $wpdb;

		// Find products whose sale just started or ended (modified in the last 2 minutes by the cron).
		$recently_modified = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'product' AND post_status = 'publish'
				AND post_modified_gmt >= %s",
				gmdate( 'Y-m-d H:i:s', time() - 120 )
			)
		);

		foreach ( $recently_modified as $product_id ) {
			WSS_Sync_Queue::add( absint( $product_id ), 'update' );
		}
	}

	/**
	 * Handle WooCommerce bulk edit and quick edit saves.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function on_bulk_edit_save( $product ) {
		if ( $product && method_exists( $product, 'get_id' ) ) {
			$this->schedule_product_update( $product->get_id() );
		}
	}

	/**
	 * Handle WooCommerce CSV import product insertion.
	 *
	 * @param WC_Product $product Imported product object.
	 */
	public function on_import_product( $product ) {
		if ( $product && method_exists( $product, 'get_id' ) ) {
			$this->schedule_product_update( $product->get_id() );
		}
	}

	/**
	 * WP All Import — fires after each record is saved.
	 *
	 * @param int $post_id Imported post ID.
	 */
	public function on_wp_all_import_saved( $post_id ) {
		if ( 'product' === get_post_type( $post_id ) ) {
			WSS_Sync_Queue::add( absint( $post_id ), 'update' );
		}
	}

	/**
	 * WP All Import — fires when the entire import is complete. Useful
	 * for catching any items that slipped through individual hooks.
	 */
	public function on_wp_all_import_complete() {
		WSS_Sync_Queue::add_wake_up();
	}

	/**
	 * WooCommerce Advanced Bulk Edit — fires once per product after a bulk save.
	 *
	 * WCABE writes with direct SQL and does not fire the standard product hooks,
	 * so this per-product action (wcabe_product_save_completed, verified in v6.2)
	 * is how we learn a product changed. Handles both products and variations
	 * (a variation re-indexes its parent).
	 *
	 * @param int $product_id The saved product (or variation) ID.
	 */
	public function on_advanced_bulk_edit_saved( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id ) {
			return;
		}

		$post_type = get_post_type( $product_id );

		if ( 'product' === $post_type ) {
			$this->schedule_product_update( $product_id );
		} elseif ( 'product_variation' === $post_type ) {
			$parent_id = wp_get_post_parent_id( $product_id );
			if ( $parent_id ) {
				$this->schedule_product_update( $parent_id );
			}
		}
	}

	/**
	 * WooCommerce product props updated — fires from WC core and some
	 * inventory/ERP plugins (ATUM, TradeGecko connectors, etc.).
	 *
	 * @param WC_Product $product Product object.
	 */
	public function on_product_props_updated( $product ) {
		if ( $product && method_exists( $product, 'get_id' ) ) {
			$this->schedule_product_update( $product->get_id() );
		}
	}

	/**
	 * Run periodic re-indexation.
	 *
	 * Finds products that may be out of sync (modified after last sync)
	 * and re-queues them for indexing. Acts as a safety net for changes
	 * that bypassed WordPress hooks (direct DB updates, external APIs, etc.).
	 */
	public function run_periodic_reindex() {
		global $wpdb;

		$last_reindex = (int) get_option( 'wss_last_periodic_reindex', 0 );
		$cutoff       = $last_reindex > 0 ? gmdate( 'Y-m-d H:i:s', $last_reindex ) : gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS );

		// 1) Products whose post row was modified (covers title, status,
		//    slug, description, and any plugin that calls wp_update_post).
		$stale_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'product' AND post_status = 'publish'
				AND post_modified_gmt > %s
				ORDER BY post_modified_gmt ASC
				LIMIT 500",
				$cutoff
			)
		);

		// 2) Products whose meta was changed (covers direct-DB price/stock
		//    updates from ERPs, WP All Import, bulk-edit plugins, etc.).
		//    WooCommerce stores a _last_stock_change timestamp on stock
		//    updates and _price_last_change in some versions, but the most
		//    reliable check is looking at the postmeta table directly for
		//    any row modified after our cutoff by checking the meta_id
		//    auto-increment (larger ID = newer row).
		$last_meta_id = (int) get_option( 'wss_last_periodic_reindex_meta_id', 0 );
		if ( $last_meta_id > 0 ) {
			$meta_stale_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"SELECT DISTINCT p.ID
					FROM {$wpdb->postmeta} pm
					INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
					WHERE p.post_type = 'product' AND p.post_status = 'publish'
					AND pm.meta_id > %d
					AND pm.meta_key IN ('_price','_regular_price','_sale_price','_stock','_stock_status','_sku','_sale_price_dates_from','_sale_price_dates_to')
					ORDER BY pm.meta_id ASC
					LIMIT 500",
					$last_meta_id
				)
			);

			if ( ! empty( $meta_stale_ids ) ) {
				$stale_ids = array_unique( array_merge( $stale_ids ?: array(), $meta_stale_ids ) );
			}
		}

		// Store the current max meta_id for next run's comparison.
		$current_max_meta_id = (int) $wpdb->get_var( "SELECT MAX(meta_id) FROM {$wpdb->postmeta}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( $current_max_meta_id > 0 ) {
			update_option( 'wss_last_periodic_reindex_meta_id', $current_max_meta_id, false );
		}

		if ( ! empty( $stale_ids ) ) {
			foreach ( $stale_ids as $product_id ) {
				WSS_Sync_Queue::add( absint( $product_id ), 'update' );
			}

			wss_log(
				sprintf(
					/* translators: %d: number of products queued */
					__( 'Periodic re-index: queued %d products for sync.', 'woo-smart-search' ),
					count( $stale_ids )
				),
				'info'
			);
		}

		update_option( 'wss_last_periodic_reindex', time(), false );

		// Prune orphaned index entries, but at most once every 6 hours to
		// avoid the full index scan on every short reindex interval.
		$last_prune = (int) get_option( 'wss_last_orphan_prune', 0 );
		if ( time() - $last_prune > 6 * HOUR_IN_SECONDS ) {
			$pruned = self::prune_orphans();
			update_option( 'wss_last_orphan_prune', time(), false );
			if ( $pruned > 0 ) {
				wss_log(
					sprintf(
						/* translators: %d: number of orphans removed */
						__( 'Periodic prune: removed %d orphaned index entries.', 'woo-smart-search' ),
						$pruned
					),
					'info'
				);
			}
		}
	}

	/**
	 * Start a full bulk synchronization.
	 *
	 * Uses a paginated approach: counts total products first, then schedules
	 * the first batch. Each batch schedules the next one (chain pattern).
	 *
	 * @return array Status info.
	 */
	public function start_full_sync(): array {
		$engine = wss_get_engine();

		if ( ! $engine ) {
			return array(
				'success' => false,
				'message' => __( 'Search engine not configured.', 'woo-smart-search' ),
			);
		}

		$index_name = wss_get_option( 'index_name', 'woo_products', true );

		// Create index if it does not exist.
		$created = $engine->create_index( $index_name );
		if ( ! $created ) {
			wss_log( sprintf( 'Failed to create index "%s". Sync aborted.', $index_name ), 'error' );
			return array(
				'success' => false,
				'message' => __( 'Failed to create Meilisearch index. Check connection settings.', 'woo-smart-search' ),
			);
		}

		// Configure index settings (skip if mixed mode already configured combined settings).
		if ( ! get_option( 'wss_skip_index_configure' ) ) {
			$configured = $this->configure_index_settings( $engine, $index_name );
			if ( ! $configured ) {
				wss_log( 'Index configuration failed. Sync will proceed but may have issues.', 'warning' );
			}
		}

		// Count total products using paginated query.
		$count_args             = $this->get_product_query_args();
		$count_args['return']   = 'ids';
		$count_args['paginate'] = true;
		$count_args['limit']    = 1;
		$count_args['page']     = 1;

		$total  = 0;
		$result = wc_get_products( $count_args );

		if ( is_object( $result ) && isset( $result->total ) ) {
			$total = (int) $result->total;
		}

		// Fallback: direct DB count if paginated query fails.
		if ( 0 === $total ) {
			global $wpdb;
			$total = (int) $wpdb->get_var(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish'"
			);
		}

		if ( 0 === $total ) {
			return array(
				'success' => true,
				'message' => __( 'No products to sync.', 'woo-smart-search' ),
				'total'   => 0,
			);
		}

		$batch_size    = (int) wss_get_option( 'batch_size', 100 );
		$total_batches = (int) ceil( $total / $batch_size );

		// Store progress via update_option for persistent tracking.
		update_option(
			'wss_sync_progress',
			array(
				'total'     => $total,
				'processed' => 0,
				'batches'   => $total_batches,
				'current'   => 0,
				'status'    => 'running',
				'started'   => time(),
				'errors'    => 0,
			),
			false
		);

		do_action( 'wss_before_full_sync' );

		wss_log(
			sprintf(
				/* translators: %d: total number of products */
				__( 'Starting full sync of %d products', 'woo-smart-search' ),
				$total
			),
			'info'
		);

		// Schedule the first batch. Each batch will schedule the next (chain pattern).
		$batch_args = array(
			'page' => 1,
		);

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action(
				time(),
				'wss_bulk_sync_batch',
				array( $batch_args ),
				'woo-smart-search'
			);
		} else {
			// Fallback: process the first batch immediately.
			$this->process_bulk_sync_batch( $batch_args );
		}

		return array(
			'success' => true,
			'message' => sprintf(
				/* translators: 1: total products 2: number of batches */
				__( 'Sync started: %1$d products in %2$d batches', 'woo-smart-search' ),
				$total,
				$total_batches
			),
			'total'   => $total,
			'batches' => $total_batches,
		);
	}

	/**
	 * Process a single bulk sync batch and schedule the next one.
	 *
	 * Uses paginated WP_Query via wc_get_products with a page parameter
	 * to fetch only one batch of products at a time. After processing,
	 * schedules the next batch via Action Scheduler (chain pattern).
	 *
	 * @param array $batch_args Batch arguments containing 'page'.
	 */
	public function process_bulk_sync_batch( $batch_args ) {
		$engine = wss_get_engine();

		if ( ! $engine ) {
			self::mark_sync_failed( __( 'Search engine not available during batch processing.', 'woo-smart-search' ) );
			return;
		}

		$page       = isset( $batch_args['page'] ) ? (int) $batch_args['page'] : 1;
		$batch_size = (int) wss_get_option( 'batch_size', 100 );
		$index_name = wss_get_option( 'index_name', 'woo_products' );

		// Fetch one page of product IDs.
		$query_args           = $this->get_product_query_args();
		$query_args['return'] = 'ids';
		$query_args['limit']  = $batch_size;
		$query_args['page']   = $page;

		$product_ids = wc_get_products( $query_args );

		if ( empty( $product_ids ) ) {
			// No more products; mark sync as completed.
			self::complete_sync();
			return;
		}

		$documents = array();
		$errors    = 0;

		$index_hidden = ( 'yes' === wss_get_option( 'index_hidden', 'no' ) );

		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );

			if ( ! $product ) {
				++$errors;
				continue;
			}

			// Skip hidden products unless "Index Hidden" is checked.
			if ( ! $index_hidden && 'hidden' === $product->get_catalog_visibility() ) {
				continue;
			}

			$should_index = apply_filters( 'wss_should_index_product', true, $product );

			if ( ! $should_index ) {
				continue;
			}

			$doc = WSS_Product_Transformer::transform( $product );

			if ( ! empty( $doc ) ) {
				$documents[] = $doc;
			}
		}

		$batch_failed = false;

		if ( ! empty( $documents ) ) {
			$result = $engine->index_documents( $index_name, $documents );

			if ( empty( $result['success'] ) ) {
				wss_log(
					sprintf(
						/* translators: 1: page number 2: error message */
						__( 'Batch page %1$d failed: %2$s', 'woo-smart-search' ),
						$page,
						isset( $result['message'] ) ? $result['message'] : 'Unknown error'
					),
					'error'
				);
				$errors      += count( $documents );
				$batch_failed = true;
			} else {
				foreach ( $documents as $doc ) {
					do_action( 'wss_product_indexed', $doc['id'], $doc );
				}
			}
		}

		// Update progress + circuit breaker: abort after 3 consecutive failed
		// batches instead of queueing hundreds of doomed jobs while the engine
		// is down.
		$progress = get_option( 'wss_sync_progress', array() );

		if ( ! empty( $progress ) ) {
			$progress['processed']            += count( $product_ids );
			$progress['current']               = $page;
			$progress['errors']               += $errors;
			$progress['consecutive_failures']  = $batch_failed
				? ( (int) ( $progress['consecutive_failures'] ?? 0 ) ) + 1
				: 0;

			update_option( 'wss_sync_progress', $progress, false );

			if ( $progress['consecutive_failures'] >= 3 ) {
				$progress['status'] = 'failed';
				update_option( 'wss_sync_progress', $progress, false );
				wss_log( __( 'Bulk sync aborted: 3 consecutive batch failures (engine unavailable?).', 'woo-smart-search' ), 'error' );
				return;
			}
		}

		// Schedule next batch (chain pattern).
		$next_page  = $page + 1;
		$next_args  = array( 'page' => $next_page );

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action(
				time() + 5,
				'wss_bulk_sync_batch',
				array( $next_args ),
				'woo-smart-search'
			);
		} else {
			// Fallback: process next batch immediately.
			$this->process_bulk_sync_batch( $next_args );
		}
	}

	/**
	 * Mark sync as completed and fire completion hooks.
	 */
	private static function complete_sync() {
		$progress = get_option( 'wss_sync_progress', array() );

		if ( empty( $progress ) ) {
			return;
		}

		// Remove orphaned index entries (products deleted/unpublished since
		// the last sync) before marking complete.
		$pruned = self::prune_orphans();

		$progress['status']   = 'completed';
		$progress['finished'] = time();
		$progress['pruned']   = $pruned;

		update_option( 'wss_sync_progress', $progress, false );

		do_action( 'wss_after_full_sync', $progress['processed'] );

		wss_log(
			sprintf(
				/* translators: 1: processed count 2: error count 3: pruned count */
				__( 'Full sync completed: %1$d products processed, %2$d errors, %3$d orphans removed', 'woo-smart-search' ),
				$progress['processed'],
				$progress['errors'],
				$pruned
			),
			$progress['errors'] > 0 ? 'warning' : 'info'
		);

		wss_update_option( 'last_sync', time() );
	}

	/**
	 * Remove orphaned documents from the index.
	 *
	 * Compares every document ID in the index against the set of posts that
	 * SHOULD be indexed (published products and/or configured post types).
	 * Anything in the index but not in that set is a leftover from a deleted
	 * or unpublished item and gets removed.
	 *
	 * @return int Number of orphaned documents removed.
	 */
	public static function prune_orphans(): int {
		global $wpdb;

		$engine = wss_get_engine();
		if ( ! $engine || ! method_exists( $engine, 'get_all_document_ids' ) ) {
			return 0;
		}

		$index_name   = wss_get_option( 'index_name', 'woo_products' );
		$indexed_ids  = $engine->get_all_document_ids( $index_name );
		if ( empty( $indexed_ids ) ) {
			return 0;
		}

		// Build the set of IDs that legitimately belong in the index.
		$content_source = wss_get_content_source();
		$is_ecommerce   = wss_is_ecommerce_mode();
		$is_mixed       = 'mixed' === $content_source;

		$valid_ids = array();

		if ( $is_ecommerce || $is_mixed ) {
			$product_ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish'" // phpcs:ignore WordPress.DB.PreparedSQL
			);
			$valid_ids = array_merge( $valid_ids, array_map( 'intval', $product_ids ) );
		}

		if ( ! $is_ecommerce || $is_mixed ) {
			$post_types = class_exists( 'WSS_Post_Sync' ) ? WSS_Post_Sync::get_configured_post_types() : array( 'post' );
			if ( ! empty( $post_types ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
				$post_ids     = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->prepare(
						"SELECT ID FROM {$wpdb->posts} WHERE post_type IN ({$placeholders}) AND post_status = 'publish'", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						...$post_types
					)
				);
				$valid_ids = array_merge( $valid_ids, array_map( 'intval', $post_ids ) );
			}
		}

		$valid_set = array_flip( $valid_ids );
		$orphans   = array();

		foreach ( $indexed_ids as $doc_id ) {
			if ( ! isset( $valid_set[ $doc_id ] ) ) {
				$orphans[] = $doc_id;
			}
		}

		// Safety guard: if the "valid" set is empty (e.g., a transient DB
		// hiccup), do NOT wipe the whole index — bail out instead.
		if ( empty( $valid_ids ) ) {
			return 0;
		}

		foreach ( $orphans as $doc_id ) {
			$engine->delete_document( $index_name, (string) $doc_id );
		}

		return count( $orphans );
	}

	/**
	 * Mark sync as failed.
	 *
	 * @param string $message Error message.
	 */
	private static function mark_sync_failed( string $message ) {
		$progress = get_option( 'wss_sync_progress', array() );

		if ( ! empty( $progress ) ) {
			$progress['status']   = 'failed';
			$progress['finished'] = time();

			update_option( 'wss_sync_progress', $progress, false );
		}

		wss_log( $message, 'error' );
	}

	/**
	 * Configure the index settings on Meilisearch.
	 *
	 * @param WSS_Meilisearch $engine     Meilisearch instance.
	 * @param string          $index_name Index name.
	 */
	public function configure_index_settings( $engine, $index_name ): bool {
		$searchable = apply_filters(
			'wss_searchable_attributes',
			array( 'name', 'sku', 'all_skus', 'search_codes', 'categories', 'tags', 'brand', 'description', 'attributes_text', 'variations_text' )
		);

		$filterable = apply_filters(
			'wss_filterable_attributes',
			array(
				'categories',
				'category_ids',
				'category_slugs',
				'tags',
				'price',
				'price_min',
				'price_max',
				'stock_status',
				'on_sale',
				'featured',
				'rating',
				'brand',
				'type',
				'content_source',
			)
		);

		// Dynamically add product attributes as filterable (attributes.Color, attributes.Size, etc.).
		$attribute_taxonomies = wc_get_attribute_taxonomies();
		$attribute_names      = array();
		if ( ! empty( $attribute_taxonomies ) ) {
			foreach ( $attribute_taxonomies as $tax ) {
				$label             = $tax->attribute_label ? $tax->attribute_label : $tax->attribute_name;
				$filterable[]      = 'attributes.' . $label;
				$attribute_names[] = $label;
			}
		}
		// Store the attribute names for frontend facet requests.
		update_option( 'wss_product_attribute_names', $attribute_names, true );

		// In mixed or WordPress-only mode, add WordPress-specific fields.
		$content_source = wss_get_content_source();
		$is_mixed       = 'mixed' === $content_source;
		$is_wp_only     = ! wss_is_ecommerce_mode();

		if ( $is_mixed || $is_wp_only ) {
			$filterable[] = 'post_type';
			$filterable[] = 'author';

			// Add searchable fields from WordPress content.
			$searchable = array_values( array_unique( array_merge( $searchable, array( 'full_description', 'taxonomies_text', 'author' ) ) ) );

			// Custom taxonomy keys (tax_genre, tax_topic, etc.).
			$wp_post_types       = class_exists( 'WSS_Post_Sync' ) ? WSS_Post_Sync::get_configured_post_types() : array( 'post' );
			$excluded_taxonomies = array( 'category', 'post_tag', 'product_cat', 'product_tag', 'post_format' );
			foreach ( $wp_post_types as $pt ) {
				$pt_taxonomies = get_object_taxonomies( $pt, 'objects' );
				foreach ( $pt_taxonomies as $tax_name => $tax_obj ) {
					if ( in_array( $tax_name, $excluded_taxonomies, true ) || ! $tax_obj->public ) {
						continue;
					}
					$key = 'tax_' . $tax_name;
					if ( ! in_array( $key, $filterable, true ) ) {
						$filterable[] = $key;
					}
				}
			}

			// Custom field keys (cf_color, cf_size, etc.).
			$wp_custom_fields = wss_get_option( 'wp_custom_fields', array() );
			if ( ! empty( $wp_custom_fields ) && is_array( $wp_custom_fields ) ) {
				foreach ( $wp_custom_fields as $cf_key ) {
					$prefixed = 'cf_' . $cf_key;
					if ( ! in_array( $prefixed, $filterable, true ) ) {
						$filterable[] = $prefixed;
					}
				}
			}
		}

		$filterable = array_values( array_unique( $filterable ) );

		$sortable = array(
			'price',
			'price_min',
			'price_max',
			'date_created',
			'date_modified',
			'name',
			'rating',
			'total_sales',
			'menu_order',
		);

		// Displayed attributes — only expose safe fields to frontend direct search.
		// Sensitive fields (stock_quantity, total_sales, custom_fields, etc.) are excluded.
		$displayed = apply_filters(
			'wss_displayed_attributes',
			array(
				'id', 'name', 'slug', 'description', 'sku', 'permalink',
				'image', 'gallery',
				'price', 'regular_price', 'sale_price', 'price_min', 'price_max',
				'on_sale', 'currency',
				'stock_status',
				'categories', 'category_slugs',
				'tags', 'brand',
				'attributes',
				'rating', 'review_count',
				'type',
				'content_source',
			)
		);

		// In mixed or WordPress-only mode, also display WP-specific fields.
		if ( $is_mixed || $is_wp_only ) {
			$displayed = array_values( array_unique( array_merge( $displayed, array(
				'post_type', 'author', 'date_created', 'comment_count', 'taxonomies',
			) ) ) );
		}

		$settings = apply_filters(
			'wss_index_settings',
			array(
				'searchableAttributes'  => $searchable,
				'filterableAttributes'  => $filterable,
				'sortableAttributes'    => $sortable,
				'displayedAttributes'   => $displayed,
			)
		);

		$result = $engine->configure_index( $index_name, $settings );
		if ( ! $result ) {
			return false;
		}

		// Configure synonyms if set.
		$synonyms = wss_get_option( 'synonyms', '' );

		if ( ! empty( $synonyms ) ) {
			$synonyms_array = json_decode( $synonyms, true );

			if ( is_array( $synonyms_array ) ) {
				$engine->set_synonyms( $index_name, $synonyms_array );
			}
		}

		// Configure stop words if set.
		$stop_words = wss_get_option( 'stop_words', '' );

		if ( ! empty( $stop_words ) ) {
			$stop_words_array = array_map( 'trim', explode( ',', $stop_words ) );
			$engine->set_stop_words( $index_name, $stop_words_array );
		}

		return true;
	}

	/**
	 * Update only the filterable attributes on Meilisearch.
	 *
	 * This can be called without a full re-sync to register new
	 * product attributes as filterable facets.
	 *
	 * @return bool True on success.
	 */
	public static function update_filterable_attributes(): bool {
		$engine = wss_get_engine();
		if ( ! $engine ) {
			return false;
		}

		$index_name = wss_get_option( 'index_name', 'woo_products' );

		$filterable = apply_filters(
			'wss_filterable_attributes',
			array(
				'categories',
				'category_ids',
				'category_slugs',
				'tags',
				'price',
				'price_min',
				'price_max',
				'stock_status',
				'on_sale',
				'featured',
				'rating',
				'brand',
				'type',
				'content_source',
			)
		);

		// Add product attributes.
		if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
			$taxonomies = wc_get_attribute_taxonomies();
			if ( ! empty( $taxonomies ) ) {
				foreach ( $taxonomies as $tax ) {
					$label        = $tax->attribute_label ? $tax->attribute_label : $tax->attribute_name;
					$filterable[] = 'attributes.' . $label;
				}
			}
		}

		// In mixed or WordPress-only mode, add WordPress-specific fields.
		$content_source = wss_get_content_source();
		$is_mixed       = 'mixed' === $content_source;
		$is_wp_only     = ! wss_is_ecommerce_mode();

		if ( $is_mixed || $is_wp_only ) {
			$filterable[] = 'post_type';
			$filterable[] = 'author';

			// Custom taxonomy keys.
			$wp_post_types       = class_exists( 'WSS_Post_Sync' ) ? WSS_Post_Sync::get_configured_post_types() : array( 'post' );
			$excluded_taxonomies = array( 'category', 'post_tag', 'product_cat', 'product_tag', 'post_format' );
			foreach ( $wp_post_types as $pt ) {
				$pt_taxonomies = get_object_taxonomies( $pt, 'objects' );
				foreach ( $pt_taxonomies as $tax_name => $tax_obj ) {
					if ( in_array( $tax_name, $excluded_taxonomies, true ) || ! $tax_obj->public ) {
						continue;
					}
					$key = 'tax_' . $tax_name;
					if ( ! in_array( $key, $filterable, true ) ) {
						$filterable[] = $key;
					}
				}
			}

			// Custom field keys.
			$wp_custom_fields = wss_get_option( 'wp_custom_fields', array() );
			if ( ! empty( $wp_custom_fields ) && is_array( $wp_custom_fields ) ) {
				foreach ( $wp_custom_fields as $cf_key ) {
					$prefixed = 'cf_' . $cf_key;
					if ( ! in_array( $prefixed, $filterable, true ) ) {
						$filterable[] = $prefixed;
					}
				}
			}
		}

		$filterable = array_values( array_unique( $filterable ) );

		$result = $engine->set_filterable_attributes( $index_name, $filterable );

		// Also ensure displayed attributes are set for safe direct frontend search.
		$displayed = apply_filters(
			'wss_displayed_attributes',
			array(
				'id', 'name', 'slug', 'description', 'sku', 'permalink',
				'image', 'gallery',
				'price', 'regular_price', 'sale_price', 'price_min', 'price_max',
				'on_sale', 'currency',
				'stock_status',
				'categories', 'category_slugs',
				'tags', 'brand',
				'attributes',
				'rating', 'review_count',
				'type',
				'content_source',
			)
		);

		// In mixed or WordPress-only mode, also display WP-specific fields.
		if ( $is_mixed || $is_wp_only ) {
			$displayed = array_values( array_unique( array_merge( $displayed, array(
				'post_type', 'author', 'date_created', 'comment_count', 'taxonomies',
			) ) ) );
		}

		$engine->set_displayed_attributes( $index_name, $displayed );

		return $result;
	}

	/**
	 * Ensure Meilisearch filterable attributes include product attributes.
	 *
	 * Runs once per plugin version to keep the index settings in sync
	 * without requiring a full re-sync.
	 */
	public static function maybe_update_filterable_attributes() {
		$version_key = 'wss_filterable_attrs_version';
		if ( get_option( $version_key, '' ) === WSS_VERSION ) {
			return;
		}

		if ( self::update_filterable_attributes() ) {
			update_option( $version_key, WSS_VERSION, true );
		}
	}

	/**
	 * Get the WC_Product_Query arguments for syncing.
	 *
	 * @return array
	 */
	private function get_product_query_args(): array {
		$args = array(
			'status'  => 'publish',
			'orderby' => 'ID',
			'order'   => 'ASC',
		);

		// Visibility filter: only exclude products set to "hidden" in WooCommerce.
		// Note: we intentionally do NOT set 'visibility' => 'visible' because it
		// can exclude products whose visibility term is unset (common in imports/demos).
		// Instead we filter out hidden products after retrieval in process_bulk_sync_batch.
		// When "Index Hidden" is checked, no visibility filter is applied at all.

		// Stock filter.
		if ( 'yes' !== wss_get_option( 'index_out_of_stock', 'yes' ) ) {
			$args['stock_status'] = 'instock';
		}

		// Category exclusion.
		$exclude_cats = wss_get_option( 'exclude_categories', array() );

		if ( ! empty( $exclude_cats ) ) {
			// Get all category slugs except the excluded ones.
			$included_cats = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'fields'     => 'slugs',
					'hide_empty' => false,
					'exclude'    => $exclude_cats,
				)
			);

			// Only apply filter if there are remaining categories to include.
			if ( ! is_wp_error( $included_cats ) && ! empty( $included_cats ) ) {
				$args['category'] = $included_cats;
			}
		}

		return apply_filters( 'wss_product_query_args', $args );
	}

	/**
	 * Sync a single product immediately.
	 *
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	/**
	 * Decide whether a product currently qualifies to live in the index.
	 *
	 * Applies the SAME rules as the full sync (published, in stock when
	 * "index out of stock" is off, not hidden when "index hidden" is off, and
	 * not in an excluded category). The full sync enforces these through its
	 * WC_Product_Query, but the incremental path used to check only the publish
	 * status — so a product that went out of stock (or was hidden, or moved to
	 * an excluded category) while still published was re-indexed instead of
	 * removed, and lingered in the index forever. Centralizing the rule here
	 * lets the incremental path remove it the moment it stops qualifying.
	 *
	 * @param WC_Product $product Product object.
	 * @return bool
	 */
	private function should_index_product( $product ): bool {
		if ( ! $product || ! method_exists( $product, 'get_id' ) ) {
			return false;
		}

		// Must be published.
		if ( 'publish' !== get_post_status( $product->get_id() ) ) {
			return false;
		}

		// Respect "index out of stock" — mirror the full sync, which keeps only
		// stock_status = 'instock'.
		if ( 'yes' !== wss_get_option( 'index_out_of_stock', 'yes' ) && 'instock' !== $product->get_stock_status() ) {
			return false;
		}

		// Respect "index hidden".
		if ( 'yes' !== wss_get_option( 'index_hidden', 'no' ) && 'hidden' === $product->get_catalog_visibility() ) {
			return false;
		}

		// Respect excluded categories.
		$exclude_cats = wss_get_option( 'exclude_categories', array() );
		if ( ! empty( $exclude_cats ) && is_array( $exclude_cats ) ) {
			$product_cats = $product->get_category_ids();
			if ( ! empty( $product_cats ) && array_intersect( array_map( 'absint', $product_cats ), array_map( 'absint', $exclude_cats ) ) ) {
				return false;
			}
		}

		return true;
	}

	public function sync_single_product( int $product_id ): bool {
		$engine = wss_get_engine();

		if ( ! $engine ) {
			return false;
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return false;
		}

		$index_name = wss_get_option( 'index_name', 'woo_products' );

		// Check if product should be indexed (publish + stock + visibility +
		// category rules, matching the full sync). If it no longer qualifies it
		// is removed from the index below.
		$should_index = $this->should_index_product( $product );
		$should_index = apply_filters( 'wss_should_index_product', $should_index, $product );

		if ( ! $should_index ) {
			$engine->delete_document( $index_name, (string) $product_id );
			do_action( 'wss_product_removed', $product_id );
			return true;
		}

		$document = WSS_Product_Transformer::transform( $product );
		$result   = $engine->index_documents( $index_name, array( $document ) );

		if ( ! empty( $result['success'] ) ) {
			do_action( 'wss_product_indexed', $product_id, $document );
			return true;
		}

		do_action( 'wss_sync_error', $result, $product_id );
		return false;
	}

	/**
	 * Delete a single product from the index.
	 *
	 * @param int $product_id Product ID.
	 * @return bool
	 */
	public function delete_single_product( int $product_id ): bool {
		$engine = wss_get_engine();

		if ( ! $engine ) {
			return false;
		}

		$index_name = wss_get_option( 'index_name', 'woo_products' );
		$result     = $engine->delete_document( $index_name, (string) $product_id );

		if ( $result ) {
			do_action( 'wss_product_removed', $product_id );
		}

		return $result;
	}
}
