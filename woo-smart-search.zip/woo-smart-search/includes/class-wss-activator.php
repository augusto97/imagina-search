<?php
/**
 * Plugin activator.
 *
 * @package WooSmartSearch
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WSS_Activator
 */
class WSS_Activator {

	/**
	 * Run on plugin activation.
	 */
	public static function activate() {
		self::create_tables();
		self::set_default_options();
		self::maybe_create_results_page();

		// Create local search engine tables.
		WSS_Local_Engine::create_tables();

		flush_rewrite_rules();
		set_transient( 'wss_activation_redirect', true, 30 );
	}

	/**
	 * Create custom database tables.
	 *
	 * Note: dbDelta() needs plain "CREATE TABLE name" statements. With
	 * "CREATE TABLE IF NOT EXISTS" it parses every table name as "IF", so only
	 * the last statement survived and wss_logs / wss_sync_queue were never
	 * created on fresh installs. Each table now gets its own dbDelta() call.
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$tables = array(
			"CREATE TABLE {$wpdb->prefix}wss_logs (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			type varchar(20) NOT NULL DEFAULT 'info',
			message text NOT NULL,
			context longtext,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY type (type),
			KEY created_at (created_at)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}wss_sync_queue (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			product_id bigint(20) NOT NULL,
			action varchar(20) NOT NULL DEFAULT 'update',
			priority int(11) NOT NULL DEFAULT 0,
			scheduled_at datetime NOT NULL,
			processed_at datetime DEFAULT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			PRIMARY KEY  (id),
			KEY product_id (product_id),
			KEY status (status),
			KEY scheduled_at (scheduled_at)
			) {$charset_collate};",

			"CREATE TABLE {$wpdb->prefix}wss_search_log (
			id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			query varchar(255) NOT NULL DEFAULT '',
			results_count int(11) NOT NULL DEFAULT 0,
			clicked_product_id bigint(20) UNSIGNED DEFAULT NULL,
			ip_address varchar(45) NOT NULL DEFAULT '',
			user_agent varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY idx_query (query(191)),
			KEY idx_created_at (created_at),
			KEY idx_results_count (results_count)
			) {$charset_collate};",
		);

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		foreach ( $tables as $sql ) {
			dbDelta( $sql );
		}

		update_option( 'wss_db_version', WSS_VERSION );
	}

	/**
	 * Create/upgrade tables when the plugin was updated without re-activation
	 * (e.g. uploading a new ZIP), since the activation hook doesn't run then.
	 */
	public static function maybe_upgrade() {
		if ( get_option( 'wss_db_version' ) === WSS_VERSION ) {
			return;
		}
		self::create_tables();
		if ( class_exists( 'WSS_Local_Engine' ) ) {
			WSS_Local_Engine::create_tables();
		}

		// Queue rows from older versions: `priority` (the retry counter)
		// defaulted to 10, so the first failure exhausted all retries, and
		// scheduled_at was stored in local time (the queue now uses UTC).
		global $wpdb;
		$table = $wpdb->prefix . 'wss_sync_queue';
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET priority = 0, scheduled_at = %s WHERE status = 'pending'", current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Set default plugin options.
	 */
	private static function set_default_options() {
		$defaults = array(
			'host'                      => 'localhost',
			'port'                      => '',
			'protocol'                  => 'http',
			'api_key'                   => '',
			'search_api_key'            => '',
			'index_name'                => 'woo_products',
			'batch_size'                => 100,
			'index_out_of_stock'        => 'yes',
			'index_hidden'              => 'no',
			'exclude_categories'        => array(),
			'custom_fields'             => array(),
			'max_autocomplete_results'  => 8,
			'results_per_page'          => 20,
			'enable_facets'             => 'yes',
			'visible_facets'            => array( 'categories', 'price', 'stock', 'attributes' ),
			'search_by_sku'             => 'yes',
			'show_out_of_stock_results' => 'yes',
			'integration_mode'          => 'replace',
			'theme'                     => 'light',
			'primary_color'             => '#2563eb',
			'bg_color'                  => '#ffffff',
			'text_color'                => '#1f2937',
			'border_color'              => '#e5e7eb',
			'highlight_bg'              => '#fef3c7',
			'highlight_text'            => '#92400e',
			'font_size'                 => '14',
			'border_radius'             => '8',
			'show_image'                => 'yes',
			'show_price'                => 'yes',
			'show_category'             => 'yes',
			'show_sku'                  => 'no',
			'show_stock'                => 'yes',
			'show_rating'               => 'no',
			'show_sale_badge'           => 'yes',
			'placeholder_text'          => '',
			'custom_css'                => '',
			'cache_ttl'                 => 300,
			'rate_limit'                => 30,
			'synonyms'                  => '',
			'stop_words'                => '',
			'enable_analytics'          => 'yes',
			'results_page_id'           => 0,
			// WordPress content display settings.
			'show_excerpt'              => 'yes',
			'show_author'               => 'yes',
			'show_date'                 => 'yes',
			'show_post_type'            => 'no',
			// Content source settings.
			'content_source'            => 'auto',
			'wp_post_types'             => array( 'post' ),
			'wp_custom_fields'          => array(),
			'search_engine'             => 'meilisearch',
			'reindex_interval'          => 360,
			'exclude_taxonomies'        => array(),
			'translations'              => array(),
			// Results page appearance defaults.
			'results_layout'            => 'default',
			'results_layout_mobile'     => 'same',
			'widget_layout_mobile'      => 'same',
			'results_columns'           => '3',
			'rp_card_bg'                => '#ffffff',
			'rp_card_border'            => '#e5e7eb',
			'rp_card_radius'            => '8',
			'rp_card_shadow'            => 'medium',
			'rp_price_color'            => '#1f2937',
			'rp_sale_color'             => '#dc2626',
			'rp_badge_bg'               => '#ef4444',
			'rp_badge_text'             => '#ffffff',
			'rp_stars_color'            => '#f59e0b',
			'rp_button_bg'              => '#2563eb',
			'rp_button_text'            => '#ffffff',
			'rp_button_hover_bg'        => '#1d4ed8',
			'rp_button_hover_text'      => '#ffffff',
			'rp_button_radius'          => '8',
			'rp_sidebar_bg'             => '#ffffff',
			'rp_toolbar_bg'             => '#ffffff',
			'rp_page_bg'               => 'transparent',
			'rp_image_ratio'            => '1:1',
			'rp_image_fit'              => 'cover',
			'rp_card_gap'               => '20',
			'rp_name_size'              => '14',
			'rp_price_size'             => '16',
			'rp_name_lines'             => '2',
			'rp_custom_css'             => '',
			// Results page visible elements.
			'rp_show_image'             => 'yes',
			'rp_show_category'          => 'yes',
			'rp_show_price'             => 'yes',
			'rp_show_sale_badge'        => 'yes',
			'rp_show_stock'             => 'yes',
			'rp_show_rating'            => 'yes',
			'rp_show_sku'               => 'no',
			'rp_show_description'       => 'no',
			'rp_show_add_to_cart'       => 'no',
			'rp_show_shipping'          => 'no',
			'rp_show_sold'              => 'no',
		);

		$existing = get_option( 'wss_settings', array() );
		if ( empty( $existing ) ) {
			update_option( 'wss_settings', $defaults );
		}
	}

	/**
	 * Create the search results page if it doesn't exist yet.
	 *
	 * Works like WooCommerce's auto-created Cart/Checkout/My Account pages.
	 */
	private static function maybe_create_results_page() {
		$settings = get_option( 'wss_settings', array() );

		// Already configured.
		if ( ! empty( $settings['results_page_id'] ) && get_post_status( $settings['results_page_id'] ) ) {
			return;
		}

		// Check if a page with the shortcode already exists.
		$existing = get_posts(
			array(
				'post_type'      => 'page',
				's'              => '[woo_smart_search_results]',
				'posts_per_page' => 1,
				'post_status'    => array( 'publish', 'draft', 'private' ),
				'fields'         => 'ids',
			)
		);

		if ( ! empty( $existing ) ) {
			$settings['results_page_id'] = $existing[0];
			update_option( 'wss_settings', $settings );
			return;
		}

		// Create the page.
		$page_id = wp_insert_post(
			array(
				'post_title'   => __( 'Search Results', 'woo-smart-search' ),
				'post_content' => '[woo_smart_search_results]',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_name'    => 'product-search-results',
			)
		);

		if ( $page_id && ! is_wp_error( $page_id ) ) {
			$settings['results_page_id'] = $page_id;
			update_option( 'wss_settings', $settings );
		}
	}
}
