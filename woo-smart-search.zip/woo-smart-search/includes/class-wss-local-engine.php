<?php
/**
 * Local Search Engine (MySQL-based inverted index).
 *
 * Provides a zero-dependency search engine that stores an inverted index
 * in custom WordPress tables. Uses tokenization + TF-IDF scoring for
 * relevance-ranked full-text search without requiring an external service.
 *
 * @package WooSmartSearch
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WSS_Local_Engine
 */
class WSS_Local_Engine implements WSS_Search_Engine {

	/**
	 * Singleton instance.
	 *
	 * @var WSS_Local_Engine|null
	 */
	private static $instance = null;

	/**
	 * Index settings cache.
	 *
	 * @var array
	 */
	private $index_settings = array();

	/**
	 * Stop words list.
	 *
	 * @var array
	 */
	private $stop_words = array();

	/**
	 * Synonyms map.
	 *
	 * @var array
	 */
	private $synonyms = array();

	/**
	 * Whether typo-tolerant (fuzzy) matching is enabled as a fallback.
	 *
	 * @var bool
	 */
	private $fuzzy_enabled = true;

	/**
	 * In-memory result cache for the current request.
	 *
	 * @var array
	 */
	private $memory_cache = array();

	/**
	 * Search cache generation (see invalidate_cache()).
	 *
	 * @var int|null
	 */
	private $cache_gen = null;

	/**
	 * Default cache TTL in seconds (5 minutes).
	 */
	const CACHE_TTL = 300;

	/**
	 * Document fields stripped from search hits (used for matching/filtering
	 * only, never rendered by the widget or the results page).
	 */
	const PRIVATE_FIELDS = array(
		'search_codes',
		'full_description',
		'stock_quantity',
		'custom_fields',
		'attributes_text',
		'variations_text',
		'variation_skus',
		'all_skus',
		'visibility',
		'menu_order',
		'weight',
		'dimensions',
		'gallery',
	);

	/**
	 * Get the singleton instance.
	 *
	 * @return WSS_Local_Engine
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->load_settings();
		}
		return self::$instance;
	}

	/**
	 * Reset the singleton.
	 */
	public static function reset() {
		self::$instance = null;
	}

	/**
	 * Load index settings from database.
	 */
	private function load_settings() {
		$this->index_settings = get_option( 'wss_local_index_settings', array() );

		// Fold stop words so they match accent-normalized tokens.
		$stop_words       = get_option( 'wss_local_stop_words', array() );
		$this->stop_words = is_array( $stop_words ) ? array_map( array( $this, 'fold_term' ), $stop_words ) : array();

		// Fold synonym keys so lookups work against accent-normalized query tokens.
		$synonyms        = get_option( 'wss_local_synonyms', array() );
		$this->synonyms  = array();
		if ( is_array( $synonyms ) ) {
			foreach ( $synonyms as $key => $values ) {
				$folded_key = $this->fold_term( (string) $key );
				if ( '' === $folded_key ) {
					continue;
				}
				$this->synonyms[ $folded_key ] = is_array( $values ) ? $values : array( $values );
			}
		}

		// Typo tolerance is on unless explicitly disabled in the main settings.
		$main                = get_option( 'wss_settings', array() );
		$this->fuzzy_enabled = ! is_array( $main ) || ! isset( $main['local_fuzzy'] ) || 'no' !== $main['local_fuzzy'];
	}

	/**
	 * Get the engine type.
	 *
	 * @return string
	 */
	public function get_engine_type(): string {
		return 'local';
	}

	/**
	 * Test the connection (always succeeds for local engine).
	 *
	 * @return array
	 */
	public function test_connection(): array {
		global $wpdb;

		$table = $wpdb->prefix . 'wss_index_documents';
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( ! $exists ) {
			// Auto-create tables if missing (e.g. engine switched without reactivation).
			self::create_tables();

			// Re-check after creation.
			$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			if ( ! $exists ) {
				return array(
					'success' => false,
					'message' => __( 'Could not create local search index tables. Check database permissions.', 'woo-smart-search' ),
					'version' => '',
				);
			}
		}

		return array(
			'success' => true,
			'message' => __( 'Local search engine is ready.', 'woo-smart-search' ),
			'version' => 'Local ' . WSS_VERSION,
		);
	}

	/**
	 * Create the index (tables already exist from activation, this is a no-op).
	 *
	 * @param string $index_name Index name.
	 * @return bool
	 */
	public function create_index( string $index_name ): bool {
		self::create_tables();
		return true;
	}

	/**
	 * Delete an index (clear all data for the given index).
	 *
	 * @param string $index_name Index name.
	 * @return bool
	 */
	public function delete_index( string $index_name ): bool {
		return $this->delete_all_documents( $index_name );
	}

	/**
	 * Get index statistics.
	 *
	 * @param string $index_name Index name.
	 * @return array
	 */
	public function get_index_stats( string $index_name ): array {
		global $wpdb;

		$table = $wpdb->prefix . 'wss_index_documents';
		$count = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE index_name = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$index_name
			)
		);

		return array(
			'numberOfDocuments' => $count,
			'isIndexing'        => false,
		);
	}

	/**
	 * Configure index settings.
	 *
	 * @param string $index_name Index name.
	 * @param array  $settings   Settings.
	 * @return bool
	 */
	public function configure_index( string $index_name, array $settings ): bool {
		$this->index_settings[ $index_name ] = $settings;
		update_option( 'wss_local_index_settings', $this->index_settings );
		return true;
	}

	/**
	 * Set filterable attributes for an index.
	 *
	 * @param string $index_name Index name.
	 * @param array  $attributes Filterable attribute names.
	 * @return bool
	 */
	public function set_filterable_attributes( string $index_name, array $attributes ): bool {
		if ( ! isset( $this->index_settings[ $index_name ] ) ) {
			$this->index_settings[ $index_name ] = array();
		}
		$this->index_settings[ $index_name ]['filterableAttributes'] = $attributes;
		update_option( 'wss_local_index_settings', $this->index_settings );
		return true;
	}

	/**
	 * Set sortable attributes for an index.
	 *
	 * @param string $index_name Index name.
	 * @param array  $attributes Sortable attribute names.
	 * @return bool
	 */
	public function set_sortable_attributes( string $index_name, array $attributes ): bool {
		if ( ! isset( $this->index_settings[ $index_name ] ) ) {
			$this->index_settings[ $index_name ] = array();
		}
		$this->index_settings[ $index_name ]['sortableAttributes'] = $attributes;
		update_option( 'wss_local_index_settings', $this->index_settings );
		return true;
	}

	/**
	 * Set displayed attributes for an index.
	 *
	 * @param string $index_name Index name.
	 * @param array  $attributes Displayed attribute names.
	 * @return bool
	 */
	public function set_displayed_attributes( string $index_name, array $attributes ): bool {
		if ( ! isset( $this->index_settings[ $index_name ] ) ) {
			$this->index_settings[ $index_name ] = array();
		}
		$this->index_settings[ $index_name ]['displayedAttributes'] = $attributes;
		update_option( 'wss_local_index_settings', $this->index_settings );
		return true;
	}

	/**
	 * Index documents into the local inverted index.
	 *
	 * @param string $index_name Index name.
	 * @param array  $documents  Documents to index.
	 * @return array
	 */
	public function index_documents( string $index_name, array $documents ): array {
		global $wpdb;

		$docs_table     = $wpdb->prefix . 'wss_index_documents';
		$terms_table    = $wpdb->prefix . 'wss_index_terms';
		$postings_table = $wpdb->prefix . 'wss_index_postings';

		// Invalidate search cache when documents change.
		$this->invalidate_cache( $index_name );

		$settings    = isset( $this->index_settings[ $index_name ] ) ? $this->index_settings[ $index_name ] : array();
		$searchable  = isset( $settings['searchableAttributes'] ) ? (array) $settings['searchableAttributes'] : array( 'name', 'description' );

		// Safety net: always index the core identity/code fields when present,
		// even if the stored index config is stale. Index settings saved before
		// 6.19.0 have 'sku'/'all_skus' but not 'search_codes', which silently
		// dropped SKU-fragment search (exact SKU still matched via 'sku', but a
		// fragment like "551", which only lives in search_codes, did not). Fields
		// absent from a document are skipped by the empty() check below anyway.
		foreach ( array( 'name', 'sku', 'all_skus', 'search_codes' ) as $core_field ) {
			if ( ! in_array( $core_field, $searchable, true ) ) {
				$searchable[] = $core_field;
			}
		}

		$indexed     = 0;

		foreach ( $documents as $doc ) {
			if ( ! isset( $doc['id'] ) ) {
				continue;
			}

			$doc_id = (int) $doc['id'];

			// Upsert the document JSON.
			$existing = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"SELECT id FROM {$docs_table} WHERE index_name = %s AND doc_id = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$index_name,
					$doc_id
				)
			);

			$doc_json = wp_json_encode( $doc, JSON_UNESCAPED_UNICODE );

			if ( $existing ) {
				$wpdb->update( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$docs_table,
					array(
						'doc_data'   => $doc_json,
						'indexed_at' => current_time( 'mysql' ),
					),
					array( 'id' => $existing ),
					array( '%s', '%s' ),
					array( '%d' )
				);
				// Clear old postings for re-indexing.
				$wpdb->delete( $postings_table, array( 'doc_id' => $doc_id, 'index_name' => $index_name ), array( '%d', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			} else {
				$wpdb->insert( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$docs_table,
					array(
						'index_name' => $index_name,
						'doc_id'     => $doc_id,
						'doc_data'   => $doc_json,
						'indexed_at' => current_time( 'mysql' ),
					),
					array( '%s', '%d', '%s', '%s' )
				);
			}

			// Build inverted index from searchable fields.
			// Name and SKU matches weigh more than description/category matches.
			$field_weights = array(
				'name'     => 3,
				'sku'      => 3,
				'all_skus' => 2,
			);
			$all_tokens    = array();
			foreach ( $searchable as $field ) {
				$value = $this->extract_field_value( $doc, $field );
				if ( empty( $value ) ) {
					continue;
				}
				$weight = $field_weights[ $field ] ?? 1;
				$tokens = $this->tokenize( $value );
				foreach ( $tokens as $token ) {
					if ( ! isset( $all_tokens[ $token ] ) ) {
						$all_tokens[ $token ] = 0;
					}
					$all_tokens[ $token ] += $weight;
				}
			}

			// Also index the human-readable filterable values (categories,
			// brands, attributes…) as searchable words. Machine values are
			// skipped: filters read the document JSON, and words like "simple"
			// or "instock" matched every product of that type/status.
			$filterable = isset( $settings['filterableAttributes'] ) ? $settings['filterableAttributes'] : array();
			$machine    = array( 'type', 'stock_status', 'content_source', 'post_type', 'on_sale', 'featured', 'visibility', 'rating', 'price', 'price_min', 'price_max', 'category_ids', 'category_slugs', 'date_created', 'date_modified', 'id' );
			foreach ( $filterable as $field ) {
				if ( in_array( $field, $machine, true ) ) {
					continue;
				}
				$value = $this->extract_field_value( $doc, $field );
				if ( ! empty( $value ) ) {
					$tokens = $this->tokenize( $value );
					foreach ( $tokens as $token ) {
						if ( ! isset( $all_tokens[ $token ] ) ) {
							$all_tokens[ $token ] = 0;
						}
						++$all_tokens[ $token ];
					}
				}
			}

			// Expand synonyms.
			$synonym_tokens = array();
			foreach ( array_keys( $all_tokens ) as $token ) {
				if ( isset( $this->synonyms[ $token ] ) ) {
					foreach ( $this->synonyms[ $token ] as $syn ) {
						$syn_lower = $this->fold_term( $syn );
						if ( ! isset( $all_tokens[ $syn_lower ] ) && ! isset( $synonym_tokens[ $syn_lower ] ) ) {
							$synonym_tokens[ $syn_lower ] = 1;
						}
					}
				}
			}
			// '+' keeps numeric-string keys ("551", "0065"); array_merge() renumbered
			// them to 0, 1, 2…, so purely numeric terms (SKU fragments) were never
			// indexed under their real value.
			$all_tokens = $all_tokens + $synonym_tokens;

			if ( empty( $all_tokens ) ) {
				continue;
			}

			// Total tokens for TF calculation.
			$total_tokens = array_sum( $all_tokens );

			// Insert terms and postings in bulk (one lookup + one multi-row
			// insert per document instead of 2-3 queries per term).
			$term_ids = $this->get_term_ids( array_map( 'strval', array_keys( $all_tokens ) ) );
			$rows     = array();
			$values   = array();

			foreach ( $all_tokens as $token => $count ) {
				$token = (string) $token;
				if ( empty( $term_ids[ $token ] ) ) {
					continue;
				}
				$rows[] = '(%s, %d, %d, %f)';
				array_push( $values, $index_name, (int) $term_ids[ $token ], $doc_id, $count / max( $total_tokens, 1 ) );
			}

			foreach ( array_chunk( $rows, 500 ) as $i => $chunk ) {
				$chunk_values = array_slice( $values, $i * 500 * 4, count( $chunk ) * 4 );
				$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
					$wpdb->prepare(
						"INSERT INTO {$postings_table} (index_name, term_id, doc_id, tf) VALUES " . implode( ',', $chunk ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
						$chunk_values
					)
				);
			}

			++$indexed;
		}

		return array(
			'success' => true,
			'indexed' => $indexed,
		);
	}

	/**
	 * Sort document IDs by a document field ("price:asc", "name:desc", …).
	 *
	 * Relevance order is kept for ties (stable), and documents missing the
	 * field go last.
	 *
	 * @param string $index_name Index name.
	 * @param array  $ids        Document IDs in relevance order.
	 * @param array  $sort       Sort rules; the first valid one is applied.
	 * @return array
	 */
	private function sort_ids( string $index_name, array $ids, array $sort ): array {
		global $wpdb;

		$rule = (string) reset( $sort );
		if ( ! preg_match( '/^([a-zA-Z_][a-zA-Z0-9_]*):(asc|desc)$/i', $rule, $m ) ) {
			return $ids;
		}
		$field = $m[1];
		$desc  = 'desc' === strtolower( $m[2] );

		$values = array();
		$table  = $wpdb->prefix . 'wss_index_documents';
		foreach ( array_chunk( $ids, 500 ) as $chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
			$rows         = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"SELECT doc_id, doc_data FROM {$table} WHERE index_name = %s AND doc_id IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					array_merge( array( $index_name ), $chunk )
				)
			);
			foreach ( (array) $rows as $row ) {
				$doc = json_decode( $row->doc_data, true );
				if ( is_array( $doc ) && isset( $doc[ $field ] ) && '' !== $doc[ $field ] && ! is_array( $doc[ $field ] ) ) {
					$values[ (int) $row->doc_id ] = $doc[ $field ];
				}
			}
		}

		$rank = array_flip( array_values( $ids ) );
		usort(
			$ids,
			function ( $a, $b ) use ( $values, $desc, $rank ) {
				$has_a = isset( $values[ $a ] );
				$has_b = isset( $values[ $b ] );
				if ( $has_a !== $has_b ) {
					return $has_a ? -1 : 1;
				}
				if ( $has_a ) {
					$va  = $values[ $a ];
					$vb  = $values[ $b ];
					$cmp = ( is_numeric( $va ) && is_numeric( $vb ) )
						? ( (float) $va <=> (float) $vb )
						: strcmp( remove_accents( mb_strtolower( (string) $va ) ), remove_accents( mb_strtolower( (string) $vb ) ) );
					if ( 0 !== $cmp ) {
						return $desc ? -$cmp : $cmp;
					}
				}
				return $rank[ $a ] <=> $rank[ $b ];
			}
		);

		return $ids;
	}

	/**
	 * Resolve term IDs for a list of terms, creating the missing ones.
	 *
	 * @param string[] $terms Folded terms.
	 * @return array term => id
	 */
	private function get_term_ids( array $terms ): array {
		global $wpdb;

		$table = $wpdb->prefix . 'wss_index_terms';
		$terms = array_values( array_unique( array_filter( $terms, 'strlen' ) ) );
		$map   = array();

		foreach ( array_chunk( $terms, 200 ) as $chunk ) {
			$placeholders = implode( ',', array_fill( 0, count( $chunk ), '%s' ) );
			$lookup       = function () use ( $wpdb, $table, $placeholders, $chunk, &$map ) {
				$found = $wpdb->get_results( $wpdb->prepare( "SELECT id, term FROM {$table} WHERE term IN ({$placeholders})", $chunk ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				foreach ( (array) $found as $row ) {
					$map[ (string) $row->term ] = (int) $row->id;
				}
			};

			$lookup();

			$missing = array();
			foreach ( $chunk as $term ) {
				if ( ! isset( $map[ $term ] ) ) {
					$missing[] = $term;
				}
			}
			if ( empty( $missing ) ) {
				continue;
			}

			// INSERT IGNORE: concurrent indexers may create the same term.
			$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$table} (term) VALUES " . implode( ',', array_fill( 0, count( $missing ), '(%s)' ) ), $missing ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$lookup();

			// Collation-equivalent spellings map to an existing row: resolve one by one.
			foreach ( $missing as $term ) {
				if ( ! isset( $map[ $term ] ) ) {
					$id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE term = %s", $term ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					if ( $id ) {
						$map[ $term ] = (int) $id;
					}
				}
			}
		}

		return $map;
	}

	/**
	 * Delete a single document.
	 *
	 * @param string $index_name  Index name.
	 * @param string $document_id Document ID.
	 * @return bool
	 */
	public function delete_document( string $index_name, string $document_id ): bool {
		global $wpdb;

		$doc_id = (int) $document_id;
		$wpdb->delete( $wpdb->prefix . 'wss_index_postings', array( 'doc_id' => $doc_id, 'index_name' => $index_name ), array( '%d', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( $wpdb->prefix . 'wss_index_documents', array( 'doc_id' => $doc_id, 'index_name' => $index_name ), array( '%d', '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		$this->invalidate_cache( $index_name );

		return true;
	}

	/**
	 * Delete all documents from an index.
	 *
	 * @param string $index_name Index name.
	 * @return bool
	 */
	public function delete_all_documents( string $index_name ): bool {
		global $wpdb;

		$wpdb->delete( $wpdb->prefix . 'wss_index_postings', array( 'index_name' => $index_name ), array( '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( $wpdb->prefix . 'wss_index_documents', array( 'index_name' => $index_name ), array( '%s' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		$this->invalidate_cache( $index_name );

		return true;
	}

	/**
	 * Get all document IDs currently stored in an index.
	 *
	 * Used to prune orphaned entries (documents whose source post no longer
	 * exists or is no longer published).
	 *
	 * @param string $index_name Index name.
	 * @return int[] Array of document IDs.
	 */
	public function get_all_document_ids( string $index_name ): array {
		global $wpdb;

		$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT doc_id FROM {$wpdb->prefix}wss_index_documents WHERE index_name = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$index_name
			)
		);

		return array_map( 'intval', (array) $ids );
	}

	/**
	 * Search documents using the inverted index with TF-IDF scoring.
	 *
	 * Results are cached in a dedicated MySQL table for ultra-fast repeated queries.
	 *
	 * @param string $index_name Index name.
	 * @param string $query      Search query.
	 * @param array  $options    Search options.
	 * @return array
	 */
	public function search( string $index_name, string $query, array $options = array() ): array {
		global $wpdb;

		$start_time = microtime( true );

		// Build a cache key from the query + options that affect results.
		$cache_key = $this->build_cache_key( $index_name, $query, $options );

		// Check in-memory cache first (same request).
		if ( isset( $this->memory_cache[ $cache_key ] ) ) {
			$cached = $this->memory_cache[ $cache_key ];
			$cached['processingTimeMs'] = 0;
			$cached['_cacheHit']        = true;
			return $cached;
		}

		// Check persistent cache (MySQL table).
		$cached = $this->get_cached_result( $cache_key );
		if ( null !== $cached ) {
			$this->memory_cache[ $cache_key ] = $cached;
			$elapsed = ( microtime( true ) - $start_time ) * 1000;
			$cached['processingTimeMs'] = (int) $elapsed;
			$cached['_cacheHit']        = true;
			return $cached;
		}

		$limit  = isset( $options['limit'] ) ? (int) $options['limit'] : 12;
		$offset = isset( $options['offset'] ) ? (int) $options['offset'] : 0;

		$docs_table     = $wpdb->prefix . 'wss_index_documents';
		$terms_table    = $wpdb->prefix . 'wss_index_terms';
		$postings_table = $wpdb->prefix . 'wss_index_postings';

		// Tokenize the query.
		$query_tokens = $this->tokenize( $query );

		// Group the query: each original word plus its synonyms and collapsed
		// code form. Documents matching more groups (words) rank first.
		$token_groups = array();
		foreach ( array_values( array_unique( $query_tokens ) ) as $gi => $token ) {
			$group = array( $token );
			if ( isset( $this->synonyms[ $token ] ) ) {
				foreach ( $this->synonyms[ $token ] as $syn ) {
					$group[] = $this->fold_term( $syn );
				}
			}
			// Code fragments: also try a collapsed (alphanumeric-only) form of any
			// token that carries a separator or a digit. SKUs are indexed in
			// search_codes in collapsed form ("abc1234"), so a fragment typed with
			// its separator ("abc-12", "00-123") would otherwise never match.
			if ( preg_match( '/[^a-z0-9]/', $token ) || preg_match( '/\d/', $token ) ) {
				$collapsed = preg_replace( '/[^a-z0-9]+/', '', $token );
				if ( '' !== $collapsed && $collapsed !== $token && mb_strlen( $collapsed ) >= 3 ) {
					$group[] = $collapsed;
				}
			}
			$token_groups[ $gi ] = array_values( array_unique( array_filter( $group, 'strlen' ) ) );
		}

		if ( empty( $token_groups ) ) {
			return $this->empty_result( $query );
		}

		// Get total documents for IDF calculation.
		$total_docs = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$docs_table} WHERE index_name = %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$index_name
			)
		);

		if ( 0 === $total_docs ) {
			return $this->empty_result( $query );
		}

		// Exact + prefix matches (prefix = basic typo tolerance while typing).
		$all_scored = $this->score_documents( $index_name, $total_docs, $token_groups, true );

		// Typo tolerance (local engine): if the exact/prefix pass found nothing,
		// fall back to fuzzy matching (Levenshtein) so small misspellings still
		// resolve — e.g. "pantlon" / "pantilon" -> "pantalon". This only runs on
		// otherwise zero-result queries, so correctly spelled searches pay no
		// extra cost.
		if ( empty( $all_scored ) && $this->fuzzy_enabled ) {
			$fuzzy_groups = array();
			foreach ( $token_groups as $gi => $group ) {
				$fuzzy = $this->find_fuzzy_terms( $group );
				if ( ! empty( $fuzzy ) ) {
					$fuzzy_groups[ $gi ] = $fuzzy;
				}
			}
			if ( ! empty( $fuzzy_groups ) ) {
				$all_scored = $this->score_documents( $index_name, $total_docs, $fuzzy_groups, false );
			}
		}

		if ( empty( $all_scored ) ) {
			return $this->empty_result( $query, $start_time );
		}

		// Apply filters if specified.
		$filter_str = isset( $options['filters'] ) ? $options['filters'] : '';
		$scored_ids = wp_list_pluck( $all_scored, 'doc_id' );

		if ( ! empty( $filter_str ) ) {
			$scored_ids = $this->apply_filters( $index_name, $scored_ids, $filter_str );

			// Re-map scores for filtered IDs.
			$score_map = array();
			foreach ( $all_scored as $row ) {
				$score_map[ $row->doc_id ] = $row->score;
			}
			$filtered_scored = array();
			foreach ( $scored_ids as $did ) {
				$filtered_scored[] = (object) array(
					'doc_id' => $did,
					'score'  => isset( $score_map[ $did ] ) ? $score_map[ $did ] : 0,
				);
			}
			usort( $filtered_scored, function ( $a, $b ) {
				return $b->score <=> $a->score;
			} );
			$all_scored = $filtered_scored;
			$scored_ids = wp_list_pluck( $all_scored, 'doc_id' );
		}

		// Explicit sort (results page "Sort by"): relevance order is the default.
		if ( ! empty( $options['sort'] ) && count( $scored_ids ) > 1 ) {
			$scored_ids = $this->sort_ids( $index_name, $scored_ids, (array) $options['sort'] );
		}

		$total_hits = count( $scored_ids );

		// Apply offset/limit.
		$page_ids = array_slice( $scored_ids, $offset, $limit );

		if ( empty( $page_ids ) ) {
			return $this->empty_result( $query, $start_time, $total_hits );
		}

		// Fetch documents.
		$placeholders = implode( ',', array_fill( 0, count( $page_ids ), '%d' ) );
		$docs = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT doc_id, doc_data FROM {$docs_table} WHERE index_name = %s AND doc_id IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_merge( array( $index_name ), $page_ids )
			)
		);

		// Build hits in score order.
		$doc_map = array();
		foreach ( $docs as $row ) {
			$doc_map[ $row->doc_id ] = json_decode( $row->doc_data, true );
		}

		$hits = array();
		$highlight_fields = isset( $options['highlight_fields'] ) ? $options['highlight_fields'] : array( 'name' );
		foreach ( $page_ids as $did ) {
			if ( isset( $doc_map[ $did ] ) ) {
				$hit = $doc_map[ $did ];

				// Internal / indexing-only fields never reach the (public) client:
				// stock quantities, custom field values and long texts were all
				// exposed through the search endpoint.
				foreach ( self::PRIVATE_FIELDS as $private_field ) {
					unset( $hit[ $private_field ] );
				}

				// Add highlighting.
				$hit['_formatted'] = array();
				foreach ( $highlight_fields as $hf ) {
					if ( isset( $hit[ $hf ] ) && is_string( $hit[ $hf ] ) ) {
						$hit['_formatted'][ $hf ] = $this->highlight_text( $hit[ $hf ], $query_tokens );
					}
				}

				$hits[] = $hit;
			}
		}

		// Calculate facets if requested.
		$facet_distribution = array();
		if ( ! empty( $options['facets'] ) ) {
			// Facet counts come from the most relevant 3000 matches: exact for
			// normal result sets, approximate (but fast) for very broad queries.
			$facet_distribution = $this->calculate_facets( $index_name, array_slice( $scored_ids, 0, 3000 ), (array) $options['facets'] );
		}

		$elapsed = ( microtime( true ) - $start_time ) * 1000;

		$result = array(
			'hits'               => $hits,
			'query'              => $query,
			'estimatedTotalHits' => $total_hits,
			'facetDistribution'  => $facet_distribution,
			'processingTimeMs'   => (int) $elapsed,
		);

		// Store in both caches.
		$this->memory_cache[ $cache_key ] = $result;
		$this->store_cached_result( $cache_key, $result );

		return $result;
	}

	/**
	 * Set synonyms.
	 *
	 * @param string $index_name Index name.
	 * @param array  $synonyms   Synonyms.
	 * @return bool
	 */
	public function set_synonyms( string $index_name, array $synonyms ): bool {
		$this->synonyms = $synonyms;
		update_option( 'wss_local_synonyms', $synonyms );
		return true;
	}

	/**
	 * Set stop words.
	 *
	 * @param string $index_name Index name.
	 * @param array  $stop_words Stop words.
	 * @return bool
	 */
	public function set_stop_words( string $index_name, array $stop_words ): bool {
		$this->stop_words = array_map( array( $this, 'fold_term' ), $stop_words );
		update_option( 'wss_local_stop_words', $this->stop_words );
		return true;
	}

	/**
	 * Get the base URL for the local search endpoint.
	 *
	 * @return string
	 */
	public function get_base_url(): string {
		return plugins_url( 'search-endpoint.php', dirname( __FILE__ ) . '/woo-smart-search.php' );
	}

	/**
	 * Get the local search endpoint URL.
	 *
	 * @return string
	 */
	public function get_search_endpoint_url(): string {
		return plugins_url( 'search-endpoint.php', dirname( __FILE__ ) . '/woo-smart-search.php' );
	}

	// ---- Internal helpers ----

	/**
	 * Score documents with TF-IDF for groups of query tokens.
	 *
	 * Only the postings of the matching terms are read (the IDF used to be
	 * computed over the whole postings table on every uncached search). Ranking:
	 * documents matching more query words come first (like Meilisearch's
	 * "words" rule), then by TF-IDF, with prefix matches weighted below exact.
	 *
	 * @param string $index_name   Index name.
	 * @param int    $total_docs   Total documents (for IDF).
	 * @param array  $token_groups group index => folded tokens (word + synonyms).
	 * @param bool   $allow_prefix Also match terms starting with a token (3+ chars).
	 * @return array Scored rows (doc_id, score) ordered by score DESC.
	 */
	private function score_documents( string $index_name, int $total_docs, array $token_groups, bool $allow_prefix ): array {
		global $wpdb;

		$terms_table    = $wpdb->prefix . 'wss_index_terms';
		$postings_table = $wpdb->prefix . 'wss_index_postings';

		$conditions = array();
		$params     = array();
		$last_group = array_key_last( $token_groups );
		foreach ( $token_groups as $gi => $group ) {
			// The word being typed (last one) completes from 2 letters, like
			// Meilisearch; earlier words need 3 to keep the term scan small.
			$min_prefix = ( $gi === $last_group ) ? 2 : 3;
			foreach ( $group as $token ) {
				$conditions[] = 'term = %s';
				$params[]     = $token;
				if ( $allow_prefix && mb_strlen( $token ) >= $min_prefix ) {
					$conditions[] = 'term LIKE %s';
					$params[]     = $wpdb->esc_like( $token ) . '%';
				}
			}
		}
		if ( empty( $conditions ) ) {
			return array();
		}

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		$terms = $wpdb->get_results(
			$wpdb->prepare( "SELECT id, term FROM {$terms_table} WHERE " . implode( ' OR ', $conditions ) . ' LIMIT 3000', $params )
		);
		if ( empty( $terms ) ) {
			return array();
		}

		// Which groups each term matches, and how strongly (exact 1.0, prefix 0.6).
		$term_match = array();
		foreach ( $terms as $row ) {
			$term = (string) $row->term;
			foreach ( $token_groups as $gi => $group ) {
				foreach ( $group as $token ) {
					$token = (string) $token;
					if ( $term === $token ) {
						$weight = 1.0;
					} elseif ( $allow_prefix && 0 === strpos( $term, $token ) ) {
						$weight = 0.6;
					} else {
						continue;
					}
					if ( $weight > ( $term_match[ (int) $row->id ][ $gi ] ?? 0 ) ) {
						$term_match[ (int) $row->id ][ $gi ] = $weight;
					}
				}
			}
		}

		$term_ids     = array_keys( $term_match );
		$placeholders = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );

		// Document frequency of the matching terms only.
		$df_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT term_id, COUNT(*) AS cnt FROM {$postings_table} WHERE index_name = %s AND term_id IN ({$placeholders}) GROUP BY term_id",
				array_merge( array( $index_name ), $term_ids )
			)
		);
		$idf = array();
		foreach ( (array) $df_rows as $row ) {
			$idf[ (int) $row->term_id ] = log( ( $total_docs + 1 ) / ( (int) $row->cnt + 1 ) ) + 0.1;
		}

		$postings = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT doc_id, term_id, tf FROM {$postings_table} WHERE index_name = %s AND term_id IN ({$placeholders})",
				array_merge( array( $index_name ), $term_ids )
			)
		);
		// phpcs:enable

		$scores   = array();
		$coverage = array();
		foreach ( (array) $postings as $row ) {
			$tid = (int) $row->term_id;
			$did = (int) $row->doc_id;
			foreach ( $term_match[ $tid ] as $gi => $weight ) {
				if ( $weight <= 0 ) {
					continue;
				}
				$value = (float) $row->tf * ( $idf[ $tid ] ?? 0.1 ) * $weight;
				// Per word keep the best-matching term, so many prefix variants
				// of one word don't outweigh an exact match.
				if ( $value > ( $coverage[ $did ][ $gi ] ?? 0 ) ) {
					$coverage[ $did ][ $gi ] = $value;
				}
			}
		}

		foreach ( $coverage as $did => $groups ) {
			// Matched words dominate; TF-IDF orders documents within that.
			$scores[ $did ] = count( $groups ) * 1000 + array_sum( $groups );
		}

		arsort( $scores );

		$result = array();
		foreach ( $scores as $did => $score ) {
			$result[] = (object) array(
				'doc_id' => $did,
				'score'  => $score,
			);
		}

		return $result;
	}

	/**
	 * Find index terms within a small edit distance of the query tokens.
	 *
	 * Candidates are narrowed in SQL by first character and length (typos
	 * rarely change the first letter, and length differs by at most the
	 * allowed distance), so the PHP levenshtein() pass runs on a small set.
	 * The distance threshold scales with word length, mirroring Meilisearch:
	 * 1 edit for 5-8 chars, 2 edits for 9+; words under 5 chars are skipped
	 * to avoid noise. Only called as a fallback on zero-result queries.
	 *
	 * @param array $tokens Folded query tokens.
	 * @return array Matching term strings present in the index.
	 */
	private function find_fuzzy_terms( array $tokens ): array {
		global $wpdb;

		$terms_table = $wpdb->prefix . 'wss_index_terms';
		$matches     = array();

		foreach ( array_unique( $tokens ) as $token ) {
			$len = mb_strlen( $token );
			if ( $len < 5 ) {
				continue;
			}
			$max_dist = ( $len >= 9 ) ? 2 : 1;
			$first    = mb_substr( $token, 0, 1 );

			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
			$candidates = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT term FROM {$terms_table}
					WHERE term LIKE %s
					AND CHAR_LENGTH( term ) BETWEEN %d AND %d
					LIMIT 2000",
					$wpdb->esc_like( $first ) . '%',
					$len - $max_dist,
					$len + $max_dist
				)
			);
			// phpcs:enable

			if ( empty( $candidates ) ) {
				continue;
			}

			foreach ( $candidates as $cand ) {
				if ( $cand === $token ) {
					continue;
				}
				if ( levenshtein( $token, $cand ) <= $max_dist ) {
					$matches[ $cand ] = true;
				}
			}
		}

		return array_keys( $matches );
	}

	/**
	 * Normalize a single term: lowercase + strip diacritics (accents).
	 *
	 * This makes the local engine accent-insensitive, so "aviación" and
	 * "aviacion" resolve to the same token. Applied at both index and query
	 * time, and to stop words / synonyms, so all comparisons stay consistent.
	 *
	 * @param string $text Term to normalize.
	 * @return string Folded term.
	 */
	private function fold_term( $text ): string {
		$text = mb_strtolower( (string) $text );
		if ( function_exists( 'remove_accents' ) ) {
			$text = remove_accents( $text );
		}
		return $text;
	}

	/**
	 * Tokenize a string into normalized terms.
	 *
	 * @param string $text Text to tokenize.
	 * @return array Array of lowercase tokens.
	 */
	private function tokenize( $text ): array {
		if ( is_array( $text ) ) {
			$parts = array();
			foreach ( $text as $item ) {
				if ( is_string( $item ) ) {
					$parts = array_merge( $parts, $this->tokenize( $item ) );
				}
			}
			return $parts;
		}

		if ( ! is_string( $text ) || '' === $text ) {
			return array();
		}

		// Lowercase + strip diacritics so search is accent-insensitive.
		$text = mb_strtolower( $text );
		if ( function_exists( 'remove_accents' ) ) {
			$text = remove_accents( $text );
		}

		// Remove HTML tags.
		$text = wp_strip_all_tags( $text );

		// Replace non-alphanumeric with spaces (preserve hyphens inside words).
		$text = preg_replace( '/[^\p{L}\p{N}\-]/u', ' ', $text );

		// Split by whitespace.
		$tokens = preg_split( '/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY );

		// Remove stop words and very short tokens.
		$result = array();
		foreach ( $tokens as $token ) {
			$token = trim( $token, '-' );
			if ( mb_strlen( $token ) < 2 ) {
				continue;
			}
			if ( in_array( $token, $this->stop_words, true ) ) {
				continue;
			}
			$result[] = $token;
		}

		return $result;
	}

	/**
	 * Extract a field value from a document (supports nested dot notation).
	 *
	 * @param array  $doc   Document array.
	 * @param string $field Field name (e.g., 'name', 'attributes.Color').
	 * @return string|array
	 */
	private function extract_field_value( array $doc, string $field ) {
		if ( isset( $doc[ $field ] ) ) {
			return $doc[ $field ];
		}

		// Support dot notation (attributes.Color).
		$parts   = explode( '.', $field );
		$current = $doc;
		foreach ( $parts as $part ) {
			if ( is_array( $current ) && isset( $current[ $part ] ) ) {
				$current = $current[ $part ];
			} else {
				return '';
			}
		}

		return $current;
	}

	/**
	 * Apply Meilisearch-style filter string to a set of document IDs.
	 *
	 * Supports: field = "value", field != "value", field > N, field < N,
	 *           field >= N, field <= N, AND, OR.
	 *
	 * @param string $index_name Index name.
	 * @param array  $doc_ids    Document IDs to filter.
	 * @param string $filter_str Filter string.
	 * @return array Filtered document IDs.
	 */
	private function apply_filters( string $index_name, array $doc_ids, string $filter_str ): array {
		global $wpdb;

		if ( empty( $doc_ids ) || empty( $filter_str ) ) {
			return $doc_ids;
		}

		$docs_table   = $wpdb->prefix . 'wss_index_documents';
		$placeholders = implode( ',', array_fill( 0, count( $doc_ids ), '%d' ) );

		// Fetch document data for filtering.
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT doc_id, doc_data FROM {$docs_table} WHERE index_name = %s AND doc_id IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_merge( array( $index_name ), $doc_ids )
			)
		);

		// Parse once, evaluate per document (it used to be re-parsed by regex
		// for every candidate document).
		$parsed = $this->parse_filter( $filter_str );

		$result = array();
		foreach ( $rows as $row ) {
			$doc = json_decode( $row->doc_data, true );
			if ( is_array( $doc ) && $this->evaluate_parsed_filter( $doc, $parsed ) ) {
				$result[] = (int) $row->doc_id;
			}
		}

		return $result;
	}

	/**
	 * Parse a Meilisearch-style filter into AND-ed groups of OR-ed conditions.
	 *
	 * Quote-aware: values such as "Bath and Body" or "Shoes (kids)" are no
	 * longer split on the AND/OR inside them.
	 *
	 * @param string $filter Filter expression.
	 * @return array List of groups; each group is a list of [field, op, value]
	 *               (null for an unparseable condition, which never matches).
	 */
	private function parse_filter( string $filter ): array {
		$groups = array();
		foreach ( $this->split_top_level( $filter, 'AND' ) as $part ) {
			$part = trim( $part );
			if ( '' === $part ) {
				continue;
			}
			if ( '(' === $part[0] && ')' === substr( $part, -1 ) ) {
				$part = substr( $part, 1, -1 );
			}
			$group = array();
			foreach ( $this->split_top_level( $part, 'OR' ) as $cond ) {
				$group[] = $this->parse_condition( trim( $cond ) );
			}
			$groups[] = $group;
		}
		return $groups;
	}

	/**
	 * Split on a keyword (AND / OR) outside quotes and parentheses.
	 *
	 * @param string $str     Expression.
	 * @param string $keyword Keyword.
	 * @return string[]
	 */
	private function split_top_level( string $str, string $keyword ): array {
		$parts  = array();
		$buf    = '';
		$quote  = '';
		$depth  = 0;
		$len    = strlen( $str );
		$kwlen  = strlen( $keyword );
		for ( $i = 0; $i < $len; $i++ ) {
			$ch = $str[ $i ];
			if ( '' !== $quote ) {
				if ( '\\' === $ch && $i + 1 < $len ) {
					$buf .= $ch . $str[ ++$i ];
					continue;
				}
				if ( $ch === $quote ) {
					$quote = '';
				}
				$buf .= $ch;
				continue;
			}
			if ( '"' === $ch || "'" === $ch ) {
				$quote = $ch;
			} elseif ( '(' === $ch ) {
				++$depth;
			} elseif ( ')' === $ch ) {
				$depth = max( 0, $depth - 1 );
			} elseif ( 0 === $depth && ctype_space( $ch ) && 0 === strcasecmp( substr( $str, $i + 1, $kwlen ), $keyword ) && ( $i + 1 + $kwlen < $len ) && ctype_space( $str[ $i + 1 + $kwlen ] ) ) {
				$parts[] = $buf;
				$buf     = '';
				$i      += $kwlen + 1;
				continue;
			}
			$buf .= $ch;
		}
		$parts[] = $buf;
		return $parts;
	}

	/**
	 * Parse `field op value` into [field, op, value], or null if invalid.
	 *
	 * @param string $condition Condition.
	 * @return array|null
	 */
	private function parse_condition( string $condition ) {
		if ( ! preg_match( '/^([A-Za-z0-9_.\- ]+?)\s*(>=|<=|!=|=|>|<)\s*(?:"((?:[^"\\\\]|\\\\.)*)"|\'([^\']*)\'|(\S+))\s*$/u', $condition, $m ) ) {
			return null;
		}
		$value = '';
		if ( isset( $m[3] ) && '' !== $m[3] ) {
			$value = stripslashes( $m[3] );
		} elseif ( isset( $m[4] ) && '' !== $m[4] ) {
			$value = $m[4];
		} elseif ( isset( $m[5] ) ) {
			$value = $m[5];
		}
		return array( trim( $m[1] ), $m[2], $value );
	}

	/**
	 * Evaluate a parsed filter against a document.
	 *
	 * @param array $doc    Document.
	 * @param array $groups Output of parse_filter().
	 * @return bool
	 */
	private function evaluate_parsed_filter( array $doc, array $groups ): bool {
		foreach ( $groups as $group ) {
			$ok = false;
			foreach ( $group as $cond ) {
				if ( null !== $cond && $this->evaluate_condition( $doc, $cond[0], $cond[1], $cond[2] ) ) {
					$ok = true;
					break;
				}
			}
			if ( ! $ok ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Evaluate one parsed condition.
	 *
	 * @param array  $doc      Document.
	 * @param string $field    Field (dot notation allowed).
	 * @param string $operator Operator.
	 * @param string $value    Value.
	 * @return bool
	 */
	private function evaluate_condition( array $doc, string $field, string $operator, string $value ): bool {
		$doc_val = $this->extract_field_value( $doc, $field );

		// Booleans are stored as true/false; filters say "true"/"false".
		if ( is_bool( $doc_val ) ) {
			$doc_val = $doc_val ? 'true' : 'false';
			if ( '1' === $value ) {
				$value = 'true';
			} elseif ( '0' === $value ) {
				$value = 'false';
			}
		}

		return $this->evaluate_single_condition( $doc, $field . ' ' . $operator . ' "' . addcslashes( $value, '"' ) . '"', $doc_val, $value, $operator );
	}

	/**
	 * Evaluate a single filter condition (e.g., 'categories = "Electronics"').
	 *
	 * @param array  $doc       Document data.
	 * @param string $condition Single condition string.
	 * @return bool
	 */
	private function evaluate_single_condition( array $doc, string $condition, $doc_val = null, $value = null, $operator = null ): bool {
		if ( null === $operator ) {
			// Legacy string form.
			$parsed = $this->parse_condition( $condition );
			if ( null === $parsed ) {
				return false; // Unparseable conditions never match.
			}
			list( $field, $operator, $value ) = $parsed;
			$doc_val = $this->extract_field_value( $doc, $field );
		}

		// Array field: check if any element matches.
		if ( is_array( $doc_val ) ) {
			switch ( $operator ) {
				case '=':
					return in_array( $value, $doc_val, false ); // Loose comparison for numeric strings.
				case '!=':
					return ! in_array( $value, $doc_val, false );
				default:
					return false;
			}
		}

		// Numeric comparisons.
		if ( in_array( $operator, array( '>=', '<=', '>', '<' ), true ) ) {
			$num_doc = (float) $doc_val;
			$num_val = (float) $value;
			switch ( $operator ) {
				case '>=': return $num_doc >= $num_val;
				case '<=': return $num_doc <= $num_val;
				case '>':  return $num_doc > $num_val;
				case '<':  return $num_doc < $num_val;
			}
		}

		// String comparison.
		switch ( $operator ) {
			case '=':  return (string) $doc_val === $value;
			case '!=': return (string) $doc_val !== $value;
		}

		return true;
	}

	/**
	 * Calculate facet distributions for a set of document IDs.
	 *
	 * @param string $index_name Index name.
	 * @param array  $doc_ids    Document IDs.
	 * @param array  $facets     Facet field names.
	 * @return array Facet distribution map.
	 */
	private function calculate_facets( string $index_name, array $doc_ids, array $facets ): array {
		global $wpdb;

		if ( empty( $doc_ids ) || empty( $facets ) ) {
			return array();
		}

		$docs_table   = $wpdb->prefix . 'wss_index_documents';
		$placeholders = implode( ',', array_fill( 0, count( $doc_ids ), '%d' ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT doc_data FROM {$docs_table} WHERE index_name = %s AND doc_id IN ({$placeholders})", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				array_merge( array( $index_name ), $doc_ids )
			)
		);

		$distribution = array();
		foreach ( $facets as $facet ) {
			$distribution[ $facet ] = array();
		}

		foreach ( $rows as $row ) {
			$doc = json_decode( $row->doc_data, true );
			foreach ( $facets as $facet ) {
				$value = $this->extract_field_value( $doc, $facet );
				if ( is_array( $value ) ) {
					foreach ( $value as $v ) {
						$v = (string) $v;
						if ( '' === $v ) {
							continue;
						}
						if ( ! isset( $distribution[ $facet ][ $v ] ) ) {
							$distribution[ $facet ][ $v ] = 0;
						}
						++$distribution[ $facet ][ $v ];
					}
				} elseif ( '' !== (string) $value && null !== $value ) {
					$sv = (string) $value;
					if ( ! isset( $distribution[ $facet ][ $sv ] ) ) {
						$distribution[ $facet ][ $sv ] = 0;
					}
					++$distribution[ $facet ][ $sv ];
				}
			}
		}

		// Remove empty facets.
		foreach ( $distribution as $key => $values ) {
			if ( empty( $values ) ) {
				unset( $distribution[ $key ] );
			}
		}

		return $distribution;
	}

	/**
	 * Highlight query terms in text.
	 *
	 * @param string $text   Text to highlight.
	 * @param array  $tokens Query tokens.
	 * @return string
	 */
	private function highlight_text( string $text, array $tokens ): string {
		$tokens = array_filter( array_map( 'strval', $tokens ), 'strlen' );
		if ( empty( $tokens ) ) {
			return htmlspecialchars( $text, ENT_QUOTES, 'UTF-8' );
		}

		// Tokens are accent-folded ("aviacion"): match any accented spelling
		// in the original text, on the raw text (escaping first could match
		// inside entities like "&amp;"), then escape each piece.
		$variants = array(
			'a' => '[aáàâäãå]',
			'e' => '[eéèêë]',
			'i' => '[iíìîï]',
			'o' => '[oóòôöõ]',
			'u' => '[uúùûü]',
			'n' => '[nñ]',
			'c' => '[cç]',
		);
		$patterns = array();
		foreach ( $tokens as $token ) {
			$chars = preg_split( '//u', $token, -1, PREG_SPLIT_NO_EMPTY );
			$pat   = '';
			foreach ( (array) $chars as $ch ) {
				$pat .= $variants[ $ch ] ?? preg_quote( $ch, '/' );
			}
			$patterns[] = $pat;
		}
		// Longest first so "pantalones" wins over "pantalon".
		usort(
			$patterns,
			function ( $a, $b ) {
				return strlen( $b ) <=> strlen( $a );
			}
		);

		$parts = preg_split( '/(' . implode( '|', $patterns ) . ')/iu', $text, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( false === $parts ) {
			return htmlspecialchars( $text, ENT_QUOTES, 'UTF-8' );
		}

		$out = '';
		foreach ( $parts as $i => $part ) {
			$safe = htmlspecialchars( $part, ENT_QUOTES, 'UTF-8' );
			$out .= ( 1 === $i % 2 && '' !== $part ) ? '<mark>' . $safe . '</mark>' : $safe;
		}
		return $out;
	}

	/**
	 * Return an empty result set.
	 *
	 * @param string     $query      The query.
	 * @param float|null $start_time Start time for timing.
	 * @param int        $total      Total count.
	 * @return array
	 */
	private function empty_result( string $query, $start_time = null, int $total = 0 ): array {
		$elapsed = $start_time ? ( microtime( true ) - $start_time ) * 1000 : 0;
		return array(
			'hits'               => array(),
			'query'              => $query,
			'estimatedTotalHits' => $total,
			'facetDistribution'  => array(),
			'processingTimeMs'   => (int) $elapsed,
		);
	}

	// ---- Cache helpers ----

	/**
	 * Build a deterministic cache key from query + options.
	 *
	 * @param string $index_name Index name.
	 * @param string $query      Search query.
	 * @param array  $options    Search options.
	 * @return string MD5 hash key.
	 */
	private function build_cache_key( string $index_name, string $query, array $options ): string {
		$key_parts = array(
			'idx'     => $index_name,
			'q'       => $this->fold_term( trim( $query ) ),
			'limit'   => $options['limit'] ?? 12,
			'offset'  => $options['offset'] ?? 0,
			'filters' => $options['filters'] ?? '',
			'sort'    => $options['sort'] ?? '',
			'facets'  => $options['facets'] ?? array(),
			// Bumped whenever documents change (cheap invalidation, no TRUNCATE).
			'gen'     => $this->get_cache_generation(),
		);
		return md5( wp_json_encode( $key_parts ) );
	}

	/**
	 * Get a cached search result from the persistent cache table.
	 *
	 * @param string $cache_key Cache key.
	 * @return array|null Cached result or null if not found/expired.
	 */
	private function get_cached_result( string $cache_key ) {
		global $wpdb;

		$table = $wpdb->prefix . 'wss_search_cache';

		// Check if table exists (avoid errors before activation).
		if ( ! $this->cache_table_exists() ) {
			return null;
		}

		$ttl = (int) apply_filters( 'wss_search_cache_ttl', self::CACHE_TTL );

		$row = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT result_data FROM {$table} WHERE cache_key = %s AND created_at >= DATE_SUB( NOW(), INTERVAL %d SECOND ) LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$cache_key,
				$ttl
			)
		);

		if ( null === $row ) {
			return null;
		}

		$result = json_decode( $row, true );
		return is_array( $result ) ? $result : null;
	}

	/**
	 * Store a search result in the persistent cache.
	 *
	 * @param string $cache_key Cache key.
	 * @param array  $result    Search result to cache.
	 */
	private function store_cached_result( string $cache_key, array $result ) {
		global $wpdb;

		$table = $wpdb->prefix . 'wss_search_cache';

		if ( ! $this->cache_table_exists() ) {
			return;
		}

		// Remove timing data from cached result (will be recalculated on read).
		$to_cache = $result;
		unset( $to_cache['processingTimeMs'], $to_cache['_cacheHit'] );

		// Keep the table bounded: purge expired rows now and then (this used
		// to be never called, so the table grew with every unique keystroke).
		if ( 1 === mt_rand( 1, 50 ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand -- wp_rand() is not loaded in SHORTINIT.
			$this->purge_expired_cache();
		}

		// Use REPLACE to upsert (handles duplicate keys).
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"REPLACE INTO {$table} (cache_key, result_data, created_at) VALUES (%s, %s, NOW())", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$cache_key,
				wp_json_encode( $to_cache, JSON_UNESCAPED_UNICODE )
			)
		);
	}

	/**
	 * Invalidate all cached results for an index.
	 *
	 * Called when documents are indexed, updated, or deleted.
	 *
	 * @param string $index_name Index name (unused, clears all for simplicity).
	 */
	public function invalidate_cache( string $index_name = '', bool $hard = false ) {
		global $wpdb;

		$this->memory_cache = array();

		if ( ! $hard ) {
			// Start a new cache generation: old entries are never read again
			// and expire via purge_expired_cache(). (A TRUNCATE on every single
			// product save made the cache useless on busy stores.)
			$this->cache_gen = $this->get_cache_generation() + 1;
			update_option( 'wss_cache_gen', $this->cache_gen, true );
			return;
		}

		if ( ! $this->cache_table_exists() ) {
			return;
		}

		$table = $wpdb->prefix . 'wss_search_cache';
		$wpdb->query( "TRUNCATE TABLE {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Current cache generation (memoized per request).
	 *
	 * @return int
	 */
	private function get_cache_generation(): int {
		if ( null === $this->cache_gen ) {
			$this->cache_gen = (int) get_option( 'wss_cache_gen', 0 );
		}
		return $this->cache_gen;
	}

	/**
	 * Purge expired entries from the cache table.
	 *
	 * Can be called periodically to keep the table small.
	 */
	public function purge_expired_cache() {
		global $wpdb;

		$table = $wpdb->prefix . 'wss_search_cache';

		if ( ! $this->cache_table_exists() ) {
			return;
		}

		$ttl = (int) apply_filters( 'wss_search_cache_ttl', self::CACHE_TTL );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE created_at < DATE_SUB( NOW(), INTERVAL %d SECOND )", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$ttl
			)
		);
	}

	/**
	 * Get cache statistics.
	 *
	 * @return array
	 */
	public function get_cache_stats(): array {
		global $wpdb;

		$table = $wpdb->prefix . 'wss_search_cache';

		if ( ! $this->cache_table_exists() ) {
			return array( 'entries' => 0, 'size' => '0 KB' );
		}

		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$size  = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT ROUND( SUM( LENGTH( result_data ) ) / 1024, 1 ) FROM {$table} WHERE 1 = %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				1
			)
		);

		return array(
			'entries' => $count,
			'size'    => $size . ' KB',
		);
	}

	/**
	 * Check if the cache table exists.
	 *
	 * @return bool
	 */
	private function cache_table_exists(): bool {
		global $wpdb;
		static $exists = null;

		if ( null === $exists ) {
			$table  = $wpdb->prefix . 'wss_search_cache';
			$exists = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		}

		return $exists;
	}

	/**
	 * Create the local index database tables.
	 *
	 * Called during plugin activation and when creating an index.
	 */
	public static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Use direct CREATE TABLE IF NOT EXISTS — more reliable than dbDelta
		// in contexts where wp-admin/includes/upgrade.php may not be available.
		$tables = array(
			"CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wss_index_documents (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				index_name varchar(100) NOT NULL DEFAULT 'woo_products',
				doc_id bigint(20) NOT NULL,
				doc_data longtext NOT NULL,
				indexed_at datetime NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY idx_index_doc (index_name, doc_id),
				KEY idx_index_name (index_name)
			) {$charset_collate}",
			"CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wss_index_terms (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				term varchar(191) NOT NULL,
				PRIMARY KEY (id),
				UNIQUE KEY idx_term (term)
			) {$charset_collate}",
			"CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wss_index_postings (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				index_name varchar(100) NOT NULL DEFAULT 'woo_products',
				term_id bigint(20) NOT NULL,
				doc_id bigint(20) NOT NULL,
				tf float NOT NULL DEFAULT 0,
				PRIMARY KEY (id),
				KEY idx_term_index (term_id, index_name),
				KEY idx_doc_index (doc_id, index_name),
				KEY idx_index_name (index_name)
			) {$charset_collate}",
			"CREATE TABLE IF NOT EXISTS {$wpdb->prefix}wss_search_cache (
				cache_key char(32) NOT NULL,
				result_data longtext NOT NULL,
				created_at datetime NOT NULL,
				PRIMARY KEY (cache_key),
				KEY idx_created_at (created_at)
			) {$charset_collate}",
		);

		foreach ( $tables as $sql ) {
			$wpdb->query( $sql ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
		}
	}
}
