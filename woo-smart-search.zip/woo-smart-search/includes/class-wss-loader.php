<?php
/**
 * The loader class registers all hooks with WordPress.
 *
 * @package WooSmartSearch
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class WSS_Loader
 */
class WSS_Loader {

	/**
	 * Whether Meilisearch is currently available.
	 *
	 * @var bool|null
	 */
	private $meilisearch_available = null;

	/**
	 * Run the loader to initialize all plugin components.
	 */
	public function run() {
		// Create missing tables after updates that skipped the activation hook.
		WSS_Activator::maybe_upgrade();

		// One-time fix: restore defaults for display settings that were incorrectly reset.
		$this->maybe_fix_display_settings();

		// Initialize admin.
		if ( is_admin() ) {
			$admin = new WSS_Admin();
			$admin->init();

			$admin_ajax = new WSS_Admin_Ajax();
			$admin_ajax->init();
		}

		// Initialize frontend.
		$frontend = new WSS_Frontend();
		$frontend->init();

		// Initialize shortcode.
		$shortcode = new WSS_Shortcode();
		$shortcode->init();

		// Initialize REST API.
		$rest_api = new WSS_Rest_Api();
		$rest_api->init();

		// Initialize content source based on mode.
		$content_source = wss_get_content_source();

		if ( 'mixed' === $content_source ) {
			// Mixed mode: initialize both syncs.
			if ( wss_is_woocommerce_active() ) {
				$sync = new WSS_Product_Sync();
				$sync->init();
				add_action( 'admin_init', array( 'WSS_Product_Sync', 'maybe_update_filterable_attributes' ) );
			}
			$post_sync = new WSS_Post_Sync();
			$post_sync->init();
		} elseif ( wss_is_ecommerce_mode() ) {
			// WooCommerce product sync.
			$sync = new WSS_Product_Sync();
			$sync->init();

			// Ensure Meilisearch filterable attributes include product attributes.
			add_action( 'admin_init', array( 'WSS_Product_Sync', 'maybe_update_filterable_attributes' ) );
		} else {
			// WordPress content sync (posts, pages, CPTs).
			$post_sync = new WSS_Post_Sync();
			$post_sync->init();
		}

		// Initialize sync queue (shared by both modes).
		$queue = new WSS_Sync_Queue();
		$queue->init();

		// Initialize search analytics.
		$analytics = new WSS_Search_Analytics();
		$analytics->init();

		// Schedule background jobs on `init`, not here (plugins_loaded): Action
		// Scheduler's API is not guaranteed to be loaded/ready this early, so
		// scheduling here could silently no-op and the recurring action would
		// never register. Register a custom WP-Cron interval as a fallback for
		// sites where Action Scheduler is unavailable.
		add_filter( 'cron_schedules', array( $this, 'add_reindex_cron_schedule' ) );
		add_action( 'wss_health_check', array( $this, 'run_health_check' ) );
		add_action( 'wss_cron_health_check', array( $this, 'run_health_check' ) );
		add_action( 'init', array( $this, 'maybe_schedule_jobs' ), 20 );

		// Auto-fallback filter for when Meilisearch is down.
		add_filter( 'wss_use_native_search', array( $this, 'maybe_fallback_to_native' ) );

		// Dashboard widget for connection status.
		add_action( 'wp_dashboard_setup', array( $this, 'add_dashboard_widget' ) );

		// Add settings link to plugins page.
		add_filter( 'plugin_action_links_' . WSS_PLUGIN_BASENAME, array( $this, 'add_settings_link' ) );
	}

	/**
	 * Register a custom WP-Cron recurrence matching the reindex interval, used
	 * as a fallback when Action Scheduler is unavailable.
	 *
	 * @param array $schedules Existing cron schedules.
	 * @return array
	 */
	public function add_reindex_cron_schedule( $schedules ) {
		// Health check fallback interval (the reindex one is far too long and
		// isn't registered at all when re-indexing is disabled).
		$schedules['wss_5min'] = array(
			'interval' => 300,
			'display'  => __( 'Every 5 minutes (Woo Smart Search)', 'woo-smart-search' ),
		);

		$minutes = (int) wss_get_option( 'reindex_interval', 360 );
		if ( $minutes > 0 ) {
			$schedules['wss_reindex'] = array(
				'interval' => $minutes * 60,
				'display'  => __( 'Woo Smart Search re-index interval', 'woo-smart-search' ),
			);
		}
		return $schedules;
	}

	/**
	 * Make sure the recurring jobs are scheduled.
	 *
	 * Checking Action Scheduler costs DB queries, so it runs at most every
	 * 10 minutes (timestamp kept in an autoloaded option = no extra query).
	 * Saving the settings clears the timestamp to force an immediate check.
	 */
	public function maybe_schedule_jobs() {
		$last = (int) get_option( 'wss_jobs_checked_at', 0 );
		$now  = time();
		if ( $last > $now - 600 && $last <= $now ) {
			return;
		}
		update_option( 'wss_jobs_checked_at', $now, true );

		$this->schedule_health_check();
		$this->schedule_periodic_reindex();
		WSS_Search_Analytics::schedule_cleanup();
	}

	/**
	 * Schedule periodic health check every 5 minutes.
	 *
	 * Hooked to `init` so Action Scheduler is loaded; falls back to WP-Cron.
	 */
	public function schedule_health_check() {
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_recurring_action' ) ) {
			if ( ! as_has_scheduled_action( 'wss_health_check' ) ) {
				as_schedule_recurring_action( time() + 300, 300, 'wss_health_check', array(), 'woo-smart-search' );
			}
			$ts = wp_next_scheduled( 'wss_cron_health_check' );
			if ( $ts ) {
				wp_unschedule_event( $ts, 'wss_cron_health_check' );
			}
			return;
		}

		// WP-Cron fallback.
		if ( ! wp_next_scheduled( 'wss_cron_health_check' ) ) {
			wp_schedule_event( time() + 300, 'wss_5min', 'wss_cron_health_check' );
		}
	}

	/**
	 * Schedule periodic re-indexation to catch changes that bypassed hooks.
	 *
	 * Runs every 6 hours by default. Catches: direct DB updates, REST API changes
	 * from external apps, bulk edit plugins, scheduled sales, CSV imports.
	 *
	 * Hooked to `init` (Action Scheduler ready) and falls back to WP-Cron so the
	 * safety net still registers on sites where Action Scheduler is unavailable.
	 */
	public function schedule_periodic_reindex() {
		$minutes  = (int) wss_get_option( 'reindex_interval', 360 );
		$interval = (int) apply_filters( 'wss_reindex_interval', $minutes * 60 );

		if ( $interval <= 0 ) {
			// Disabled — unschedule from both mechanisms.
			if ( function_exists( 'as_unschedule_all_actions' ) ) {
				as_unschedule_all_actions( 'wss_periodic_reindex', array(), 'woo-smart-search' );
			}
			$ts = wp_next_scheduled( 'wss_cron_periodic_reindex' );
			if ( $ts ) {
				wp_unschedule_event( $ts, 'wss_cron_periodic_reindex' );
			}
			return;
		}

		// Prefer Action Scheduler when it is actually available.
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_recurring_action' ) ) {
			if ( ! as_has_scheduled_action( 'wss_periodic_reindex' ) ) {
				as_schedule_recurring_action( time() + $interval, $interval, 'wss_periodic_reindex', array(), 'woo-smart-search' );
			}
			// Drop any duplicate WP-Cron fallback event.
			$ts = wp_next_scheduled( 'wss_cron_periodic_reindex' );
			if ( $ts ) {
				wp_unschedule_event( $ts, 'wss_cron_periodic_reindex' );
			}
			return;
		}

		// WP-Cron fallback when Action Scheduler is unavailable.
		if ( ! wp_next_scheduled( 'wss_cron_periodic_reindex' ) ) {
			wp_schedule_event( time() + $interval, 'wss_reindex', 'wss_cron_periodic_reindex' );
		}
	}

	/**
	 * Run health check on the Meilisearch connection.
	 *
	 * Sends email notification on failure and sets transients for fallback.
	 */
	public function run_health_check() {
		// Local engine: always healthy — skip remote health checks.
		if ( wss_is_local_engine() ) {
			delete_transient( 'wss_connection_error' );
			update_option( 'wss_meilisearch_available', true );
			return;
		}

		// Not configured yet (fresh install): nothing is down, so don't email
		// the admin every hour about it.
		$settings = get_option( 'wss_settings', array() );
		if ( empty( $settings['api_key'] ) ) {
			return;
		}

		$engine = WSS_Meilisearch::get_instance();
		if ( ! $engine ) {
			$this->handle_health_check_failure( __( 'Meilisearch is not configured.', 'woo-smart-search' ) );
			return;
		}

		$result = $engine->test_connection();
		if ( ! $result['success'] ) {
			$this->handle_health_check_failure( $result['message'] );
		} else {
			// Connection restored — clear error state.
			$was_down = get_transient( 'wss_connection_error' );
			delete_transient( 'wss_connection_error' );
			update_option( 'wss_meilisearch_available', true );

			if ( $was_down ) {
				wss_log( __( 'Meilisearch connection restored.', 'woo-smart-search' ), 'info' );

				// Wake up the sync queue so any items that piled up during
				// the outage get processed now instead of waiting for the
				// next scheduled run.
				WSS_Sync_Queue::add_wake_up();

				// Notify admin that connection is back.
				$this->send_health_notification(
					__( 'Meilisearch Connection Restored', 'woo-smart-search' ),
					__( 'The Meilisearch connection has been restored. Native WooCommerce search fallback has been deactivated.', 'woo-smart-search' )
				);
			}
		}
	}

	/**
	 * Handle a health check failure.
	 *
	 * @param string $message Error message.
	 */
	private function handle_health_check_failure( $message ) {
		wss_log(
			sprintf(
				/* translators: %s: error message */
				__( 'Health check failed: %s', 'woo-smart-search' ),
				$message
			),
			'error'
		);

		// Set error transient and mark unavailable.
		set_transient( 'wss_connection_error', $message, 600 );
		update_option( 'wss_meilisearch_available', false );

		// Send email notification (throttled to once per hour).
		$last_email = get_transient( 'wss_health_email_sent' );
		if ( ! $last_email ) {
			$this->send_health_notification(
				__( 'Meilisearch Connection Down', 'woo-smart-search' ),
				sprintf(
					/* translators: 1: site name 2: error message */
					__( "Meilisearch is unreachable on %1\$s.\n\nError: %2\$s\n\nThe plugin has automatically fallen back to native WooCommerce search until the connection is restored.", 'woo-smart-search' ),
					get_bloginfo( 'name' ),
					$message
				)
			);
			set_transient( 'wss_health_email_sent', true, HOUR_IN_SECONDS );
		}
	}

	/**
	 * Send a health check email notification to the site admin.
	 *
	 * @param string $subject Email subject.
	 * @param string $body    Email body.
	 */
	private function send_health_notification( $subject, $body ) {
		$admin_email = get_option( 'admin_email' );
		if ( ! $admin_email ) {
			return;
		}

		wp_mail(
			$admin_email,
			'[' . get_bloginfo( 'name' ) . '] ' . $subject,
			$body
		);
	}

	/**
	 * Determine whether to fallback to native WooCommerce search.
	 *
	 * @param bool $use_native Current value.
	 * @return bool
	 */
	public function maybe_fallback_to_native( $use_native ) {
		if ( $use_native ) {
			return true;
		}

		$available = get_option( 'wss_meilisearch_available', true );
		if ( ! $available ) {
			return true;
		}

		// Also check for recent connection error transient.
		$error = get_transient( 'wss_connection_error' );
		if ( $error ) {
			return true;
		}

		return false;
	}

	/**
	 * Register the dashboard widget.
	 */
	public function add_dashboard_widget() {
		$required_cap = wss_is_woocommerce_active() ? 'manage_woocommerce' : 'manage_options';
		if ( ! current_user_can( $required_cap ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'wss_dashboard_widget',
			__( 'Woo Smart Search', 'woo-smart-search' ),
			array( $this, 'render_dashboard_widget' )
		);
	}

	/**
	 * Render the dashboard widget content.
	 */
	public function render_dashboard_widget() {
		$error     = get_transient( 'wss_connection_error' );
		$available = get_option( 'wss_meilisearch_available', true );
		$engine    = WSS_Meilisearch::get_instance();

		// Connection status.
		if ( $error || ! $available ) {
			$status_color = '#dc3232';
			$status_label = __( 'Down', 'woo-smart-search' );
			$status_msg   = $error ? $error : __( 'Meilisearch is unreachable.', 'woo-smart-search' );
		} elseif ( ! $engine ) {
			$status_color = '#ffb900';
			$status_label = __( 'Not Configured', 'woo-smart-search' );
			$status_msg   = __( 'Please configure your Meilisearch connection.', 'woo-smart-search' );
		} else {
			$status_color = '#46b450';
			$status_label = __( 'Connected', 'woo-smart-search' );
			$status_msg   = '';
		}

		// Document count.
		$doc_count = 0;
		$last_sync = '';
		if ( $engine && ! $error ) {
			$index_name = wss_get_option( 'index_name', 'woo_products' );
			$stats      = $engine->get_index_stats( $index_name );
			$doc_count  = isset( $stats['numberOfDocuments'] ) ? (int) $stats['numberOfDocuments'] : 0;

			$sync_ts = wss_get_last_sync();
			if ( $sync_ts ) {
				$last_sync = human_time_diff( $sync_ts ) . ' ' . __( 'ago', 'woo-smart-search' );
			}
		}

		// Search stats (today).
		$searches_today = 0;
		if ( class_exists( 'WSS_Search_Analytics' ) ) {
			$analytics = new WSS_Search_Analytics();
			$volume    = $analytics->get_search_volume( 'today' );
			foreach ( $volume as $row ) {
				$searches_today += (int) $row->count;
			}
		}
		?>
		<div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
			<span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:<?php echo esc_attr( $status_color ); ?>;"></span>
			<strong><?php echo esc_html( $status_label ); ?></strong>
			<?php if ( $status_msg ) : ?>
				<span style="color:#666;font-size:12px;">&mdash; <?php echo esc_html( $status_msg ); ?></span>
			<?php endif; ?>
		</div>

		<table style="width:100%;border-collapse:collapse;font-size:13px;">
			<tr>
				<td style="padding:4px 0;color:#666;"><?php esc_html_e( 'Indexed products', 'woo-smart-search' ); ?></td>
				<td style="padding:4px 0;text-align:right;font-weight:600;"><?php echo esc_html( number_format_i18n( $doc_count ) ); ?></td>
			</tr>
			<?php if ( $last_sync ) : ?>
			<tr>
				<td style="padding:4px 0;color:#666;"><?php esc_html_e( 'Last sync', 'woo-smart-search' ); ?></td>
				<td style="padding:4px 0;text-align:right;"><?php echo esc_html( $last_sync ); ?></td>
			</tr>
			<?php endif; ?>
			<tr>
				<td style="padding:4px 0;color:#666;"><?php esc_html_e( 'Searches today', 'woo-smart-search' ); ?></td>
				<td style="padding:4px 0;text-align:right;font-weight:600;"><?php echo esc_html( number_format_i18n( $searches_today ) ); ?></td>
			</tr>
		</table>

		<p style="margin:12px 0 0;text-align:right;">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=woo-smart-search' ) ); ?>" class="button button-small">
				<?php esc_html_e( 'Settings', 'woo-smart-search' ); ?>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=woo-smart-search&tab=analytics' ) ); ?>" class="button button-small">
				<?php esc_html_e( 'Analytics', 'woo-smart-search' ); ?>
			</a>
		</p>
		<?php
	}

	/**
	 * One-time migration to restore display settings that were
	 * incorrectly reset to 'no' by the cross-tab save bug.
	 */
	private function maybe_fix_display_settings() {
		if ( get_option( 'wss_display_fix_v1' ) ) {
			return;
		}

		$settings = get_option( 'wss_settings', array() );

		// If show_image was set to 'no' but the user never explicitly disabled it,
		// restore defaults. We detect this by checking if ALL display bools are 'no'
		// (which would only happen from the cross-tab save bug).
		$display_fields = array( 'show_image', 'show_price', 'show_category', 'show_stock' );
		$all_no         = true;
		foreach ( $display_fields as $field ) {
			if ( isset( $settings[ $field ] ) && 'yes' === $settings[ $field ] ) {
				$all_no = false;
				break;
			}
		}

		if ( $all_no && ! empty( $settings ) ) {
			$defaults = array(
				'show_image'       => 'yes',
				'show_price'       => 'yes',
				'show_category'    => 'yes',
				'show_stock'       => 'yes',
				'show_sale_badge'  => 'yes',
				'enable_analytics' => 'yes',
			);
			foreach ( $defaults as $key => $value ) {
				if ( ! isset( $settings[ $key ] ) || 'no' === $settings[ $key ] ) {
					$settings[ $key ] = $value;
				}
			}
			update_option( 'wss_settings', $settings );
		}

		update_option( 'wss_display_fix_v1', true );
	}

	/**
	 * Add settings link to plugins page.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function add_settings_link( $links ) {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			admin_url( 'admin.php?page=woo-smart-search' ),
			__( 'Settings', 'woo-smart-search' )
		);
		array_unshift( $links, $settings_link );
		return $links;
	}
}
