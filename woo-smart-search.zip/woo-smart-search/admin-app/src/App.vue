<template>
  <div class="wss-app">
    <!-- Sidebar -->
    <aside class="wss-sidebar">
      <div class="wss-sidebar-brand">
        <h2>{{ t('Smart Search') }}</h2>
        <div class="wss-version">v{{ version }}</div>
      </div>
      <nav class="wss-sidebar-nav">
        <button
          v-for="tab in tabs"
          :key="tab.id"
          class="wss-nav-item"
          :class="{ active: activeTab === tab.id }"
          @click="activeTab = tab.id"
        >
          <span class="nav-icon">
            <el-icon><component :is="tab.icon" /></el-icon>
          </span>
          {{ tab.label }}
        </button>
      </nav>
    </aside>

    <!-- Main -->
    <div class="wss-main">
      <!-- Header -->
      <header class="wss-header">
        <h1>{{ currentTab.label }}</h1>
        <div class="wss-header-actions">
          <span v-if="dirty" class="wss-unsaved-badge">
            <el-icon><Warning /></el-icon>
            {{ t('Unsaved changes') }}
          </span>
          <span>
            <span class="wss-status-dot" :class="connectionStatus" />
            {{ connectionLabel }}
          </span>
        </div>
      </header>

      <!-- Content -->
      <div class="wss-content">
        <ConnectionTab      v-if="activeTab === 'connection'" />
        <ContentSourcesTab  v-if="activeTab === 'content_sources'" />
        <IndexingTab        v-if="activeTab === 'indexing'" />
        <WidgetTab          v-if="activeTab === 'appearance'" />
        <ResultsPageTab     v-if="activeTab === 'search'" />
        <SynonymsTab        v-if="activeTab === 'synonyms'" />
        <TranslationsTab    v-if="activeTab === 'translations'" />
        <AnalyticsTab       v-if="activeTab === 'analytics'" />
        <LogsTab            v-if="activeTab === 'logs'" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue';
import {
  Link, DataBoard, Refresh, Setting, Brush,
  Document, EditPen, DataAnalysis, Tickets, Warning, MagicStick,
} from '@element-plus/icons-vue';
import { t } from '@/i18n';
import { useApi } from '@/composables/useApi';
import { useSettings } from '@/composables/useSettings';

import ConnectionTab from '@/components/tabs/ConnectionTab.vue';
import ContentSourcesTab from '@/components/tabs/ContentSourcesTab.vue';
import IndexingTab from '@/components/tabs/IndexingTab.vue';
import WidgetTab from '@/components/tabs/WidgetTab.vue';
import ResultsPageTab from '@/components/tabs/ResultsPageTab.vue';
import SynonymsTab from '@/components/tabs/SynonymsTab.vue';
import TranslationsTab from '@/components/tabs/TranslationsTab.vue';
import AnalyticsTab from '@/components/tabs/AnalyticsTab.vue';
import LogsTab from '@/components/tabs/LogsTab.vue';

const { post } = useApi();
const { load, dirty } = useSettings();

// Warn before leaving the page with unsaved changes. Tab switches within
// the panel are safe (state lives in the shared store and any Save button
// persists everything), so we only guard against full page navigation.
function onBeforeUnload(e) {
  if (dirty.value) {
    e.preventDefault();
    e.returnValue = '';
  }
}

const version = window.wssAdmin?.version || '5.2.0';

const tabs = [
  { id: 'connection',      label: t('Connection'),      icon: Link },
  { id: 'content_sources', label: t('Content Sources'),  icon: DataBoard },
  { id: 'indexing',        label: t('Indexing'),         icon: Refresh },
  { id: 'appearance',      label: t('Widget'),           icon: Brush },
  { id: 'search',          label: t('Results Page'),     icon: Document },
  { id: 'synonyms',        label: t('Synonyms & Typos'), icon: MagicStick },
  { id: 'translations',    label: t('Translations'),     icon: EditPen },
  { id: 'analytics',       label: t('Analytics'),        icon: DataAnalysis },
  { id: 'logs',            label: t('Logs'),             icon: Tickets },
];

const activeTab = ref('connection');
const connectionStatus = ref('idle');
const connectionLabel = ref(t('Checking...'));

const currentTab = computed(() => tabs.find((t) => t.id === activeTab.value) || tabs[0]);

onUnmounted(() => {
  window.removeEventListener('beforeunload', onBeforeUnload);
});

onMounted(async () => {
  load();
  window.addEventListener('beforeunload', onBeforeUnload);
  try {
    const res = await post('wss_get_connection_status');
    if (res.success && res.data) {
      const d = res.data;
      if (d.status === 'connected') {
        connectionStatus.value = 'connected';
        let info = d.version ? `v${d.version}` : '';
        if (d.documents !== undefined) info += (info ? ', ' : '') + t('%s docs', d.documents);
        connectionLabel.value = info ? t('Connected (%s)', info) : t('Connected');
      } else if (d.status === 'not_configured') {
        connectionStatus.value = 'idle';
        connectionLabel.value = t('Not Configured');
      } else {
        connectionStatus.value = 'error';
        connectionLabel.value = d.message || t('Error');
      }
    }
  } catch {
    connectionStatus.value = 'error';
    connectionLabel.value = t('Connection error');
  }
});
</script>
