/**
 * Woo Smart Search — Results Page
 *
 * Faceted search results with AJAX filtering, sorting, pagination,
 * and URL parameter persistence.
 *
 * @package WooSmartSearch
 */

( function () {
	'use strict';

	/* ---- Globals from wp_localize_script ---- */
	var cfg = window.wssConfig || {};

	// REST nonce only for logged-in users (a cached guest nonce expires → 403).
	function restHeaders() {
		return cfg.nonce ? { 'X-WP-Nonce': cfg.nonce } : {};
	}

	/* ---- Direct Meilisearch (ultra-fast mode) ---- */
	var useDirect = !!( cfg.meiliUrl && cfg.meiliKey && cfg.meiliIndex );
	var meiliSearchUrl = useDirect
		? cfg.meiliUrl + '/indexes/' + encodeURIComponent( cfg.meiliIndex ) + '/search'
		: '';

	/* ---- Local engine mode ---- */
	var useLocal = cfg.engineType === 'local' && !!cfg.localSearchUrl;

	/* ---- Layout config ---- */
	var layout = cfg.resultsLayout || 'default';
	var layoutMobile = cfg.resultsLayoutMobile || 'same';
	var allLayouts = [ 'default', 'amazon', 'temu', 'mercadolibre', 'aliexpress', 'shopify' ];
	var currentLayout = layout;
	var resizeTimer = null;

	/**
	 * Pick the layout that applies for the current viewport: the mobile
	 * layout on small screens (when one is configured), otherwise desktop.
	 */
	function effectiveLayout() {
		var isMobile = window.innerWidth <= 768;
		if ( isMobile && layoutMobile && layoutMobile !== 'same' ) {
			return layoutMobile;
		}
		return layout;
	}

	/**
	 * Apply the effective layout class to the page, removing any other
	 * layout class so only one is ever active.
	 */
	function applyResponsiveLayout() {
		if ( ! dom.page ) return;
		var target = effectiveLayout();
		if ( target === currentLayout && dom.page.classList.contains( 'wss-layout-' + target ) ) {
			return;
		}
		allLayouts.forEach( function ( l ) {
			dom.page.classList.toggle( 'wss-layout-' + l, l === target && l !== 'default' );
		} );
		currentLayout = target;
		// mercadolibre defaults to list view; others to grid. Only auto-switch
		// when the user hasn't manually toggled the view this session.
		if ( ! state.viewLocked ) {
			var wantList = ( target === 'mercadolibre' );
			state.view = wantList ? 'list' : 'grid';
			if ( dom.grid ) dom.grid.classList.toggle( 'wss-view-list', wantList );
		}
	}

	/* ---- State ---- */
	var defaultView = ( layout === 'mercadolibre' ) ? 'list' : 'grid';
	var state = {
		query:   '',
		page:    1,
		limit:   cfg.resultsPerPage || 12,
		sort:    '',
		filters: {},          // { categories: ['Cat A'], stock_status: ['instock'], ... }
		priceMin: null,
		priceMax: null,
		view:    defaultView,      // 'grid' or 'list'
		total:   0,
		facets:  {},
		loading: false,
		controller: null
	};

	/* ---- DOM refs (set on init) ---- */
	var dom = {};

	/**
	 * Reject after `ms` so a slow (not down) engine still falls back to the
	 * WP REST API instead of hanging the page indefinitely.
	 */
	function withTimeout( promise, ms ) {
		return Promise.race( [
			promise,
			new Promise( function ( resolve, reject ) {
				setTimeout( function () { reject( new Error( 'WSS engine timeout' ) ); }, ms );
			} )
		] );
	}

	/* ---- Init ---- */
	function init() {
		var page = document.querySelector( '.wss-results-page' );
		if ( ! page ) {
			return;
		}

		dom.page = page;

		// Apply the layout for the current viewport (desktop vs mobile).
		applyResponsiveLayout();

		// Re-evaluate the layout when the viewport crosses the breakpoint.
		window.addEventListener( 'resize', function () {
			clearTimeout( resizeTimer );
			resizeTimer = setTimeout( applyResponsiveLayout, 150 );
		} );

		// Apply image ratio utility class.
		var imgRatio = cfg.rpImageRatio || '1:1';
		if ( imgRatio !== '1:1' ) {
			page.classList.add( 'wss-img-ratio-' + imgRatio.replace( ':', '-' ) );
		}

		// Apply image fit utility class.
		var imgFit = cfg.rpImageFit || 'cover';
		if ( imgFit === 'contain' ) {
			page.classList.add( 'wss-img-fit-contain' );
		}

		// Apply card shadow utility class.
		var cardShadow = cfg.rpCardShadow || 'medium';
		page.classList.add( 'wss-shadow-' + cardShadow );

		dom.grid           = page.querySelector( '.wss-products-grid' );
		dom.sidebar        = page.querySelector( '.wss-filters-sidebar' );
		dom.toolbar        = page.querySelector( '.wss-results-toolbar' );
		dom.sortSelect     = page.querySelector( '.wss-sort-select' );
		dom.viewToggle     = page.querySelector( '.wss-view-toggle' );
		dom.pagination     = page.querySelector( '.wss-pagination' );
		dom.loading        = page.querySelector( '.wss-results-loading' );
		dom.noResults      = page.querySelector( '.wss-no-results' );
		dom.resultsCount   = page.querySelector( '.wss-results-count' );
		dom.activeFilters  = page.querySelector( '.wss-active-filters' );
		dom.mobileToggle   = page.querySelector( '.wss-mobile-filter-toggle' );
		dom.mobileOverlay  = page.querySelector( '.wss-mobile-filter-overlay' );
		dom.filterClose    = page.querySelector( '.wss-filter-panel-close button' );

		// Read URL params.
		readUrlParams();

		// Bind events.
		bindEvents();

		// Initial search.
		performSearch();
	}

	/* ---- URL Params ---- */

	function readUrlParams() {
		var params = new URLSearchParams( window.location.search );

		state.query    = ( params.get( 'q' ) || params.get( 's' ) || '' ).substring( 0, 100 );
		state.page     = Math.max( 1, parseInt( params.get( 'paged' ) || '1', 10 ) || 1 );
		state.sort     = /^[A-Za-z_][\w.]*:(asc|desc)$/i.test( params.get( 'sort' ) || '' ) ? params.get( 'sort' ) : '';
		state.view     = params.get( 'view' ) === 'list' ? 'list' : 'grid';

		var priceMin = parseFloat( params.get( 'price_min' ) );
		var priceMax = parseFloat( params.get( 'price_max' ) );
		if ( ! isNaN( priceMin ) ) state.priceMin = priceMin;
		if ( ! isNaN( priceMax ) ) state.priceMax = priceMax;

		// Read filter params (filter_categories=A,B). Filter names are limited
		// to safe identifiers: they end up in filter expressions and markup.
		params.forEach( function ( value, key ) {
			if ( key.indexOf( 'filter_' ) === 0 ) {
				var filterName = key.replace( 'filter_', '' );
				if ( ! /^[A-Za-z0-9_.\- ]{1,64}$/.test( filterName ) ) return;
				state.filters[ filterName ] = value.split( ',' ).slice( 0, 50 );
			}
		} );
	}

	function updateUrl() {
		// Keep unrelated params (page_id on plain permalinks, lang for
		// WPML/Polylang, UTM tags); only the search state keys are rebuilt.
		var params = new URLSearchParams( window.location.search );
		[ 'q', 's', 'paged', 'sort', 'view', 'price_min', 'price_max' ].forEach( function ( k ) { params.delete( k ); } );
		Array.from( params.keys() ).forEach( function ( k ) {
			if ( k.indexOf( 'filter_' ) === 0 ) params.delete( k );
		} );
		params.set( 'q', state.query );

		if ( state.page > 1 ) params.set( 'paged', state.page );
		if ( state.sort )     params.set( 'sort', state.sort );
		if ( state.view !== 'grid' ) params.set( 'view', state.view );
		if ( state.priceMin !== null ) params.set( 'price_min', state.priceMin );
		if ( state.priceMax !== null ) params.set( 'price_max', state.priceMax );

		Object.keys( state.filters ).forEach( function ( key ) {
			if ( state.filters[ key ].length ) {
				params.set( 'filter_' + key, state.filters[ key ].join( ',' ) );
			}
		} );

		var newUrl = window.location.pathname + '?' + params.toString();
		window.history.replaceState( null, '', newUrl );
	}

	/* ---- Events ---- */

	function bindEvents() {
		// Sort.
		if ( dom.sortSelect ) {
			dom.sortSelect.value = state.sort;
			dom.sortSelect.addEventListener( 'change', function () {
				state.sort = this.value;
				state.page = 1;
				performSearch();
			} );
		}

		// View toggle.
		if ( dom.viewToggle ) {
			var btns = dom.viewToggle.querySelectorAll( 'button' );
			btns.forEach( function ( btn ) {
				if ( btn.dataset.view === state.view ) btn.classList.add( 'wss-active' );
				btn.addEventListener( 'click', function () {
					btns.forEach( function ( b ) { b.classList.remove( 'wss-active' ); } );
					btn.classList.add( 'wss-active' );
					state.view = btn.dataset.view;
					state.viewLocked = true; // user chose a view; don't auto-switch on layout change
					if ( dom.grid ) {
						dom.grid.classList.toggle( 'wss-view-list', state.view === 'list' );
					}
					updateUrl();
				} );
			} );
		}

		// Mobile filter toggle.
		if ( dom.mobileToggle ) {
			dom.mobileToggle.addEventListener( 'click', function () {
				if ( dom.sidebar ) dom.sidebar.classList.add( 'wss-open' );
				if ( dom.mobileOverlay ) dom.mobileOverlay.classList.add( 'wss-visible' );
				document.body.style.overflow = 'hidden';
			} );
		}

		if ( dom.mobileOverlay ) {
			dom.mobileOverlay.addEventListener( 'click', closeMobileFilters );
		}

		// Click tracking — single delegated listener (results re-render often;
		// per-link listeners would accumulate and fire N times).
		if ( dom.grid ) {
			dom.grid.addEventListener( 'click', function ( e ) {
				var link = e.target.closest( '.wss-product-card a' );
				if ( ! link || ! dom.grid.contains( link ) ) return;
				var card = link.closest( '.wss-product-card' );
				var productId = card ? card.dataset.id : '';
				if ( productId && cfg.trackClickUrl ) {
					trackClick( state.query, productId );
				}
			} );
		}

		// Sidebar — single delegated set of listeners. The sidebar HTML is
		// re-rendered on every search, so per-element listeners would leak.
		if ( dom.sidebar ) {
			bindSidebarDelegation();
		}
	}

	function bindSidebarDelegation() {
		// Collapse toggle + mobile close.
		dom.sidebar.addEventListener( 'click', function ( e ) {
			var closeBtn = e.target.closest( '.wss-filter-panel-close button' );
			if ( closeBtn ) {
				closeMobileFilters();
				return;
			}
			var header = e.target.closest( '.wss-filter-group-header' );
			if ( header ) {
				header.closest( '.wss-filter-group' ).classList.toggle( 'wss-collapsed' );
			}
		} );

		// Checkbox filters.
		dom.sidebar.addEventListener( 'change', function ( e ) {
			var cb = e.target;
			if ( cb.type !== 'checkbox' ) return;
			var group = cb.closest( '.wss-filter-group[data-filter]' );
			if ( ! group ) return;
			var filterKey = group.dataset.filter;
			if ( filterKey === 'price' ) return;

			if ( ! state.filters[ filterKey ] ) {
				state.filters[ filterKey ] = [];
			}
			if ( cb.checked ) {
				state.filters[ filterKey ].push( cb.value );
			} else {
				state.filters[ filterKey ] = state.filters[ filterKey ].filter( function ( v ) {
					return v !== cb.value;
				} );
			}
			state.page = 1;
			performSearch();
		} );

		// Price inputs (input events bubble).
		var priceDebounce;
		dom.sidebar.addEventListener( 'input', function ( e ) {
			if ( ! e.target.classList.contains( 'wss-price-min' ) && ! e.target.classList.contains( 'wss-price-max' ) ) {
				return;
			}
			clearTimeout( priceDebounce );
			priceDebounce = setTimeout( function () {
				var minInput = dom.sidebar.querySelector( '.wss-price-min' );
				var maxInput = dom.sidebar.querySelector( '.wss-price-max' );
				var minVal = minInput ? minInput.value : '';
				var maxVal = maxInput ? maxInput.value : '';
				state.priceMin = minVal !== '' ? parseFloat( minVal ) : null;
				state.priceMax = maxVal !== '' ? parseFloat( maxVal ) : null;
				state.page = 1;
				performSearch();
			}, 500 );
		} );
	}

	function closeMobileFilters() {
		if ( dom.sidebar ) dom.sidebar.classList.remove( 'wss-open' );
		if ( dom.mobileOverlay ) dom.mobileOverlay.classList.remove( 'wss-visible' );
		document.body.style.overflow = '';
	}

	/* ---- Search ---- */

	function buildFilterString() {
		var filterParts = [];

		Object.keys( state.filters ).forEach( function ( key ) {
			if ( state.filters[ key ].length ) {
				var conditions = state.filters[ key ].map( function ( v ) {
					return key + ' = "' + v.replace( /"/g, '\\"' ) + '"';
				} );
				filterParts.push( '(' + conditions.join( ' OR ' ) + ')' );
			}
		} );

		if ( state.priceMin !== null ) {
			filterParts.push( 'price >= ' + state.priceMin );
		}
		if ( state.priceMax !== null ) {
			filterParts.push( 'price <= ' + state.priceMax );
		}

		return filterParts.length ? filterParts.join( ' AND ' ) : '';
	}

	function performSearch() {
		if ( state.loading && state.controller ) {
			state.controller.abort();
		}

		state.loading = true;
		showLoading( true );
		updateUrl();

		state.controller = new AbortController();

		var filterStr = buildFilterString();
		var searchPromise;

		function wpFallbackSearch() {
			var params = new URLSearchParams();
			params.set( 'q', state.query );
			params.set( 'limit', state.limit );
			params.set( 'page', state.page );

			if ( filterStr ) {
				params.set( 'filters', filterStr );
			}

			if ( state.sort ) {
				params.set( 'sort', state.sort );
			}

			return fetch( cfg.apiUrl + '?' + params.toString(), {
				signal: state.controller.signal,
				headers: restHeaders()
			} )
			.then( function ( res ) {
				if ( ! res.ok ) throw new Error( 'HTTP ' + res.status );
				return res.json();
			} );
		}

		if ( useLocal ) {
			// Local engine: SHORTINIT endpoint.
			var numLimitLocal = parseInt( state.limit, 10 ) || 12;
			var localParams = 'wss_action=search&q=' + encodeURIComponent( state.query ) +
				'&limit=' + numLimitLocal +
				'&page=' + state.page;

			var localFacets = cfg.meilieFacets || ( cfg.isEcommerce || cfg.isMixed
				? [ 'categories', 'tags', 'stock_status', 'on_sale', 'brand', 'rating' ]
				: [ 'categories', 'tags', 'post_type', 'author' ] );
			localParams += '&facets=' + encodeURIComponent( localFacets.join( ',' ) );

			// Build filter combining user filters + content_source restriction.
			var localCombinedFilter = filterStr;
			if ( ! cfg.isMixed && cfg.contentSource ) {
				var localSourceValue = cfg.isEcommerce ? 'woocommerce' : 'wordpress';
				var localSourceFilter = 'content_source = "' + localSourceValue + '"';
				localCombinedFilter = localCombinedFilter ? localCombinedFilter + ' AND ' + localSourceFilter : localSourceFilter;
			}
			if ( localCombinedFilter ) {
				localParams += '&filters=' + encodeURIComponent( localCombinedFilter );
			}
			if ( state.sort ) {
				localParams += '&sort=' + encodeURIComponent( state.sort );
			}

			searchPromise = withTimeout( fetch( cfg.localSearchUrl + '?' + localParams, {
				signal: state.controller.signal
			} ), 6000 )
			.then( function ( res ) {
				if ( ! res.ok ) throw new Error( 'Local HTTP ' + res.status );
				return res.json();
			} )
			.then( function ( data ) {
				var hits = ( data.hits || [] ).map( function ( hit ) {
					var formatted = hit._formatted || {};
					hit.name_highlighted = formatted.name || hit.name || '';
					return hit;
				} );
				return {
					hits: hits,
					total: data.estimatedTotalHits || hits.length,
					facets: data.facetDistribution || {},
					processingTimeMs: data.processingTimeMs || 0
				};
			} )
			.catch( function ( err ) {
				if ( err.name === 'AbortError' ) throw err;
				console.warn( 'WSS: Local search failed, falling back to WP REST API', err.message );
				return wpFallbackSearch();
			} );
		} else if ( useDirect ) {
			// Ultra-fast: direct Meilisearch POST, with automatic WP fallback on failure.
			var numLimit = parseInt( state.limit, 10 ) || 12;
			var body = {
				q: state.query,
				limit: numLimit,
				offset: ( state.page - 1 ) * numLimit,
				attributesToHighlight: [ 'name' ],
				highlightPreTag: '<mark>',
				highlightPostTag: '</mark>',
				facets: cfg.meilieFacets || ( cfg.isEcommerce || cfg.isMixed
				? [ 'categories', 'tags', 'stock_status', 'on_sale', 'brand', 'rating' ]
				: [ 'categories', 'tags', 'post_type', 'author' ] )
			};

			// Build filter combining user filters + content_source restriction.
			var combinedFilter = filterStr;
			if ( ! cfg.isMixed && cfg.contentSource ) {
				var sourceValue = cfg.isEcommerce ? 'woocommerce' : 'wordpress';
				var sourceFilter = 'content_source = "' + sourceValue + '"';
				combinedFilter = combinedFilter ? combinedFilter + ' AND ' + sourceFilter : sourceFilter;
			}
			if ( cfg.hideOutOfStock ) {
				var stockFilter = 'stock_status != "outofstock"';
				combinedFilter = combinedFilter ? combinedFilter + ' AND ' + stockFilter : stockFilter;
			}

			if ( combinedFilter ) {
				body.filter = combinedFilter;
			}

			if ( state.sort ) {
				body.sort = [ state.sort ];
			}

			searchPromise = withTimeout( fetch( meiliSearchUrl, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer ' + cfg.meiliKey
				},
				body: JSON.stringify( body ),
				signal: state.controller.signal
			} ), 6000 )
			.then( function ( res ) {
				if ( ! res.ok ) throw new Error( 'Meili HTTP ' + res.status );
				return res.json();
			} )
			.then( function ( data ) {
				var hits = ( data.hits || [] ).map( function ( hit ) {
					var formatted = hit._formatted || {};
					hit.name_highlighted = formatted.name || hit.name || '';
					return hit;
				} );
				var directTotal = data.estimatedTotalHits || hits.length;
				// Log this search for analytics — direct Meili mode never touches
				// the server, so without this beacon it would go unrecorded.
				trackSearch( state.query, directTotal );
				return {
					hits: hits,
					total: directTotal,
					facets: data.facetDistribution || {},
					processingTimeMs: data.processingTimeMs || 0
				};
			} )
			.catch( function ( err ) {
				if ( err.name === 'AbortError' ) throw err;
				console.warn( 'WSS: Direct Meilisearch failed, falling back to WP REST API', err.message );
				return wpFallbackSearch();
			} );
		} else {
			searchPromise = wpFallbackSearch();
		}

		searchPromise
		.then( function ( data ) {
			state.loading = false;
			state.total   = data.total || 0;
			state.facets  = data.facets || {};

			showLoading( false );
			renderResults( ( data.hits || [] ).filter( function ( h ) { return h && h.name && h.name.trim() !== ''; } ) );
			renderFacets( state.facets );
			renderActiveFilters();
			renderPagination();
			updateResultsCount();
		} )
		.catch( function ( err ) {
			if ( err.name === 'AbortError' ) return;
			state.loading = false;
			showLoading( false );
			if ( dom.noResults ) {
				dom.noResults.style.display = 'block';
				dom.noResults.innerHTML = '<p>' + escapeHtml( ( cfg.i18n || {} ).errorLoading || 'Error loading results. Please try again.' ) + '</p>';
			}
			console.error( 'WSS Results:', err );
		} );
	}

	/* ---- Render Results ---- */

	function renderResults( hits ) {
		if ( ! dom.grid ) return;

		if ( ! hits.length ) {
			dom.grid.innerHTML = '';
			if ( dom.noResults ) dom.noResults.style.display = 'block';
			return;
		}

		if ( dom.noResults ) dom.noResults.style.display = 'none';

		dom.grid.classList.toggle( 'wss-view-list', state.view === 'list' );
		dom.grid.classList.toggle( 'wss-mixed-layout', !!cfg.isMixed );

		var html = '';

		// In mixed mode, group results by content_source into separate sections.
		if ( cfg.isMixed ) {
			var productHits = [];
			var contentHits = [];

			hits.forEach( function ( hit ) {
				if ( hit.content_source === 'woocommerce' ) {
					productHits.push( hit );
				} else {
					contentHits.push( hit );
				}
			} );

			if ( productHits.length ) {
				html += '<div class="wss-mixed-section">';
				html += '<h3 class="wss-mixed-section-title">Products <span class="wss-mixed-section-count">(' + productHits.length + ')</span></h3>';
				html += '<div class="wss-mixed-section-grid wss-products-grid' + ( state.view === 'list' ? ' wss-view-list' : '' ) + '">';
				productHits.forEach( function ( hit ) {
					html += buildProductCard( hit );
				} );
				html += '</div></div>';
			}

			if ( contentHits.length ) {
				// Group content by post_type.
				var byType = {};
				contentHits.forEach( function ( hit ) {
					var pt = hit.post_type || 'post';
					if ( ! byType[ pt ] ) byType[ pt ] = [];
					byType[ pt ].push( hit );
				} );

				Object.keys( byType ).forEach( function ( pt ) {
					var ptLabel = pt.charAt( 0 ).toUpperCase() + pt.slice( 1 ) + 's';
					html += '<div class="wss-mixed-section">';
					html += '<h3 class="wss-mixed-section-title">' + escapeHtml( ptLabel ) + ' <span class="wss-mixed-section-count">(' + byType[ pt ].length + ')</span></h3>';
					html += '<div class="wss-mixed-section-grid wss-products-grid' + ( state.view === 'list' ? ' wss-view-list' : '' ) + '">';
					byType[ pt ].forEach( function ( hit ) {
						html += buildPostCard( hit );
					} );
					html += '</div></div>';
				} );
			}
		} else {
			hits.forEach( function ( hit ) {
				html += buildProductCard( hit );
			} );
		}

		dom.grid.innerHTML = html;
	}

	function buildProductCard( hit ) {
		// Detect content source: use per-hit value or global config.
		var isWpContent = hit.content_source === 'wordpress' || ( cfg.contentSource === 'wordpress' && ! cfg.isEcommerce );

		if ( isWpContent ) {
			return buildPostCard( hit );
		}

		var imgSrc    = hit.image || cfg.placeholderImg || '';
		var name      = hit.name_highlighted ? sanitizeHighlight( hit.name_highlighted ) : escapeHtml( decodeHtml( hit.name || '' ) );
		var category  = ( cfg.rpShowCategory && hit.categories && hit.categories.length ) ? escapeHtml( decodeHtml( hit.categories[0] ) ) : '';
		var permalink = safeUrl( hit.permalink );
		var saleBadge = '';

		// Price.
		var priceHtml = '';
		var isOnSale = false;
		var discountPercent = 0;
		if ( cfg.rpShowPrice && typeof hit.price !== 'undefined' ) {
			if ( hit.on_sale && hit.regular_price > hit.price ) {
				isOnSale = true;
				discountPercent = Math.round( ( 1 - hit.price / hit.regular_price ) * 100 );
				if ( cfg.rpShowSaleBadge ) {
					saleBadge = '<span class="wss-sale-badge">-' + discountPercent + '%</span>';
				}
				priceHtml = '<span class="wss-price-current wss-on-sale">' + formatPrice( hit.price ) + '</span>' +
					'<span class="wss-price-regular">' + formatPrice( hit.regular_price ) + '</span>' +
					( discountPercent > 0 ? '<span class="wss-price-off">' + discountPercent + '% ' + escapeHtml( ( cfg.i18n && cfg.i18n.off ) || 'OFF' ) + '</span>' : '' );
			} else if ( hit.price_min && hit.price_max && hit.price_min !== hit.price_max ) {
				priceHtml = '<span class="wss-price-range">' +
					formatPrice( hit.price_min ) + ' – ' + formatPrice( hit.price_max ) + '</span>';
			} else {
				priceHtml = '<span class="wss-price-current">' + formatPrice( hit.price ) + '</span>';
			}
		}

		// Stock.
		var stockHtml = '';
		if ( cfg.rpShowStock && hit.stock_status ) {
			var stockClass = 'wss-stock-' + hit.stock_status;
			var stockLabel = hit.stock_status === 'instock' ? ( cfg.i18n ? cfg.i18n.inStock : 'In stock' ) :
				hit.stock_status === 'outofstock' ? ( cfg.i18n ? cfg.i18n.outOfStock : 'Out of stock' ) :
				( cfg.i18n ? cfg.i18n.onBackorder : 'On backorder' );
			stockHtml = '<div class="wss-product-card-stock">' +
				'<span class="wss-stock-dot ' + stockClass + '"></span>' +
				'<span>' + escapeHtml( stockLabel ) + '</span></div>';
		}

		// Rating.
		var ratingHtml = '';
		if ( cfg.rpShowRating && hit.rating && hit.rating > 0 ) {
			ratingHtml = '<div class="wss-product-card-rating">' +
				'<span class="wss-stars">' + buildStars( hit.rating ) + '</span>' +
				( hit.review_count ? '<span class="wss-review-count">(' + hit.review_count + ')</span>' : '' ) +
				'</div>';
		}

		// SKU.
		var skuHtml = '';
		if ( cfg.rpShowSku && hit.sku ) {
			skuHtml = '<div class="wss-product-card-sku">SKU: ' + escapeHtml( hit.sku ) + '</div>';
		}

		// Short description.
		var descHtml = '';
		if ( cfg.rpShowDescription && hit.description ) {
			descHtml = '<div class="wss-product-card-description">' + escapeHtml( hit.description ).substring( 0, 120 ) + '</div>';
		}

		// Discount badge (separate from sale badge, positioned by layout CSS).
		var discountBadgeHtml = '';
		if ( cfg.rpShowSaleBadge && isOnSale && discountPercent > 0 ) {
			discountBadgeHtml = '<span class="wss-discount-badge">-' + discountPercent + '%</span>';
		}

		// Sold/orders count.
		var soldHtml = '';
		if ( cfg.rpShowSold && hit.total_sales && hit.total_sales > 0 ) {
			var soldText = hit.total_sales >= 1000
				? ( Math.floor( hit.total_sales / 1000 ) + 'k+ ' + ( cfg.i18n ? cfg.i18n.sold || 'sold' : 'sold' ) )
				: ( hit.total_sales + ' ' + ( cfg.i18n ? cfg.i18n.sold || 'sold' : 'sold' ) );
			soldHtml = '<div class="wss-product-card-sold">' + escapeHtml( soldText ) + '</div>';
		}

		// Shipping badge.
		var shippingHtml = '';
		if ( cfg.rpShowShipping ) {
			shippingHtml = '<div class="wss-product-card-shipping">' +
				escapeHtml( cfg.i18n ? cfg.i18n.freeShipping || 'Free shipping' : 'Free shipping' ) + '</div>';
		}

		// Add to Cart button.
		var actionsHtml = '';
		if ( cfg.rpShowAddToCart ) {
			var addToCartText = cfg.i18n ? cfg.i18n.addToCart || 'Add to Cart' : 'Add to Cart';
			actionsHtml = '<div class="wss-product-card-actions" style="display:block">' +
				'<a href="' + escapeHtml( permalink ) + '" class="wss-add-to-cart-btn">' + escapeHtml( addToCartText ) + '</a>' +
				'</div>';
		}

		// Image.
		var imageHtml = '';
		if ( cfg.rpShowImage ) {
			imageHtml = '<div class="wss-product-card-image">' +
				saleBadge +
				discountBadgeHtml +
				'<img src="' + escapeHtml( imgSrc ) + '" alt="' + escapeHtml( hit.name || '' ) + '" loading="lazy" />' +
			'</div>';
		}

		return '<div class="wss-product-card" data-id="' + ( hit.id || '' ) + '">' +
			'<a href="' + escapeHtml( permalink ) + '">' +
			imageHtml +
			'<div class="wss-product-card-body">' +
				( category ? '<div class="wss-product-card-category">' + category + '</div>' : '' ) +
				'<div class="wss-product-card-name">' + name + '</div>' +
				skuHtml +
				descHtml +
				( priceHtml ? '<div class="wss-product-card-price">' + priceHtml + '</div>' : '' ) +
				stockHtml +
				ratingHtml +
				soldHtml +
				shippingHtml +
			'</div>' +
			'</a>' +
			actionsHtml +
			'</div>';
	}

	/**
	 * Build a card for WordPress posts/pages/CPTs (non-ecommerce).
	 */
	function buildPostCard( hit ) {
		var imgSrc    = hit.image || cfg.placeholderImg || '';
		var name      = hit.name_highlighted ? sanitizeHighlight( hit.name_highlighted ) : escapeHtml( decodeHtml( hit.name || '' ) );
		var category  = ( cfg.rpShowCategory && hit.categories && hit.categories.length ) ? escapeHtml( decodeHtml( hit.categories[0] ) ) : '';
		var permalink = safeUrl( hit.permalink );
		var excerpt   = ( cfg.rpShowDescription && hit.description ) ? escapeHtml( hit.description ).substring( 0, 150 ) : '';
		var author    = ( cfg.showAuthor && hit.author ) ? escapeHtml( hit.author ) : '';
		var postType  = ( cfg.showPostType && hit.post_type ) ? escapeHtml( hit.post_type ) : '';

		// Date.
		var dateHtml = '';
		if ( cfg.showDate && hit.date_created ) {
			var d = new Date( hit.date_created * 1000 );
			dateHtml = '<span class="wss-post-date">' + d.toLocaleDateString() + '</span>';
		}

		// Meta line: author + date + post type badge.
		var metaHtml = '';
		var metaParts = [];
		if ( author ) metaParts.push( author );
		if ( dateHtml ) metaParts.push( dateHtml );
		if ( postType ) metaParts.push( '<span class="wss-post-type-badge">' + postType + '</span>' );
		if ( metaParts.length ) {
			metaHtml = '<div class="wss-post-card-meta">' + metaParts.join( ' <span class="wss-meta-sep">&middot;</span> ' ) + '</div>';
		}

		// Image section.
		var imageHtml = '';
		if ( cfg.rpShowImage ) {
			imageHtml = '<div class="wss-product-card-image">' +
				'<img src="' + escapeHtml( imgSrc ) + '" alt="' + escapeHtml( hit.name || '' ) + '" loading="lazy" />' +
			'</div>';
		}

		return '<div class="wss-product-card wss-post-card" data-id="' + ( hit.id || '' ) + '">' +
			'<a href="' + escapeHtml( permalink ) + '">' +
			imageHtml +
			'<div class="wss-product-card-body">' +
				( category ? '<div class="wss-product-card-category">' + category + '</div>' : '' ) +
				'<div class="wss-product-card-name">' + name + '</div>' +
				( excerpt ? '<div class="wss-post-card-excerpt">' + excerpt + '</div>' : '' ) +
				metaHtml +
			'</div>' +
			'</a></div>';
	}

	/* ---- Render Facets (Sidebar) ---- */

	function renderFacets( facets ) {
		if ( ! dom.sidebar ) return;

		// Keep mobile close button.
		var i = cfg.i18n || {};
		var closeHtml = '<div class="wss-filter-panel-close"><button type="button" aria-label="' + escapeHtml( i.close || 'Close' ) + '">&times;</button></div>';
		var html = closeHtml;

		// Determine which facets are visible from config (admin-friendly keys).
		var hasEcommerce = cfg.isEcommerce || cfg.isMixed;
		var hasWordpress = ! cfg.isEcommerce || cfg.isMixed;
		var defaultFacetList = hasEcommerce
			? 'categories,tags,price,stock,attributes,brands,rating' + ( cfg.isMixed ? ',post_type,author' : '' )
			: 'categories,tags,post_type,author';
		var visibleList = ( cfg.visibleFacets || defaultFacetList ).split( ',' );
		function isFacetVisible( key ) {
			return visibleList.indexOf( key ) !== -1;
		}

		// Categories (always available).
		if ( isFacetVisible( 'categories' ) && facets.categories ) {
			html += buildCheckboxFilter( 'categories', i.categories || 'Categories', facets.categories );
		}

		// Tags (available in all modes — products and posts both have tags).
		if ( isFacetVisible( 'tags' ) && facets.tags && Object.keys( facets.tags ).length ) {
			html += buildCheckboxFilter( 'tags', i.tags || 'Tags', facets.tags );
		}

		// Price slider — ecommerce/mixed only (WP posts don't have prices).
		if ( hasEcommerce && isFacetVisible( 'price' ) ) {
			html += buildPriceFilter();
		}

		// Stock status — ecommerce/mixed only.
		if ( hasEcommerce && isFacetVisible( 'stock' ) && facets.stock_status ) {
			html += buildCheckboxFilter( 'stock_status', i.stock || 'Stock', facets.stock_status );
		}

		// Brand — ecommerce/mixed only.
		if ( hasEcommerce && isFacetVisible( 'brands' ) && facets.brand && Object.keys( facets.brand ).length ) {
			html += buildCheckboxFilter( 'brand', i.brand || 'Brand', facets.brand );
		}

		// Rating — ecommerce/mixed only.
		if ( hasEcommerce && isFacetVisible( 'rating' ) && facets.rating ) {
			html += buildRatingFilter( facets.rating );
		}

		// Post type (WordPress content / mixed mode).
		if ( hasWordpress && isFacetVisible( 'post_type' ) && facets.post_type && Object.keys( facets.post_type ).length ) {
			html += buildCheckboxFilter( 'post_type', i.contentType || 'Content Type', facets.post_type );
		}

		// Author (WordPress content / mixed mode).
		if ( hasWordpress && isFacetVisible( 'author' ) && facets.author && Object.keys( facets.author ).length ) {
			html += buildCheckboxFilter( 'author', i.author || 'Author', facets.author );
		}

		// Dynamic product attributes (attributes.Color, attributes.Size, etc.) — ecommerce/mixed only.
		if ( hasEcommerce && isFacetVisible( 'attributes' ) ) {
			var attrPrefix = 'attributes.';
			Object.keys( facets ).forEach( function ( facetKey ) {
				if ( facetKey.indexOf( attrPrefix ) === 0 && facets[ facetKey ] && Object.keys( facets[ facetKey ] ).length ) {
					var attrLabel = facetKey.substring( attrPrefix.length );
					html += buildCheckboxFilter( facetKey, attrLabel, facets[ facetKey ] );
				}
			} );
		}

		// Custom taxonomy facets (tax_genre, tax_topic, etc.).
		var customLabels = cfg.customFacetLabels || {};
		Object.keys( facets ).forEach( function ( facetKey ) {
			if ( facetKey.indexOf( 'tax_' ) === 0 && isFacetVisible( facetKey ) && facets[ facetKey ] && Object.keys( facets[ facetKey ] ).length ) {
				var label = customLabels[ facetKey ] || facetKey.replace( 'tax_', '' );
				html += buildCheckboxFilter( facetKey, label, facets[ facetKey ] );
			}
		} );

		// Custom field facets (cf_color, cf_size, etc.).
		Object.keys( facets ).forEach( function ( facetKey ) {
			if ( facetKey.indexOf( 'cf_' ) === 0 && isFacetVisible( facetKey ) && facets[ facetKey ] && Object.keys( facets[ facetKey ] ).length ) {
				var label = customLabels[ facetKey ] || facetKey.replace( 'cf_', '' );
				html += buildCheckboxFilter( facetKey, label, facets[ facetKey ] );
			}
		} );

		// Re-rendering the sidebar after each search used to drop keyboard
		// focus (price inputs, checkboxes — closing the phone keyboard) and
		// re-open groups the shopper had collapsed: preserve both.
		var cssEsc = function ( v ) { return window.CSS && CSS.escape ? CSS.escape( v ) : String( v ).replace( /["\\]/g, '\\$&' ); };
		var ae = document.activeElement;
		var focusSel = null;
		if ( ae && dom.sidebar.contains( ae ) ) {
			if ( ae.classList.contains( 'wss-price-min' ) ) {
				focusSel = '.wss-price-min';
			} else if ( ae.classList.contains( 'wss-price-max' ) ) {
				focusSel = '.wss-price-max';
			} else if ( 'checkbox' === ae.type ) {
				var fg = ae.closest( '.wss-filter-group' );
				focusSel = fg ? '.wss-filter-group[data-filter="' + cssEsc( fg.dataset.filter ) + '"] input[value="' + cssEsc( ae.value ) + '"]' : null;
			}
		}
		var collapsedGroups = Array.prototype.map.call( dom.sidebar.querySelectorAll( '.wss-filter-group.wss-collapsed' ), function ( g ) { return g.dataset.filter; } );

		dom.sidebar.innerHTML = html;
		// Events handled by delegation (bindSidebarDelegation) — nothing to re-bind.

		collapsedGroups.forEach( function ( key ) {
			var g = dom.sidebar.querySelector( '.wss-filter-group[data-filter="' + cssEsc( key ) + '"]' );
			if ( g ) g.classList.add( 'wss-collapsed' );
		} );
		if ( focusSel ) {
			var again = dom.sidebar.querySelector( focusSel );
			if ( again ) again.focus( { preventScroll: true } );
		}
	}

	// Human labels for machine values (stock_status facets showed "instock").
	function facetValueLabel( key, val ) {
		if ( key === 'stock_status' ) {
			var i = cfg.i18n || {};
			if ( val === 'instock' ) return i.inStock || 'In stock';
			if ( val === 'outofstock' ) return i.outOfStock || 'Out of stock';
			if ( val === 'onbackorder' ) return i.onBackorder || 'On backorder';
		}
		return val;
	}

	function buildCheckboxFilter( key, label, values ) {
		var entries = Object.entries( values ).sort( function ( a, b ) { return b[1] - a[1]; } );
		if ( ! entries.length ) return '';

		var selected = state.filters[ key ] || [];

		var html = '<div class="wss-filter-group" data-filter="' + escapeHtml( key ) + '">' +
			'<button class="wss-filter-group-header" type="button">' +
			'<span>' + escapeHtml( label ) + '</span>' +
			'<span class="wss-chevron">&#9660;</span>' +
			'</button><div class="wss-filter-group-body">';

		entries.forEach( function ( entry ) {
			var val   = entry[0];
			var decoded = decodeHtml( val );
			var count = entry[1];
			// Compare against both raw and decoded forms for robust matching.
			var checked = ( selected.indexOf( val ) !== -1 || selected.indexOf( decoded ) !== -1 ) ? ' checked' : '';
			html += '<label class="wss-filter-option">' +
				'<input type="checkbox" value="' + escapeHtml( decoded ) + '"' + checked + ' />' +
				'<span class="wss-filter-label">' + escapeHtml( facetValueLabel( key, decoded ) ) + '</span>' +
				'<span class="wss-filter-count">(' + count + ')</span>' +
				'</label>';
		} );

		html += '</div></div>';
		return html;
	}

	function buildPriceFilter() {
		var i = cfg.i18n || {};
		return '<div class="wss-filter-group" data-filter="price">' +
			'<button class="wss-filter-group-header" type="button">' +
			'<span>' + escapeHtml( i.price || 'Price' ) + '</span>' +
			'<span class="wss-chevron">&#9660;</span>' +
			'</button>' +
			'<div class="wss-filter-group-body">' +
			'<div class="wss-price-slider-wrap">' +
			'<div class="wss-price-inputs">' +
			'<input type="number" class="wss-price-min" placeholder="' + escapeHtml( i.priceMin || 'Min' ) + '" value="' + ( state.priceMin !== null ? state.priceMin : '' ) + '" min="0" step="1" />' +
			'<span class="wss-price-sep">–</span>' +
			'<input type="number" class="wss-price-max" placeholder="' + escapeHtml( i.priceMax || 'Max' ) + '" value="' + ( state.priceMax !== null ? state.priceMax : '' ) + '" min="0" step="1" />' +
			'</div></div></div></div>';
	}

	function buildRatingFilter( values ) {
		var t = cfg.i18n || {};
		var html = '<div class="wss-filter-group wss-rating-filter" data-filter="rating">' +
			'<button class="wss-filter-group-header" type="button">' +
			'<span>' + escapeHtml( t.rating || 'Rating' ) + '</span>' +
			'<span class="wss-chevron">&#9660;</span>' +
			'</button><div class="wss-filter-group-body">';

		var selected = state.filters.rating || [];

		for ( var i = 5; i >= 1; i-- ) {
			var count   = values[ i ] || 0;
			var checked = selected.indexOf( String( i ) ) !== -1 ? ' checked' : '';
			html += '<label class="wss-filter-option">' +
				'<input type="checkbox" value="' + i + '"' + checked + ' />' +
				'<span class="wss-rating-stars">' + buildStars( i ) + '</span>' +
				'<span class="wss-filter-count">(' + count + ')</span>' +
				'</label>';
		}

		html += '</div></div>';
		return html;
	}

	/* ---- Active Filters ---- */

	function renderActiveFilters() {
		if ( ! dom.activeFilters ) return;

		var tags = [];
		var hasFilters = false;

		Object.keys( state.filters ).forEach( function ( key ) {
			state.filters[ key ].forEach( function ( val ) {
				hasFilters = true;
				// For attribute/taxonomy/field filters, show label prefix.
				var displayLabel = escapeHtml( facetValueLabel( key, val ) );
				var customLabels = cfg.customFacetLabels || {};
				if ( key.indexOf( 'attributes.' ) === 0 ) {
					displayLabel = escapeHtml( key.replace( 'attributes.', '' ) ) + ': ' + displayLabel;
				} else if ( key.indexOf( 'tax_' ) === 0 || key.indexOf( 'cf_' ) === 0 ) {
					var filterLabel = customLabels[ key ] || key.replace( /^(tax_|cf_)/, '' );
					displayLabel = escapeHtml( filterLabel ) + ': ' + displayLabel;
				}
				tags.push(
					'<button type="button" class="wss-active-filter-tag" data-filter="' + escapeHtml( key ) + '" data-value="' + escapeHtml( val ) + '" aria-label="' + escapeHtml( ( ( cfg.i18n || {} ).removeFilter || 'Remove filter' ) + ': ' + facetValueLabel( key, val ) ) + '">' +
					displayLabel + ' <span class="wss-remove" aria-hidden="true">&times;</span></button>'
				);
			} );
		} );

		if ( state.priceMin !== null || state.priceMax !== null ) {
			hasFilters = true;
			var priceLabel = ( state.priceMin !== null ? formatPrice( state.priceMin ) : '' ) +
				' – ' + ( state.priceMax !== null ? formatPrice( state.priceMax ) : '' );
			tags.push(
				'<button type="button" class="wss-active-filter-tag" data-filter="price">' +
				escapeHtml( priceLabel ) + ' <span class="wss-remove" aria-hidden="true">&times;</span></button>'
			);
		}

		if ( hasFilters ) {
			tags.push( '<button class="wss-clear-all-filters" type="button">' + escapeHtml( ( cfg.i18n || {} ).clearAll || 'Clear all' ) + '</button>' );
		}

		dom.activeFilters.innerHTML = tags.join( '' );

		// Bind removal.
		dom.activeFilters.querySelectorAll( '.wss-active-filter-tag' ).forEach( function ( tag ) {
			tag.addEventListener( 'click', function () {
				var filterKey = tag.dataset.filter;
				if ( filterKey === 'price' ) {
					state.priceMin = null;
					state.priceMax = null;
				} else {
					var filterVal = tag.dataset.value;
					state.filters[ filterKey ] = ( state.filters[ filterKey ] || [] ).filter( function ( v ) {
						return v !== filterVal;
					} );
				}
				state.page = 1;
				performSearch();
			} );
		} );

		var clearBtn = dom.activeFilters.querySelector( '.wss-clear-all-filters' );
		if ( clearBtn ) {
			clearBtn.addEventListener( 'click', function () {
				state.filters  = {};
				state.priceMin = null;
				state.priceMax = null;
				state.page     = 1;
				performSearch();
			} );
		}
	}

	/* ---- Pagination ---- */

	function renderPagination() {
		if ( ! dom.pagination ) return;

		var totalPages = Math.ceil( state.total / state.limit );
		if ( totalPages <= 1 ) {
			dom.pagination.innerHTML = '';
			return;
		}

		var html = '';

		// Prev.
		html += '<button class="wss-page-prev"' + ( state.page <= 1 ? ' disabled' : '' ) + '>&laquo;</button>';

		// Page numbers.
		var start = Math.max( 1, state.page - 2 );
		var end   = Math.min( totalPages, state.page + 2 );

		if ( start > 1 ) {
			html += '<button data-page="1">1</button>';
			if ( start > 2 ) html += '<span style="padding:0 4px;">...</span>';
		}

		for ( var i = start; i <= end; i++ ) {
			html += '<button data-page="' + i + '"' + ( i === state.page ? ' class="wss-active"' : '' ) + '>' + i + '</button>';
		}

		if ( end < totalPages ) {
			if ( end < totalPages - 1 ) html += '<span style="padding:0 4px;">...</span>';
			html += '<button data-page="' + totalPages + '">' + totalPages + '</button>';
		}

		// Next.
		html += '<button class="wss-page-next"' + ( state.page >= totalPages ? ' disabled' : '' ) + '>&raquo;</button>';

		dom.pagination.innerHTML = html;

		// Bind.
		dom.pagination.querySelectorAll( 'button[data-page]' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				state.page = parseInt( btn.dataset.page, 10 );
				performSearch();
				window.scrollTo( { top: dom.page.offsetTop - 20, behavior: 'smooth' } );
			} );
		} );

		var prevBtn = dom.pagination.querySelector( '.wss-page-prev' );
		var nextBtn = dom.pagination.querySelector( '.wss-page-next' );

		if ( prevBtn ) {
			prevBtn.addEventListener( 'click', function () {
				if ( state.page > 1 ) {
					state.page--;
					performSearch();
					window.scrollTo( { top: dom.page.offsetTop - 20, behavior: 'smooth' } );
				}
			} );
		}

		if ( nextBtn ) {
			nextBtn.addEventListener( 'click', function () {
				if ( state.page < totalPages ) {
					state.page++;
					performSearch();
					window.scrollTo( { top: dom.page.offsetTop - 20, behavior: 'smooth' } );
				}
			} );
		}
	}

	/* ---- Helpers ---- */

	function showLoading( show ) {
		if ( dom.loading ) {
			dom.loading.classList.toggle( 'wss-visible', show );
		}
		if ( dom.grid ) {
			dom.grid.style.opacity = show ? '0.5' : '1';
		}
	}

	function updateResultsCount() {
		if ( dom.resultsCount ) {
			var i = cfg.i18n || {};
			var pattern = cfg.isMixed ? ( i.xResults || '%d results' ) : ( cfg.isEcommerce ? ( i.xProducts || '%d products' ) : ( i.xResults || '%d results' ) );
			dom.resultsCount.textContent = pattern.replace( '%d', state.total );
		}
	}

	function formatPrice( amount ) {
		amount = parseFloat( amount );
		if ( isNaN( amount ) ) return '';

		// 0 is a valid setting (COP, CLP, JPY…): don't let it fall back to 2.
		var decimals    = ( cfg.decimals !== undefined && cfg.decimals !== '' ) ? parseInt( cfg.decimals, 10 ) || 0 : 2;
		var decSep      = cfg.decimalSep || '.';
		var thousandSep = cfg.thousandSep || ',';
		var symbol      = cfg.currencySymbol || '$';
		var pos         = cfg.currencyPos || 'left';

		var fixed  = amount.toFixed( decimals );
		var parts  = fixed.split( '.' );
		var intPart = parts[0].replace( /\B(?=(\d{3})+(?!\d))/g, thousandSep );
		var formatted = decimals > 0 ? intPart + decSep + parts[1] : intPart;

		switch ( pos ) {
			case 'left':       return symbol + formatted;
			case 'left_space': return symbol + ' ' + formatted;
			case 'right':      return formatted + symbol;
			case 'right_space':return formatted + ' ' + symbol;
			default:           return symbol + formatted;
		}
	}

	function buildStars( rating ) {
		var full  = Math.floor( rating );
		var half  = rating - full >= 0.5 ? 1 : 0;
		var empty = 5 - full - half;
		var s     = '';

		for ( var i = 0; i < full; i++ )  s += '&#9733;';
		for ( var j = 0; j < half; j++ )  s += '&#9733;';
		for ( var k = 0; k < empty; k++ ) s += '<span class="wss-star-empty">&#9733;</span>';

		return s;
	}

	// Attribute-safe escaping (the textContent/innerHTML trick leaves quotes
	// unescaped, which let URL filter values break out of attributes).
	var ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
	function escapeHtml( str ) {
		return String( str == null ? '' : str ).replace( /[&<>"']/g, function ( c ) { return ESC_MAP[ c ]; } );
	}

	// Only http(s)/relative links: never javascript: or data: from indexed data.
	function safeUrl( url ) {
		url = String( url || '' );
		return /^(https?:)?\/\//i.test( url ) || url.charAt( 0 ) === '/' ? url : '#';
	}

	function decodeHtml( str ) {
		var txt = document.createElement( 'textarea' );
		txt.innerHTML = str;
		return txt.value;
	}

	/**
	 * Sanitize highlighted text from Meilisearch.
	 *
	 * Only allows <mark> tags; all other HTML is escaped.
	 */
	function sanitizeHighlight( str ) {
		if ( ! str ) return '';
		var decoded = decodeHtml( str );
		var parts   = decoded.split( /(<mark>[\s\S]*?<\/mark>)/gi );
		var result  = '';
		for ( var i = 0; i < parts.length; i++ ) {
			if ( /^<mark>/i.test( parts[ i ] ) ) {
				var inner = parts[ i ].replace( /<\/?mark>/gi, '' );
				result += '<mark>' + escapeHtml( inner ) + '</mark>';
			} else {
				result += escapeHtml( parts[ i ] );
			}
		}
		return result;
	}

	function trackClick( query, productId ) {
		if ( ! cfg.trackClickUrl ) return;

		var formData = new FormData();
		formData.append( 'query', query );
		formData.append( 'product_id', productId );

		fetch( cfg.trackClickUrl, {
			method: 'POST',
			headers: restHeaders(),
			body: formData,
			keepalive: true
		} ).catch( function () {} );
	}

	/**
	 * Track a search for analytics via a non-blocking beacon.
	 * Only used in direct Meilisearch mode: the WP proxy logs on the server,
	 * and the local engine logs in its search endpoint, so those paths must
	 * NOT beacon here or they would double-count.
	 */
	function trackSearch( query, totalResults ) {
		if ( ! useDirect || ! cfg.apiUrl || ! query ) return;
		try {
			var url = cfg.apiUrl.replace( '/search', '/track-search' );
			var data = JSON.stringify( { query: query, total: totalResults } );
			if ( navigator.sendBeacon ) {
				navigator.sendBeacon( url, new Blob( [ data ], { type: 'application/json' } ) );
			} else {
				fetch( url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: data, keepalive: true } ).catch( function () {} );
			}
		} catch ( err ) { /* silent fail */ }
	}

	/* ---- Boot ---- */
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

} )();
